# Builds a SMALL update package: only the files that changed since the installer was built.
# Usage:  MAKE_UPDATE.bat                (normal)
#         MAKE_UPDATE.bat -ResetBaseline (start a new baseline from this build, e.g. when you publish a new installer)
param([string]$SetBaseline = "", [switch]$ResetBaseline)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Get-Hashes([string]$dir) {
    $root = (Resolve-Path $dir).Path.TrimEnd('\')
    $h = [ordered]@{}
    Get-ChildItem -Path $root -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($root.Length + 1).Replace('\', '/')
        $h[$rel] = (Get-FileHash -Algorithm SHA256 $_.FullName).Hash.ToLower()
    }
    return $h
}

# used by BUILD_INSTALLER.bat: the installer's files are the baseline every patch is measured against
if ($SetBaseline) {
    $h = Get-Hashes $SetBaseline
    $h | ConvertTo-Json | Set-Content baseline.json -Encoding UTF8
    Write-Host "Baseline saved from the installer build ($($h.Count) files)."
    exit 0
}

$ver = [regex]::Match((Get-Content Z4ModernLauncher.csproj -Raw), '<Version>([^<]+)</Version>').Groups[1].Value
if (-not $ver) { throw "Could not read <Version> from Z4ModernLauncher.csproj" }
Write-Host "Building version $ver ..."

if (Test-Path release) { Remove-Item release -Recurse -Force }
dotnet publish Z4ModernLauncher.csproj -c Release -r win-x64 --self-contained true -o release\app
if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed" }

$new = Get-Hashes release\app
$base = @{}
if ($ResetBaseline -or -not (Test-Path baseline.json)) {
    $new | ConvertTo-Json | Set-Content baseline.json -Encoding UTF8
    Write-Host "No baseline yet: this build is now the baseline. The patch below contains every file (full size)." -ForegroundColor Yellow
} else {
    (Get-Content baseline.json -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $base[$_.Name] = $_.Value }
}

$changed = @($new.Keys | Where-Object { -not $base.ContainsKey($_) -or $base[$_] -ne $new[$_] })
foreach ($always in @('Z4ModernLauncher.exe', 'Z4ModernLauncher.dll', 'Z4ModernLauncher.deps.json', 'Z4ModernLauncher.runtimeconfig.json')) {
    if ($new.Contains($always) -and $changed -notcontains $always) { $changed += $always }   # the updater looks for the exe inside the package
}

New-Item -ItemType Directory -Force release\patch | Out-Null
foreach ($rel in $changed) {
    $dest = Join-Path release\patch $rel
    New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
    Copy-Item (Join-Path release\app $rel) $dest
}

$patch = "release\Z4Client-$ver-patch.zip"
Compress-Archive -Path release\patch\* -DestinationPath $patch -Force
$hash = (Get-FileHash -Algorithm SHA256 $patch).Hash.ToLower()
$mb = [math]::Round((Get-Item $patch).Length / 1MB, 2)

Compress-Archive -Path release\app\* -DestinationPath "release\Z4Client-$ver-full.zip" -Force   # optional full package

$json = @{ version = $ver; url = "https://YOUR-HOST/Z4Client-$ver-patch.zip"; sha256 = $hash; notes = "Write what is new here." } | ConvertTo-Json
Set-Content release\update.json $json -Encoding UTF8

Write-Host ""
Write-Host "============================================================"
Write-Host "  Done. Upload THIS file to your GitHub release:"
Write-Host "     release\Z4Client-$ver-patch.zip   ($mb MB, $($changed.Count) changed file(s))"
Write-Host "  (the -full.zip is optional and big; update.json is only for non-GitHub hosting)"
Write-Host "  Keep baseline.json in your project (commit it)."
Write-Host "============================================================"
