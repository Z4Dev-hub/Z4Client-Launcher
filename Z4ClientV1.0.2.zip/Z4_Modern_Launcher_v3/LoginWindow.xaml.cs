using System.IO;
using System.Web;
using System.Windows;
using System.Windows.Input;
using Microsoft.Web.WebView2.Core;

namespace Z4ModernLauncher;

/// <summary>In-launcher Microsoft login popup (embedded browser). Returns the OAuth code via <see cref="Code"/>.</summary>
public partial class LoginWindow : Window
{
    private readonly string _url;
    private readonly string _state;

    public string? Code { get; private set; }
    public string? Error { get; private set; }

    public LoginWindow(string authorizeUrl, string state)
    {
        InitializeComponent();
        _url = authorizeUrl;
        _state = state;
        Loaded += OnLoaded;
        Closed += (_, _) => { try { Web.Dispose(); } catch { } };
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        try
        {
            Web.DefaultBackgroundColor = System.Drawing.Color.FromArgb(255, 10, 12, 18);
            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Z4ModernLauncher", "webview");
            var env = await CoreWebView2Environment.CreateAsync(null, folder);
            await Web.EnsureCoreWebView2Async(env);
            Web.CoreWebView2.Settings.AreDevToolsEnabled = false;
            Web.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
            Web.CoreWebView2.NavigationStarting += OnNavigationStarting;
            Web.CoreWebView2.Navigate(_url);
        }
        catch (Exception ex)
        {
            Program.Log("WebView2", ex.ToString());
            Error = "The embedded browser (Microsoft Edge WebView2) could not start: " + ex.Message +
                    "\n\nInstall the WebView2 Runtime from https://developer.microsoft.com/microsoft-edge/webview2/ and try again.";
            Close();
        }
    }

    private void OnNavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
    {
        if (!e.Uri.StartsWith(AuthService.RedirectUri, StringComparison.OrdinalIgnoreCase)) return;
        e.Cancel = true;
        var query = HttpUtility.ParseQueryString(new Uri(e.Uri).Query);
        if (query["error"] is { Length: > 0 } err)
        {
            var desc = query["error_description"];
            Error = err == "access_denied" ? null : "Microsoft returned: " + (desc ?? err);
        }
        else if (query["state"] != _state)
            Error = "Sign-in response did not match the request (state mismatch). Please try again.";
        else
            Code = query["code"];
        Close();
    }

    private void Header_MouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}
