using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace Z4ModernLauncher;

public static class UpdateConfig
{
    /// <summary>
    /// Where the launcher looks for new versions. Set this ONCE before you build the installer. Either:
    ///   a GitHub "latest release" API address, e.g. https://api.github.com/repos/YOURNAME/Z4Client/releases/latest
    ///   (upload the zip made by MAKE_UPDATE.bat as a release asset and tag the release with the version), or
    ///   a link to an update.json file (also made by MAKE_UPDATE.bat) hosted anywhere over https.
    /// Empty = updates are off until a user enters a source in Settings.
    /// </summary>
    public const string DefaultUrl = "https://api.github.com/repos/Z4Dev-hub/Z4Client-Launcher/releases/latest";
}

public sealed record UpdateInfo(Version Version, string VersionText, string Url, string? Sha256, string Notes);

public static class UpdateService
{
    private static Version Norm(Version v) => new(v.Major, Math.Max(v.Minor, 0), Math.Max(v.Build, 0), Math.Max(v.Revision, 0));

    public static Version Current => Norm(typeof(UpdateService).Assembly.GetName().Version ?? new Version(1, 0, 0, 0));
    public static string CurrentText => $"{Current.Major}.{Current.Minor}.{Current.Build}";

    private static HttpClient NewClient()
    {
        var c = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
        c.DefaultRequestHeaders.UserAgent.ParseAdd("Z4Launcher/" + CurrentText);
        c.DefaultRequestHeaders.Accept.ParseAdd("application/json");
        return c;
    }

    /// <summary>First "1.2" / "1.2.3" style number found in the tag, the release title or the file name.</summary>
    private static Version? ParseVersion(IEnumerable<string?> sources)
    {
        foreach (var src in sources)
        {
            var m = System.Text.RegularExpressions.Regex.Match(src ?? "", @"\d+(\.\d+){1,3}");
            if (m.Success && Version.TryParse(m.Value, out var v)) return v;
        }
        return null;
    }

    /// <summary>Returns the newer version, or null if you are up to date.</summary>
    public static async Task<UpdateInfo?> CheckAsync(string url)
    {
        if (!url.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) throw new Exception("The update address must start with https://");
        using var http = NewClient();
        var json = JsonNode.Parse(await http.GetStringAsync(url)) ?? throw new Exception("The update information is empty.");

        string? ver, dl, sha = null, notes;
        string?[] verSources;
        if (json["tag_name"] is not null)                                   // GitHub release
        {
            ver = json["tag_name"]!.ToString();
            notes = json["body"]?.ToString() ?? "";
            var zips = json["assets"]?.AsArray().Where(a => a?["name"]?.ToString().EndsWith(".zip", StringComparison.OrdinalIgnoreCase) == true).ToList();
            var asset = zips?.FirstOrDefault(a => a!["name"]!.ToString().Contains("patch", StringComparison.OrdinalIgnoreCase)) ?? zips?.FirstOrDefault();   // small patch first
            dl = asset?["browser_download_url"]?.ToString();
            verSources = new[] { ver, json["name"]?.ToString(), asset?["name"]?.ToString() };   // tag, release title, file name
            var digest = asset?["digest"]?.ToString();
            if (digest is not null && digest.StartsWith("sha256:", StringComparison.OrdinalIgnoreCase)) sha = digest[7..];
        }
        else                                                                // update.json
        {
            ver = json["version"]?.ToString();
            dl = json["url"]?.ToString();
            sha = json["sha256"]?.ToString();
            notes = json["notes"]?.ToString() ?? "";
            verSources = new[] { ver };
        }
        if (ver is null || dl is null) throw new Exception("The update information has no version or download link.");
        var v = ParseVersion(verSources)
                ?? throw new Exception($"Could not find a version number in the release (tag \"{ver}\"). Tag the release like v2.1.1 or keep the version in the zip name, e.g. Z4Client-2.1.1-patch.zip.");
        v = Norm(v);
        if (v <= Current) return null;
        if (!dl.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) throw new Exception("The download link must be https.");
        return new UpdateInfo(v, $"{v.Major}.{v.Minor}.{v.Build}", dl, sha?.Trim().ToLowerInvariant(), notes.Trim());
    }

    /// <summary>The folder the launcher is installed in must be writable, otherwise it cannot replace itself.</summary>
    public static void EnsureWritable()
    {
        var dir = AppContext.BaseDirectory;
        try
        {
            var probe = Path.Combine(dir, ".z4write");
            File.WriteAllText(probe, "x");
            File.Delete(probe);
        }
        catch { throw new Exception($"The launcher can't write to its install folder ({dir}). Run Z4ClientSetup.exe once as administrator, or install to a folder like C:\\Z4Client."); }
    }

    /// <summary>Downloads, verifies and unpacks the update. Returns the folder with the new files.</summary>
    public static async Task<string> DownloadAsync(UpdateInfo info, Action<double> progress)
    {
        var work = Path.Combine(Path.GetTempPath(), "Z4Update_" + Guid.NewGuid().ToString("N")[..8]);
        Directory.CreateDirectory(work);
        var zip = Path.Combine(work, "update.zip");

        using (var http = new HttpClient { Timeout = Timeout.InfiniteTimeSpan })
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("Z4Launcher/" + CurrentText);
            using var resp = await http.GetAsync(info.Url, HttpCompletionOption.ResponseHeadersRead);
            resp.EnsureSuccessStatusCode();
            var total = resp.Content.Headers.ContentLength ?? 0;
            using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            await using var src = await resp.Content.ReadAsStreamAsync();
            await using var dst = File.Create(zip);
            var buf = new byte[81920];
            long done = 0;
            int n;
            while ((n = await src.ReadAsync(buf)) > 0)
            {
                await dst.WriteAsync(buf.AsMemory(0, n));
                hash.AppendData(buf, 0, n);
                done += n;
                if (total > 0) progress(done / (double)total);
            }
            if (info.Sha256 is { Length: > 0 })
            {
                var actual = Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();
                if (actual != info.Sha256) throw new Exception("The downloaded file does not match its checksum. The update was not installed.");
            }
        }

        var staging = Path.Combine(work, "files");
        ZipFile.ExtractToDirectory(zip, staging, true);
        var exeName = Path.GetFileName(Environment.ProcessPath) ?? "Z4ModernLauncher.exe";
        var exe = Directory.EnumerateFiles(staging, exeName, SearchOption.AllDirectories).FirstOrDefault()
                  ?? throw new Exception($"The update package does not contain {exeName}.");
        return Path.GetDirectoryName(exe)!;
    }

    /// <summary>Starts a helper that waits for this program to exit, copies the new files over it and starts it again.</summary>
    public static void ApplyAndRestart(string stagedDir)
    {
        var appDir = AppContext.BaseDirectory.TrimEnd('\\', '/');
        var exe = Environment.ProcessPath ?? Path.Combine(appDir, "Z4ModernLauncher.exe");
        var pid = Environment.ProcessId;
        var script = Path.Combine(Path.GetTempPath(), $"z4_update_{pid}.bat");
        var workRoot = new DirectoryInfo(stagedDir);
        while (workRoot.Parent is not null && !workRoot.Name.StartsWith("Z4Update_", StringComparison.Ordinal)) workRoot = workRoot.Parent;

        var bat = new StringBuilder();
        bat.AppendLine("@echo off");
        bat.AppendLine("set tries=0");
        bat.AppendLine(":wait");
        bat.AppendLine($"tasklist /FI \"PID eq {pid}\" 2>nul | find /i \"No tasks\" >nul");
        bat.AppendLine("if not errorlevel 1 goto copy");
        bat.AppendLine("set /a tries+=1");
        bat.AppendLine("if %tries% GTR 60 goto fail");
        bat.AppendLine("ping -n 2 127.0.0.1 >nul");
        bat.AppendLine("goto wait");
        bat.AppendLine(":copy");
        bat.AppendLine($"robocopy \"{stagedDir}\" \"{appDir}\" /E /IS /IT /R:5 /W:1 /NFL /NDL /NJH /NJS /NP >nul");
        bat.AppendLine("if errorlevel 8 goto fail");
        bat.AppendLine($"start \"\" \"{exe}\"");
        bat.AppendLine("goto cleanup");
        bat.AppendLine(":fail");
        bat.AppendLine($"echo The update could not be copied. Run the Z4 Client setup again. > \"{Path.Combine(appDir, "update_failed.txt")}\"");
        bat.AppendLine($"start \"\" \"{exe}\"");
        bat.AppendLine(":cleanup");
        bat.AppendLine($"rmdir /s /q \"{workRoot.FullName}\" 2>nul");
        bat.AppendLine("(goto) 2>nul & del \"%~f0\"");
        File.WriteAllText(script, bat.ToString().Replace("\r\n", "\n").Replace("\n", "\r\n"), Encoding.ASCII);

        Process.Start(new ProcessStartInfo("cmd.exe", $"/c \"{script}\"") { CreateNoWindow = true, UseShellExecute = false });
    }
}
