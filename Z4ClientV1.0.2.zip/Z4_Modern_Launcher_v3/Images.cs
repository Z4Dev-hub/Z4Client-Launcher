using System.Collections.Concurrent;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Z4ModernLauncher;

/// <summary>Downloads / decodes images off the UI thread (frozen, so they can be handed to WPF). Handles WebP via SkiaSharp.</summary>
public static class ImageHelper
{
    private static readonly HttpClient Client = new() { Timeout = TimeSpan.FromSeconds(25) };
    private static readonly ConcurrentDictionary<string, BitmapSource?> Memory = new();
    private static readonly string CacheDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Z4ModernLauncher", "icons");

    static ImageHelper()
    {
        Client.DefaultRequestHeaders.UserAgent.ParseAdd("Z4Launcher/2.0");
        _ = Task.Run(() =>   // keep the icon cache small: drop files not used for 30 days
        {
            try
            {
                if (!Directory.Exists(CacheDir)) return;
                foreach (var f in Directory.EnumerateFiles(CacheDir))
                    if (File.GetLastAccessTimeUtc(f) < DateTime.UtcNow.AddDays(-30)) File.Delete(f);
            }
            catch { }
        });
    }

    private static BitmapSource Make(byte[] bytes, int decodeWidth)
    {
        var bi = new BitmapImage();
        bi.BeginInit();
        bi.CacheOption = BitmapCacheOption.OnLoad;
        if (decodeWidth > 0) bi.DecodePixelWidth = decodeWidth;
        bi.StreamSource = new MemoryStream(bytes);
        bi.EndInit();
        bi.Freeze();
        return bi;
    }

    public static BitmapSource? Decode(byte[] bytes, int decodeWidth = 0)
    {
        try { return Make(bytes, decodeWidth); } catch { }
        try   // e.g. WebP, which Windows may not be able to read: convert through SkiaSharp
        {
            using var bmp = SkiaSharp.SKBitmap.Decode(bytes);
            if (bmp is null) return null;
            using var img = SkiaSharp.SKImage.FromBitmap(bmp);
            using var data = img.Encode(SkiaSharp.SKEncodedImageFormat.Png, 100);
            return Make(data.ToArray(), decodeWidth);
        }
        catch { return null; }
    }

    /// <summary>Blocking - only call from background threads (e.g. a Binding with IsAsync=True).</summary>
    public static BitmapSource? FromUrl(string? url, int decodeWidth = 0)
    {
        if (string.IsNullOrWhiteSpace(url)) return null;
        var key = url + "|" + decodeWidth;
        if (Memory.TryGetValue(key, out var hit)) return hit;
        BitmapSource? result = null;
        try
        {
            var file = Path.Combine(CacheDir, Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(url))) + ".bin");
            byte[]? bytes = null;
            if (File.Exists(file)) { try { bytes = File.ReadAllBytes(file); File.SetLastAccessTimeUtc(file, DateTime.UtcNow); } catch { } }
            if (bytes is null)
            {
                bytes = Client.GetByteArrayAsync(url).GetAwaiter().GetResult();
                try { Directory.CreateDirectory(CacheDir); File.WriteAllBytes(file, bytes); } catch { }
            }
            result = Decode(bytes, decodeWidth);
        }
        catch { }
        if (result is not null) Memory[key] = result;
        return result;
    }
}

/// <summary>Icons for installed content: mod logos (inside the jar), pack.png, world icons and screenshot thumbnails.</summary>
public static class LocalIcons
{
    private static readonly ConcurrentDictionary<string, ImageSource?> Cache = new();

    public static ImageSource? Load(string path, bool isDir, bool isShot)
    {
        try
        {
            var stamp = isDir ? Directory.GetLastWriteTimeUtc(path).Ticks : new FileInfo(path).LastWriteTimeUtc.Ticks;
            var key = path + "|" + stamp;
            if (Cache.TryGetValue(key, out var hit)) return hit;
            var img = Read(path, isDir, isShot);
            Cache[key] = img;
            return img;
        }
        catch { return null; }
    }

    private static ImageSource? Read(string path, bool isDir, bool isShot)
    {
        if (isDir)
        {
            foreach (var n in new[] { "icon.png", "pack.png" })
            {
                var f = Path.Combine(path, n);
                if (File.Exists(f)) return ImageHelper.Decode(File.ReadAllBytes(f), 96);
            }
            return null;
        }
        var name = Path.GetFileName(path).ToLowerInvariant();
        if (name.EndsWith(".disabled")) name = name[..^".disabled".Length];
        if (isShot || name.EndsWith(".png") || name.EndsWith(".jpg") || name.EndsWith(".jpeg"))
            return ImageHelper.Decode(File.ReadAllBytes(path), isShot ? 264 : 96);
        if (name.EndsWith(".jar") || name.EndsWith(".zip")) return FromArchive(path);
        return null;
    }

    private static string? IconPath(JsonNode? icon)
    {
        if (icon is JsonValue) return icon.ToString();
        if (icon is JsonObject o)   // {"16": "...", "128": "..."} -> biggest
            return o.OrderByDescending(kv => int.TryParse(kv.Key, out var n) ? n : 0).Select(kv => kv.Value?.ToString()).FirstOrDefault();
        return null;
    }

    private static ImageSource? FromArchive(string path)
    {
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Read);

        byte[]? Bytes(string? entry)
        {
            if (string.IsNullOrWhiteSpace(entry)) return null;
            var e = zip.GetEntry(entry.TrimStart('/').Replace('\\', '/'));
            if (e is null) return null;
            using var s = e.Open();
            using var ms = new MemoryStream();
            s.CopyTo(ms);
            return ms.ToArray();
        }
        string? Text(string entry) => Bytes(entry) is { } b ? Encoding.UTF8.GetString(b) : null;
        ImageSource? Img(byte[]? b) => b is null ? null : ImageHelper.Decode(b, 96);

        if (Img(Bytes("pack.png")) is { } pack) return pack;                                     // resource packs

        try { if (Text("fabric.mod.json") is { } fab && Img(Bytes(IconPath(JsonNode.Parse(fab)?["icon"]))) is { } a) return a; } catch { }
        try { if (Text("quilt.mod.json") is { } q && Img(Bytes(IconPath(JsonNode.Parse(q)?["quilt_loader"]?["metadata"]?["icon"]))) is { } b) return b; } catch { }
        foreach (var toml in new[] { "META-INF/mods.toml", "META-INF/neoforge.mods.toml" })        // Forge / NeoForge
        {
            try
            {
                var t = Text(toml);
                if (t is null) continue;
                var m = Regex.Match(t, "logoFile\\s*=\\s*\"([^\"]+)\"");
                if (m.Success && Img(Bytes(m.Groups[1].Value)) is { } c) return c;
            }
            catch { }
        }
        return null;
    }
}

/// <summary>Draws a front view of a skin (with overlay layers) and cape / face crops. Pure pixel math, no network.</summary>
public static class SkinRenderer
{
    public static BitmapSource? Front(byte[] png, bool slim)
    {
        var bmp = ImageHelper.Decode(png);
        if (bmp is null || bmp.PixelWidth < 64) return null;
        var conv = new FormatConvertedBitmap(bmp, PixelFormats.Bgra32, null, 0);
        int w = conv.PixelWidth, h = conv.PixelHeight, s = w / 64;
        var legacy = h <= 32 * s;
        var src = new byte[w * h * 4];
        conv.CopyPixels(src, w * 4, 0);
        var dst = new byte[16 * 32 * 4];

        void Blit(int sx, int sy, int bw, int bh, int dx, int dy, bool mirror = false)
        {
            for (var y = 0; y < bh; y++)
                for (var x = 0; x < bw; x++)
                {
                    var px = mirror ? bw - 1 - x : x;
                    int xs = (sx + px) * s + s / 2, ys = (sy + y) * s + s / 2;
                    if (xs >= w || ys >= h) continue;
                    var si = (ys * w + xs) * 4;
                    int a = src[si + 3];
                    if (a == 0) continue;
                    var di = ((dy + y) * 16 + dx + x) * 4;
                    int da = dst[di + 3];
                    var outA = a + da * (255 - a) / 255;
                    for (var c = 0; c < 3; c++)
                        dst[di + c] = (byte)((src[si + c] * a + dst[di + c] * da * (255 - a) / 255) / Math.Max(outA, 1));
                    dst[di + 3] = (byte)outA;
                }
        }

        var aw = slim ? 3 : 4;
        Blit(8, 8, 8, 8, 4, 0);                       // head
        Blit(20, 20, 8, 12, 4, 8);                    // body
        Blit(44, 20, aw, 12, slim ? 1 : 0, 8);        // arm (viewer's left)
        Blit(4, 20, 4, 12, 4, 20);                    // leg (viewer's left)
        if (legacy) { Blit(44, 20, aw, 12, 12, 8, true); Blit(4, 20, 4, 12, 8, 20, true); }
        else { Blit(36, 52, aw, 12, 12, 8); Blit(20, 52, 4, 12, 8, 20); }
        Blit(40, 8, 8, 8, 4, 0);                      // hat layer
        if (!legacy)
        {
            Blit(20, 36, 8, 12, 4, 8);                // jacket
            Blit(44, 36, aw, 12, slim ? 1 : 0, 8);    // sleeves
            Blit(52, 52, aw, 12, 12, 8);
            Blit(4, 36, 4, 12, 4, 20);                // pants
            Blit(4, 52, 4, 12, 8, 20);
        }

        const int k = 10;                             // nearest-neighbour upscale
        var big = new byte[16 * k * 32 * k * 4];
        for (var y = 0; y < 32 * k; y++)
            for (var x = 0; x < 16 * k; x++)
                Buffer.BlockCopy(dst, ((y / k) * 16 + x / k) * 4, big, (y * 16 * k + x) * 4, 4);
        var result = BitmapSource.Create(16 * k, 32 * k, 96, 96, PixelFormats.Bgra32, null, big, 16 * k * 4);
        result.Freeze();
        return result;
    }

    public static ImageSource? Face(string path)
    {
        try
        {
            var bmp = ImageHelper.Decode(File.ReadAllBytes(path));
            if (bmp is null || bmp.PixelWidth < 64) return null;
            var s = bmp.PixelWidth / 64;
            var c = new CroppedBitmap(bmp, new Int32Rect(8 * s, 8 * s, 8 * s, 8 * s));
            c.Freeze();
            return c;
        }
        catch { return null; }
    }

    public static ImageSource? CapeFront(string url)
    {
        try
        {
            var bmp = ImageHelper.FromUrl(url);
            if (bmp is null) return null;
            if (bmp.PixelWidth < 22) return bmp;
            var s = Math.Max(1, bmp.PixelWidth / 64);
            var c = new CroppedBitmap(bmp, new Int32Rect(s, s, 10 * s, 16 * s));
            c.Freeze();
            return c;
        }
        catch { return null; }
    }
}
