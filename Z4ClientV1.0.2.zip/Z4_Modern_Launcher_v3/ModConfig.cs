using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Windows;

namespace Z4ModernLauncher;

public enum SettingKind { Bool, Number, Text }

/// <summary>One editable option of a mod config file (bool = switch, number = slider + box, text = box).</summary>
public sealed class SettingRow : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    private void Notify(string n) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

    public string Key { get; init; } = "";                       // full path, e.g. general.tracingDistance
    public string[] Segments { get; init; } = Array.Empty<string>();
    public SettingKind Kind { get; init; }
    public bool IsInt { get; init; }
    public double Min { get; init; }
    public double Max { get; init; } = 1;
    public bool HasSlider { get; init; }
    public int LineIndex { get; init; } = -1;                    // properties / toml
    public string Leading { get; init; } = "";
    public string Tail { get; init; } = "";
    public bool QuotedString { get; init; }
    public string Original { get; init; } = "";

    public string Label => Prettify(Segments.Length > 0 ? Segments[^1] : Key);
    public string Path => Key;
    public Visibility BoolVis => Kind == SettingKind.Bool ? Visibility.Visible : Visibility.Collapsed;
    public Visibility NumVis => Kind == SettingKind.Number ? Visibility.Visible : Visibility.Collapsed;
    public Visibility TextVis => Kind == SettingKind.Text ? Visibility.Visible : Visibility.Collapsed;
    public Visibility SliderVis => Kind == SettingKind.Number && HasSlider ? Visibility.Visible : Visibility.Collapsed;

    private bool _bool;
    public bool BoolValue { get => _bool; set { _bool = value; Notify(nameof(BoolValue)); } }

    private string _text = "";
    public string TextValue { get => _text; set { _text = value; Notify(nameof(TextValue)); } }

    private double _num;
    public double NumberValue
    {
        get => _num;
        set
        {
            var v = IsInt ? Math.Round(value) : Math.Round(value, 4);
            if (v.Equals(_num)) return;
            _num = v;
            Notify(nameof(NumberValue)); Notify(nameof(NumberText));
        }
    }
    public string NumberText
    {
        get => IsInt ? ((long)_num).ToString(CultureInfo.InvariantCulture) : _num.ToString("0.####", CultureInfo.InvariantCulture);
        set { if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) NumberValue = d; else Notify(nameof(NumberText)); }
    }

    /// <summary>Current value as it must be written to the file.</summary>
    public string ValueText => Kind switch
    {
        SettingKind.Bool => BoolValue ? "true" : "false",
        SettingKind.Number => NumberText,
        _ => TextValue
    };
    public bool Changed => ValueText != Original;

    public static string Prettify(string key)
    {
        var s = Regex.Replace(key, "([a-z0-9])([A-Z])", "$1 $2").Replace('_', ' ').Replace('-', ' ').Trim();
        return s.Length == 0 ? key : char.ToUpperInvariant(s[0]) + s[1..];
    }

    public static (double Min, double Max, bool Slider) GuessRange(string key, double value, bool isInt)
    {
        if (value < 0 || double.IsNaN(value)) return (0, 1, false);
        var k = key.ToLowerInvariant();
        if (!isInt && value <= 1 && Regex.IsMatch(k, "volume|amplif|opacity|chance|alpha|gain|strength|scale|sensitiv|multiplier"))
            return (0, Math.Max(1, Math.Ceiling(value * 2)), true);
        var max = isInt ? Math.Max(16, Math.Ceiling(value * 4 / 8) * 8) : Math.Max(1, Math.Ceiling(value * 4));
        if (Regex.IsMatch(k, "distance|range|radius|chunks|blocks|size|limit|max|min|fps|delay|ticks|time"))
            return (0, max, true);
        return (0, max, true);
    }
}

/// <summary>Reads / writes .json, .json5, .properties and simple .toml mod config files. Comments and layout are kept for text formats.</summary>
public sealed class ConfigDocument
{
    public string FilePath { get; }
    public List<SettingRow> Rows { get; } = new();
    public bool LosesComments { get; private set; }
    private readonly string _ext;
    private string[] _lines = Array.Empty<string>();
    private JsonNode? _json;

    public static readonly string[] SupportedExtensions = { ".json", ".json5", ".properties", ".toml" };

    private ConfigDocument(string path) { FilePath = path; _ext = Path.GetExtension(path).ToLowerInvariant(); }

    public static ConfigDocument Load(string path)
    {
        var doc = new ConfigDocument(path);
        var text = File.ReadAllText(path);
        switch (doc._ext)
        {
            case ".json":
            case ".json5": doc.LoadJson(text); break;
            case ".properties": doc.LoadProperties(text); break;
            case ".toml": doc.LoadToml(text); break;
            default: throw new NotSupportedException("Unsupported config format: " + doc._ext);
        }
        return doc;
    }

    private static SettingRow MakeRow(string key, string[] segs, SettingKind kind, string raw, bool isInt, int line = -1,
        string leading = "", string tail = "", bool quoted = false)
    {
        double num = 0;
        double min = 0, max = 1; var slider = false;
        if (kind == SettingKind.Number)
        {
            double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out num);
            (min, max, slider) = SettingRow.GuessRange(key, num, isInt);
        }
        var row = new SettingRow
        {
            Key = key, Segments = segs, Kind = kind, IsInt = isInt, Min = min, Max = max, HasSlider = slider,
            LineIndex = line, Leading = leading, Tail = tail, QuotedString = quoted,
            Original = kind == SettingKind.Number
                ? (isInt ? ((long)num).ToString(CultureInfo.InvariantCulture) : num.ToString("0.####", CultureInfo.InvariantCulture))
                : kind == SettingKind.Bool ? (raw.Equals("true", StringComparison.OrdinalIgnoreCase) ? "true" : "false") : raw
        };
        if (kind == SettingKind.Bool) row.BoolValue = raw.Equals("true", StringComparison.OrdinalIgnoreCase);
        else if (kind == SettingKind.Number) row.NumberValue = num;
        else row.TextValue = raw;
        return row;
    }

    // ------------------------------------------------------------------ JSON
    private void LoadJson(string text)
    {
        var lenient = new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true };
        try { JsonNode.Parse(text); }
        catch { LosesComments = true; }
        _json = JsonNode.Parse(text, null, lenient) ?? throw new Exception("The file is empty.");
        Walk(_json, new List<string>());
    }

    private void Walk(JsonNode? node, List<string> path)
    {
        if (node is JsonObject obj)
        {
            foreach (var kv in obj)
            {
                path.Add(kv.Key);
                Walk(kv.Value, path);
                path.RemoveAt(path.Count - 1);
            }
        }
        else if (node is JsonValue v && path.Count > 0)
        {
            var key = string.Join(".", path);
            switch (v.GetValueKind())
            {
                case JsonValueKind.True: case JsonValueKind.False:
                    Rows.Add(MakeRow(key, path.ToArray(), SettingKind.Bool, v.GetValueKind() == JsonValueKind.True ? "true" : "false", false)); break;
                case JsonValueKind.Number:
                    var raw = v.ToJsonString();
                    Rows.Add(MakeRow(key, path.ToArray(), SettingKind.Number, raw, !raw.Contains('.') && !raw.Contains('e') && !raw.Contains('E'))); break;
                case JsonValueKind.String:
                    Rows.Add(MakeRow(key, path.ToArray(), SettingKind.Text, v.GetValue<string>(), false)); break;
            }
        }
        // arrays and nulls are left untouched
    }

    private void SaveJson()
    {
        foreach (var row in Rows.Where(r => r.Changed))
        {
            JsonNode? cur = _json;
            for (var i = 0; i < row.Segments.Length - 1 && cur is JsonObject o; i++) cur = o[row.Segments[i]];
            if (cur is not JsonObject parent) continue;
            var name = row.Segments[^1];
            parent[name] = row.Kind switch
            {
                SettingKind.Bool => JsonValue.Create(row.BoolValue),
                SettingKind.Number => row.IsInt ? JsonValue.Create((long)row.NumberValue) : JsonValue.Create(row.NumberValue),
                _ => JsonValue.Create(row.TextValue)
            };
        }
        File.WriteAllText(FilePath, _json!.ToJsonString(new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine, new UTF8Encoding(false));
    }

    // ------------------------------------------------------------------ .properties
    private void LoadProperties(string text)
    {
        _lines = text.Replace("\r\n", "\n").Split('\n');
        var rx = new Regex(@"^(\s*([^#!\s=:][^=:]*?)\s*[=:]\s*)(.*)$");
        for (var i = 0; i < _lines.Length; i++)
        {
            var m = rx.Match(_lines[i]);
            if (!m.Success) continue;
            var key = m.Groups[2].Value.Trim();
            var val = m.Groups[3].Value.TrimEnd();
            var lead = m.Groups[1].Value;
            if (val.Equals("true", StringComparison.OrdinalIgnoreCase) || val.Equals("false", StringComparison.OrdinalIgnoreCase))
                Rows.Add(MakeRow(key, new[] { key }, SettingKind.Bool, val, false, i, lead));
            else if (double.TryParse(val, NumberStyles.Float, CultureInfo.InvariantCulture, out _))
                Rows.Add(MakeRow(key, new[] { key }, SettingKind.Number, val, !val.Contains('.') && !val.Contains('e') && !val.Contains('E'), i, lead));
            else
                Rows.Add(MakeRow(key, new[] { key }, SettingKind.Text, val, false, i, lead));
        }
    }

    private void SaveLines()
    {
        foreach (var row in Rows.Where(r => r.Changed && r.LineIndex >= 0))
        {
            var value = row.ValueText;
            if (_ext == ".toml" && row.Kind == SettingKind.Text) value = "\"" + value.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
            _lines[row.LineIndex] = row.Leading + value + row.Tail;
        }
        File.WriteAllText(FilePath, string.Join(Environment.NewLine, _lines), new UTF8Encoding(false));
    }

    // ------------------------------------------------------------------ simple TOML
    private void LoadToml(string text)
    {
        _lines = text.Replace("\r\n", "\n").Split('\n');
        var section = "";
        var rx = new Regex(@"^(\s*)([A-Za-z0-9_\-\.""]+)(\s*=\s*)(.*)$");
        for (var i = 0; i < _lines.Length; i++)
        {
            var line = _lines[i];
            var t = line.Trim();
            if (t.Length == 0 || t.StartsWith('#')) continue;
            if (t.StartsWith('[')) { section = t.Trim('[', ']', ' '); continue; }
            var m = rx.Match(line);
            if (!m.Success) continue;
            var key = m.Groups[2].Value.Trim('"');
            var rest = m.Groups[4].Value;
            var lead = m.Groups[1].Value + m.Groups[2].Value + m.Groups[3].Value;
            if (rest.Length == 0 || rest[0] is '[' or '{') continue;          // arrays / tables are not edited here
            string token, tail; var quoted = false;
            if (rest[0] is '"' or '\'')
            {
                var q = rest[0]; var end = 1;
                while (end < rest.Length && !(rest[end] == q && rest[end - 1] != '\\')) end++;
                if (end >= rest.Length) continue;
                token = rest[1..end]; tail = rest[(end + 1)..]; quoted = true;
            }
            else
            {
                var stop = rest.IndexOfAny(new[] { ' ', '\t', '#' });
                token = stop < 0 ? rest : rest[..stop];
                tail = stop < 0 ? "" : rest[stop..];
            }
            var full = section.Length > 0 ? section + "." + key : key;
            var segs = section.Length > 0 ? new[] { section, key } : new[] { key };
            if (quoted) Rows.Add(MakeRow(full, segs, SettingKind.Text, token, false, i, lead, tail, true));
            else if (token is "true" or "false") Rows.Add(MakeRow(full, segs, SettingKind.Bool, token, false, i, lead, tail));
            else if (double.TryParse(token.Replace("_", ""), NumberStyles.Float, CultureInfo.InvariantCulture, out _))
                Rows.Add(MakeRow(full, segs, SettingKind.Number, token.Replace("_", ""), !token.Contains('.') && !token.Contains('e'), i, lead, tail));
        }
    }

    // ------------------------------------------------------------------ save
    public void Save()
    {
        var backup = FilePath + ".z4bak";                          // original kept once, in case a mod dislikes a value
        if (!File.Exists(backup)) File.Copy(FilePath, backup);
        if (_ext is ".json" or ".json5") SaveJson(); else SaveLines();
    }
}

/// <summary>Finds a mod's id/name inside its jar and the config files that belong to it.</summary>
public static class ModConfigFinder
{
    public static (string? Id, string? Name) ReadModInfo(string jarPath)
    {
        try
        {
            using var fs = new FileStream(jarPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            using var zip = new ZipArchive(fs, ZipArchiveMode.Read);
            foreach (var name in new[] { "fabric.mod.json", "quilt.mod.json" })
            {
                var e = zip.GetEntry(name);
                if (e is null) continue;
                using var s = e.Open();
                var j = JsonNode.Parse(s, null, new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip });
                if (name == "fabric.mod.json") return (j?["id"]?.ToString(), j?["name"]?.ToString());
                var meta = j?["quilt_loader"];
                return (meta?["id"]?.ToString(), meta?["metadata"]?["name"]?.ToString());
            }
            foreach (var toml in new[] { "META-INF/mods.toml", "META-INF/neoforge.mods.toml" })
            {
                var e = zip.GetEntry(toml);
                if (e is null) continue;
                using var r = new StreamReader(e.Open());
                var t = r.ReadToEnd();
                var id = Regex.Match(t, "modId\\s*=\\s*\"([^\"]+)\"").Groups[1].Value;
                var nm = Regex.Match(t, "displayName\\s*=\\s*\"([^\"]+)\"").Groups[1].Value;
                return (id.Length > 0 ? id : null, nm.Length > 0 ? nm : null);
            }
        }
        catch { }
        return (null, null);
    }

    private static string Norm(string? s) => s is null ? "" : new string(s.Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant();

    public static List<string> FindConfigs(string instancePath, string? id, string? name, string jarFileName)
    {
        var result = new List<string>();
        var dir = Path.Combine(instancePath, "config");
        if (!Directory.Exists(dir)) return result;
        var stemOfJar = Regex.Replace(Path.GetFileNameWithoutExtension(jarFileName.Replace(".disabled", "")), @"[-_+]?\d.*$", "");
        var keys = new[] { Norm(id), Norm(name), Norm(stemOfJar) }.Where(k => k.Length >= 3).Distinct().ToList();
        if (keys.Count == 0) return result;
        try
        {
            foreach (var f in Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories))
            {
                if (!ConfigDocument.SupportedExtensions.Contains(Path.GetExtension(f).ToLowerInvariant())) continue;
                if (f.EndsWith(".z4bak", StringComparison.OrdinalIgnoreCase)) continue;
                var rel = Path.GetRelativePath(dir, f);
                if (rel.Count(c => c is '\\' or '/') > 2) continue;
                var stem = Norm(Path.GetFileNameWithoutExtension(f));
                var folder = rel.Contains('\\') || rel.Contains('/') ? Norm(Path.GetFileName(Path.GetDirectoryName(f))) : "";
                var hit = keys.Any(k => (stem.Length >= 3 && (stem.Contains(k) || k.Contains(stem))) ||
                                        (folder.Length >= 3 && (folder.Contains(k) || k.Contains(folder))));
                if (hit) result.Add(f);
            }
        }
        catch { }
        return result.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
    }
}
