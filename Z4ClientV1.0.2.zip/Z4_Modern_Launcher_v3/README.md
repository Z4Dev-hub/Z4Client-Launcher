# Z4 Modern Launcher (v3)

Modern WPF launcher UI: animated gradient background, vector cube logo, page transitions,
premade instances, in-app instance manager with drag-and-drop, Modrinth/CurseForge search with icons.

## Build
1. Install the .NET SDK 10 or newer (Windows).
2. Run `BUILD_EXE.bat` -> `dist\Z4ModernLauncher.exe` (keep the dist folder together).
3. Problems? `RUN_DEBUG.bat`, and `%LOCALAPPDATA%\Z4ModernLauncher\startup.log`.

## Make a real installer (Z4ClientSetup.exe)
Run `BUILD_INSTALLER.bat` once on your PC. It publishes the launcher and builds `installer\output\Z4ClientSetup.exe`
with Inno Setup (it offers to install Inno Setup via winget). Friends only need that one exe: it installs to
`C:\Z4Client` (folder is created if missing), adds Start menu/Desktop shortcuts and an entry in Windows
"Installed apps" for uninstalling. No .NET SDK needed on their PCs. Instances and sign-in are kept on uninstall.

## Browsing mods, shaders, packs
Opening a browser page (Mods, Shaders, Resource packs, Datapacks) immediately lists the **most popular** projects on
Modrinth (by downloads) or CurseForge (by popularity), already filtered to the Minecraft version and loader of the
instance in "Install into" (falls back to unfiltered if nothing matches). Type to search instead; switching the
source or the target instance refreshes the list. Download counts are shown as 1.2M / 340K.

## Skin & Cape
Open **Skin & Cape** (signed in). The left card shows your character (drawn from the real skin file, front view with
layers). **Skins:** your library lives in `%APPDATA%\Z4Launcher\skins` (your current skin is saved there automatically).
Add PNGs (64x64), pick one to preview, choose Classic/Slim and press *Use this skin*; *Reset to default* is there too.
**Capes:** all capes your account owns are listed; pick one and press *Equip*, or *No cape*.

## Z4 Client pack (in-game)
Create dialog -> Preinstalled mods -> **Z4 Client**, or **Add Z4 Client pack** inside any Fabric instance. It downloads from Modrinth:
Fabric API, Sodium, Lithium, FerriteCore, Entity Culling, ImmediatelyFast, Dynamic FPS, Krypton (FPS), 3D Skin Layers,
Simple Voice Chat and Mod Menu. On the first launch the launcher binds **Right Shift** to Mod Menu (only that one options.txt
line is added, video settings are untouched), so in singleplayer or multiplayer Right Shift opens the list of installed mods.
Voice chat also needs the Simple Voice Chat mod/plugin on the server you join.

## Animations
The window fades/scales in and out (open, close, minimize, restore); the create window and opened instances animate in and out too.

## Mod switches and options
In an instance's Mods tab every mod has an **on/off switch** (renames the jar to .disabled, nothing is deleted) and a **gear**
button. The gear opens a window with that mod's options read from its file in `config/` (Fabric/Forge `.json`, `.json5`,
`.properties`, `.toml`): switches for true/false, sliders + number boxes for values like distance/range, text boxes for text.
Search box included. Saving keeps comments in .properties/.toml files, writes a one-time `.z4bak` backup, and applies after
a game restart. A mod only has a config file after its first launch, and mods that keep options in-game only won't list any.

## Auto-updates
The launcher checks for a new version 4 seconds after start (Settings -> Updates can turn that off, or check manually).
If one exists, an in-app window shows what's new; **Update now** downloads it (checksum verified when provided), closes the
launcher, copies the new files over the old ones and starts it again. Instances, skins and settings are never touched.
**Setup for you (once):** put your update source in `UpdateConfig.DefaultUrl` (Updater.cs) before building the installer, e.g.
`https://api.github.com/repos/Z4Dev-hub/Z4Client-Launcher/releases/latest` (already set; the repo must be public). **For every new version:** raise `<Version>` in
Z4ModernLauncher.csproj, run `MAKE_UPDATE.bat` (it makes a SMALL `release\Z4Client-<version>-patch.zip` with only the files that
changed since the installer build, usually a few MB) and upload that as a GitHub release tagged `v<version>`
(or host the zip + update.json yourself). `BUILD_INSTALLER.bat` stores `baseline.json` (hashes of the installer files); commit it to your repo.
If you publish a new installer, run `MAKE_UPDATE.bat -ResetBaseline` once. Friends get it automatically. Builds made before this feature must be reinstalled once.

## Community
The sidebar has a **Join our Discord** button (https://discord.gg/Uabq8nXReb).

## Create instance (in-app window)
Instances page -> **Create**. A window opens inside the launcher: name + icon (generic block icon or any image from your PC),
**Which version?** (releases, optional snapshots), **Which launcher?** (Vanilla / Fabric / Quilt / Forge / NeoForge) with a
**Launcher version** list (Latest or a specific loader version), and **Preinstalled mods?** (None / Performance / Shader Ready /
Explorer; these are Fabric packs). Inside an opened instance you can change version, loader, loader version and icon later.
Forge/NeoForge versions can be chosen and stored, but launching them is not supported yet (Vanilla, Fabric, Quilt launch).

## Logos, screenshots, window
* Installed mods, resource packs and worlds show their own logo; online results use project icons (WebP is converted).
* **Screenshots** page (sidebar): all screenshots of all instances, filter per instance, open/delete. Every instance also has a Screenshots tab.
* **Skin & Cape**: a 3D character you can drag to rotate (wheel = zoom, double-click = reset); selecting a cape shows it on the back.
* **F11** maximizes to the work area (the taskbar stays visible). When the window is big, the whole UI scales up.
* **Transparent window**: Settings -> Window effect (Acrylic / Mica / Off) and Transparency slider. Panels and backgrounds are
  see-through with a blur; buttons and inputs stay solid. Needs Windows 10/11.

## Instances
Stored in `%APPDATA%\Z4Launcher\instances\<name>\` (changeable in Settings).
* **Premade instances** (Vanilla, Performance, Shader Ready, Explorer): one click creates the instance and
  downloads the mods/shaders from Modrinth for the newest Minecraft version Fabric supports.
* **Open an instance inside the launcher** (double-click or "Open instance"): tabs for Mods, Shaders,
  Resource packs, Datapacks, Worlds. Drag files in, "Add files", enable/disable (.disabled), remove,
  or "Browse online". No Explorer needed.
* Everything installed from the Mods / Shaders / Resource packs / Datapacks / Worlds pages goes into the
  active instance (loader + game version are respected for mods).

## Sign-in (Minecraft x Microsoft x Xbox, inside the launcher)
"Sign in" opens a Microsoft login popup inside the launcher (Edge WebView2, preinstalled on Windows 10/11).
After you sign in, the launcher does Xbox Live -> XSTS -> Minecraft services and shows your profile.
Your password only goes to Microsoft. The refresh token is stored encrypted (Windows DPAPI).

### No Azure setup needed (friends-only mode)
Leave `AuthConfig.DefaultClientId` empty and the launcher signs in through CmlLib.Core's built-in Microsoft login
(`DefaultAuth.cs`). Players just click "Sign in" and use their own Microsoft account. Note: this relies on the
library's shared app ID, which is fine for a small private group but could be restricted by Microsoft/Mojang at any time.

### Optional: your own app ID (for public distribution)
Register an app in the Azure portal (personal accounts, public client, redirect `https://login.live.com/oauth20_desktop.srf`),
get Mojang approval at https://aka.ms/AppRegInfo, then put the ID in `AuthConfig.DefaultClientId` (or `"azureClientId"`
in the settings file). When set, the launcher uses its own login flow instead.

## Playing
Sign in, open **Instances**, select an instance and press **Play** (also inside the opened instance).
* First launch downloads the game files, assets and a matching Java automatically (CmlLib.Core).
* **Vanilla, Fabric and Quilt** instances are supported. Forge/NeoForge are not launchable yet.
* Libraries/assets/Java/versions are shared between instances (stored once in `%APPDATA%\Z4Launcher\shared`),
  so each instance only holds its own mods, worlds and settings. (No folder junctions are used.)
* RAM is set in Settings (default 4096 MB). If the game crashes, the launcher points you to `logs\latest.log`.

* **Version per instance:** pick it when creating an instance, change it later inside the opened instance
  ("Change version", affects only that instance), and choose it for premade instances above the premade cards.
* Faster downloads: game files download with higher parallelism, premade mods download 4 at a time, and the
  Fabric/Quilt profile is cached after the first launch.

* **Performance (video settings are never touched):** tuned garbage-collector JVM flags for smoother frame times,
  a larger starting heap, game process priority above normal, and the launcher minimizes and lowers its own
  priority while you play (its animations don't compete for CPU/GPU).
* **Temp cleanup:** before each launch (and via "Clean temp files") logs older than 7 days, crash reports older than
  14 days, Java crash dumps, `*.tmp`/`*.part` files and the launcher's own oversized error log are removed.
  Worlds, mods, screenshots, options.txt and shader/resource packs are never deleted.

Not included yet: Forge/NeoForge launching, skin/cape upload.
