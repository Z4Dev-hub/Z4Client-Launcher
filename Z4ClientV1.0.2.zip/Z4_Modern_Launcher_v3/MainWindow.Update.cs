using System.IO;
using System.Windows;
using System.Windows.Media.Animation;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private bool _autoUpdate = true;
    private string _updateUrl = "";
    private UpdateInfo? _update;
    private bool _updating;

    private string EffectiveUpdateUrl => string.IsNullOrWhiteSpace(_updateUrl) ? UpdateConfig.DefaultUrl : _updateUrl.Trim();

    private void InitUpdateUi()
    {
        VersionText.Text = $"Z4 Client {UpdateService.CurrentText}";
        AutoUpdateBox.IsChecked = _autoUpdate;
        UpdateUrlBox.Text = _updateUrl;
        try
        {
            var failed = Path.Combine(AppContext.BaseDirectory, "update_failed.txt");
            if (File.Exists(failed))
            {
                File.Delete(failed);
                SetStatus("The last update could not be installed. Run the Z4 Client setup again.");
            }
        }
        catch { }
    }

    /// <summary>Quiet check a few seconds after start (only when enabled and a source is set).</summary>
    private async Task StartupUpdateCheckAsync()
    {
        if (!_autoUpdate || string.IsNullOrEmpty(EffectiveUpdateUrl)) return;
        await Task.Delay(4000);
        await CheckForUpdatesAsync(manual: false);
    }

    private async Task CheckForUpdatesAsync(bool manual)
    {
        if (_updating) return;
        var url = EffectiveUpdateUrl;
        if (string.IsNullOrEmpty(url))
        {
            if (manual) SetStatus("No update source is set yet. Enter one under Settings → Updates.");
            return;
        }
        try
        {
            if (manual) SetStatus("Checking for updates…");
            var info = await UpdateService.CheckAsync(url);
            if (info is null)
            {
                if (manual) SetStatus($"You're up to date (version {UpdateService.CurrentText}).");
                return;
            }
            _update = info;
            ShowUpdateOverlay(info);
        }
        catch (Exception ex)
        {
            Program.Log("Update check", ex.Message);
            if (manual) SetStatus("Could not check for updates: " + ex.Message);
        }
    }

    private void ShowUpdateOverlay(UpdateInfo info)
    {
        UpdateTitle.Text = $"Version {info.VersionText} is available";
        UpdateSubtitle.Text = $"You have {UpdateService.CurrentText}. The launcher downloads the update and restarts itself. Your instances and settings are kept.";
        UpdateNotes.Text = string.IsNullOrWhiteSpace(info.Notes) ? "No release notes." : info.Notes;
        UpdateStatusText.Text = "";
        UpdateProgress.Value = 0;
        UpdateProgress.Visibility = Visibility.Collapsed;
        UpdateNowButton.IsEnabled = true;
        UpdateLaterButton.IsEnabled = true;
        UpdateOverlay.Opacity = 0;
        UpdateOverlay.Visibility = Visibility.Visible;
        UpdateOverlay.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180)));
    }

    private void UpdateLater_Click(object sender, RoutedEventArgs e)
    {
        if (_updating) return;
        UpdateOverlay.Visibility = Visibility.Collapsed;
        SetStatus($"Update {_update?.VersionText} is waiting. Settings → Updates installs it any time.");
    }

    private async void UpdateNow_Click(object sender, RoutedEventArgs e)
    {
        if (_update is null || _updating) return;
        if (_playing)
        {
            MessageBox.Show(this, "Close Minecraft first, then update.", "Update", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        _updating = true;
        UpdateNowButton.IsEnabled = false;
        UpdateLaterButton.IsEnabled = false;
        UpdateProgress.Visibility = Visibility.Visible;
        try
        {
            UpdateService.EnsureWritable();
            UpdateStatusText.Text = "Downloading…";
            var staged = await UpdateService.DownloadAsync(_update, p => Dispatcher.BeginInvoke(() =>
            {
                UpdateProgress.Value = p * 100;
                UpdateStatusText.Text = $"Downloading… {p:P0}";
            }));
            UpdateStatusText.Text = "Installing… the launcher restarts in a moment.";
            UpdateService.ApplyAndRestart(staged);
            await Task.Delay(600);
            Close();                                                    // the helper replaces the files once we have exited
        }
        catch (Exception ex)
        {
            Program.Log("Update", ex.ToString());
            UpdateStatusText.Text = "Update failed: " + ex.Message;
            UpdateNowButton.Content = "Try again";
            UpdateNowButton.IsEnabled = true;
            UpdateLaterButton.IsEnabled = true;
            UpdateProgress.Visibility = Visibility.Collapsed;
            _updating = false;
        }
    }

    private async void CheckUpdates_Click(object sender, RoutedEventArgs e)
    {
        _updateUrl = UpdateUrlBox.Text.Trim();
        _autoUpdate = AutoUpdateBox.IsChecked == true;
        await CheckForUpdatesAsync(manual: true);
    }
}
