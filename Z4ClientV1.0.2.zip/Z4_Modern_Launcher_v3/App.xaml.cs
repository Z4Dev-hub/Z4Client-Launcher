using System.Windows;
using System.Windows.Threading;

namespace Z4ModernLauncher;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += OnDispatcherException;
        base.OnStartup(e);
        Program.Log("App", "OnStartup - creating main window");
        var window = new MainWindow();
        MainWindow = window;
        window.Show();
        Program.Log("App", "Main window shown");
    }

    private static void OnDispatcherException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        Program.Log("Dispatcher exception", e.Exception.ToString());
        Program.ShowFatal(e.Exception.GetType().Name + ": " + e.Exception.Message);
        e.Handled = true;
    }
}
