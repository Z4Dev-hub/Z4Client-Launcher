using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private readonly ObservableCollection<ShotItem> _shots = new();
    private bool _shotsInit;

    private async Task RefreshShotsPageAsync()
    {
        if (!_shotsInit) { ShotsList.ItemsSource = _shots; _shotsInit = true; }
        var keep = ShotsFilterBox.SelectedItem as string;
        var names = new List<string> { "All instances" };
        names.AddRange(_instances.Select(i => i.Name));
        ShotsFilterBox.ItemsSource = names;
        ShotsFilterBox.SelectedItem = keep is not null && names.Contains(keep) ? keep : names[0];
        await LoadShotsAsync();
    }

    private async void ShotsFilter_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_ready && _shotsInit && ReferenceEquals(_currentPage, ScreenshotsPanel)) await LoadShotsAsync();
    }

    private async Task LoadShotsAsync()
    {
        var filter = ShotsFilterBox.SelectedItem as string;
        var targets = _instances.Where(i => filter is null or "All instances" || i.Name == filter).Select(i => (i.Name, i.Path)).ToList();
        var items = await Task.Run(() =>
        {
            var list = new List<ShotItem>();
            foreach (var (name, path) in targets)
            {
                try
                {
                    var dir = Path.Combine(path, "screenshots");
                    if (!Directory.Exists(dir)) continue;
                    foreach (var f in Directory.EnumerateFiles(dir))
                    {
                        var ext = Path.GetExtension(f).ToLowerInvariant();
                        if (ext is ".png" or ".jpg" or ".jpeg") list.Add(new ShotItem(f, name, File.GetLastWriteTime(f)));
                    }
                }
                catch { }
            }
            return list.OrderByDescending(s => s.Time).ToList();
        });
        _shots.Clear();
        foreach (var s in items) _shots.Add(s);
        ShotsEmpty.Visibility = _shots.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        ShotsCount.Text = $"{_shots.Count} screenshot(s)";
    }

    private static void OpenPath(string path)
    {
        try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); } catch { }
    }

    private void ShotsList_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (ShotsList.SelectedItem is ShotItem s) OpenPath(s.Path);
    }

    private void ShotsOpen_Click(object sender, RoutedEventArgs e)
    {
        if (ShotsList.SelectedItem is ShotItem s) OpenPath(s.Path); else SetStatus("Select a screenshot first.");
    }

    private void ShotsOpenFolder_Click(object sender, RoutedEventArgs e)
    {
        var picked = ShotsList.SelectedItem as ShotItem ?? _shots.FirstOrDefault();
        var inst = ShotsFilterBox.SelectedItem is string n && n != "All instances" ? _instances.FirstOrDefault(i => i.Name == n) : null;
        inst ??= picked is null ? ActiveInstance : _instances.FirstOrDefault(i => i.Name == picked.Instance);
        if (inst is null) { SetStatus("No instance selected."); return; }
        var dir = Path.Combine(inst.Path, "screenshots");
        Directory.CreateDirectory(dir);
        OpenPath(dir);
    }

    private async void ShotsDelete_Click(object sender, RoutedEventArgs e)
    {
        var picked = ShotsList.SelectedItems.OfType<ShotItem>().ToList();
        if (picked.Count == 0) { SetStatus("Select screenshots to delete first."); return; }
        if (MessageBox.Show(this, $"Delete {picked.Count} screenshot(s)? This cannot be undone.", "Delete screenshots",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        foreach (var s in picked)
        {
            try { File.Delete(s.Path); } catch (Exception ex) { SetStatus("Could not delete: " + ex.Message); }
        }
        await LoadShotsAsync();
    }
}
