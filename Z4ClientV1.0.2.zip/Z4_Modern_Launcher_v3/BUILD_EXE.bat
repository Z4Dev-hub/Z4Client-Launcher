@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET SDK not found. Install the .NET 10 SDK or newer: https://dotnet.microsoft.com/download
  pause & exit /b 1
)
dotnet --list-sdks | findstr /r /b "10\. 11\. 12\." >nul
if errorlevel 1 (
  echo No .NET SDK 10 or newer was detected. Installed SDKs:
  dotnet --list-sdks
  pause & exit /b 1
)
if exist dist rmdir /s /q dist
echo Building self-contained app (no .NET runtime install needed to run it)...
dotnet publish Z4ModernLauncher.csproj -c Release -r win-x64 --self-contained true -o dist
if errorlevel 1 (
  echo.
  echo Build failed. Read the error above.
  pause & exit /b 1
)
echo.
echo Built: dist\Z4ModernLauncher.exe
echo Keep the whole "dist" folder together. You can make a shortcut to the exe.
echo If it does not open, read: %%LOCALAPPDATA%%\Z4ModernLauncher\startup.log
pause
