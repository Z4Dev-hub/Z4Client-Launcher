using System.Collections.ObjectModel;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Threading;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private readonly ObservableCollection<SkinFile> _skins = new();
    private readonly ObservableCollection<CapeItem> _capes = new();
    private bool _profileLoading, _profileOp, _activeSlim;

    private static string SkinsDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Z4Launcher", "skins");

    private void InitProfile()
    {
        SkinList.ItemsSource = _skins;
        CapeList.ItemsSource = _capes;
        InitViewer();
    }

    // ---------------------------------------------------------------- 3D character (drag to rotate, wheel to zoom)
    private readonly AxisAngleRotation3D _yaw = new(new Vector3D(0, 1, 0), 25);
    private readonly AxisAngleRotation3D _pitch = new(new Vector3D(1, 0, 0), 0);
    private ModelVisual3D? _charVisual;
    private BitmapSource? _viewerSkin, _viewerCape;
    private bool _viewerSlim, _viewerDrag;
    private Point _viewerLast;
    private DateTime _viewerTouched = DateTime.MinValue;

    private void InitViewer()
    {
        var lights = new ModelVisual3D
        {
            Content = new Model3DGroup
            {
                Children =
                {
                    new AmbientLight(Color.FromRgb(0xB0, 0xB0, 0xB0)),
                    new DirectionalLight(Color.FromRgb(0x80, 0x80, 0x80), new Vector3D(-0.4, -0.6, -1))
                }
            }
        };
        var transform = new Transform3DGroup();
        transform.Children.Add(new RotateTransform3D(_yaw, new Point3D(0, 16, 0)));
        transform.Children.Add(new RotateTransform3D(_pitch, new Point3D(0, 16, 0)));
        _charVisual = new ModelVisual3D { Transform = transform };
        SkinViewport.Children.Add(lights);
        SkinViewport.Children.Add(_charVisual);

        var spin = new DispatcherTimer(DispatcherPriority.Render) { Interval = TimeSpan.FromMilliseconds(33) };
        spin.Tick += (_, _) =>
        {
            if (_viewerDrag || !ProfilePanel.IsVisible) return;
            if ((DateTime.UtcNow - _viewerTouched).TotalSeconds < 2.5) return;   // pause right after you moved it
            _yaw.Angle = (_yaw.Angle + 0.8) % 360;
        };
        spin.Start();
    }

    private void RebuildViewer()
    {
        if (_charVisual is null || _viewerSkin is null) return;
        try { _charVisual.Content = SkinViewer3D.Build(_viewerSkin, _viewerSlim, _viewerCape); }
        catch (Exception ex) { Program.Log("Viewer", ex.Message); }
    }

    private void SetViewerSkin(byte[] png, bool slim)
    {
        var bmp = ImageHelper.Decode(png);
        if (bmp is null) return;
        _viewerSkin = bmp;
        _viewerSlim = slim;
        RebuildViewer();
    }

    private async Task SetViewerCapeAsync(string? url)
    {
        _viewerCape = string.IsNullOrEmpty(url) ? null : await Task.Run(() => ImageHelper.FromUrl(url));
        RebuildViewer();
    }

    private void Viewer_Down(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) { _yaw.Angle = 25; _pitch.Angle = 0; SkinCamera.Position = new Point3D(0, 16, 72); return; }
        _viewerDrag = true;
        _viewerLast = e.GetPosition(ViewerHost);
        ViewerHost.CaptureMouse();
    }

    private void Viewer_Move(object sender, System.Windows.Input.MouseEventArgs e)
    {
        if (!_viewerDrag) return;
        var p = e.GetPosition(ViewerHost);
        _yaw.Angle += (p.X - _viewerLast.X) * 0.9;
        _pitch.Angle = Math.Clamp(_pitch.Angle + (p.Y - _viewerLast.Y) * 0.5, -40, 40);
        _viewerLast = p;
        _viewerTouched = DateTime.UtcNow;
    }

    private void Viewer_Up(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        _viewerDrag = false;
        _viewerTouched = DateTime.UtcNow;
        ViewerHost.ReleaseMouseCapture();
    }

    private void Viewer_Wheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
    {
        var z = Math.Clamp(SkinCamera.Position.Z - e.Delta / 40.0, 38, 130);
        SkinCamera.Position = new Point3D(0, 16, z);
        _viewerTouched = DateTime.UtcNow;
        e.Handled = true;
    }

    private async void CapeList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (CapeList.SelectedItem is CapeItem cape) await SetViewerCapeAsync(cape.Url);
    }

    private async Task RefreshProfilePageAsync()
    {
        var signedIn = _session is not null;
        ProfileSignedOut.Visibility = signedIn ? Visibility.Collapsed : Visibility.Visible;
        ProfileSignedIn.Visibility = signedIn ? Visibility.Visible : Visibility.Collapsed;
        if (signedIn) await LoadProfileAsync();
    }

    // ---------------------------------------------------------------- Minecraft services API
    private async Task<string> McAsync(HttpMethod method, string path, HttpContent? content = null)
    {
        var s = await EnsureFreshSessionAsync();
        _session = s;
        using var req = new HttpRequestMessage(method, "https://api.minecraftservices.com" + path) { Content = content };
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", s.AccessToken);
        using var resp = await Http.SendAsync(req);
        var body = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
            throw new Exception($"Minecraft services returned {(int)resp.StatusCode}. {(body.Length > 200 ? body[..200] : body)}");
        return body;
    }

    private async Task LoadProfileAsync()
    {
        if (_profileLoading || _session is null) return;
        _profileLoading = true;
        try
        {
            ProfileName.Text = _session.Name;
            ProfileStatus.Text = "Loading your profile…";
            var profile = JsonNode.Parse(await McAsync(HttpMethod.Get, "/minecraft/profile"))!;

            var activeSkin = profile["skins"]?.AsArray().FirstOrDefault(x => x?["state"]?.ToString() == "ACTIVE");
            _activeSlim = string.Equals(activeSkin?["variant"]?.ToString(), "SLIM", StringComparison.OrdinalIgnoreCase);
            VariantSlim.IsChecked = _activeSlim;
            VariantClassic.IsChecked = !_activeSlim;

            _capes.Clear();
            foreach (var c in profile["capes"]?.AsArray() ?? new JsonArray())
            {
                if (c is null) continue;
                _capes.Add(new CapeItem(c["id"]?.ToString() ?? "", c["alias"]?.ToString() ?? "Cape",
                    c["url"]?.ToString() ?? "", c["state"]?.ToString() == "ACTIVE"));
            }
            NoCapesText.Visibility = _capes.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

            var skinUrl = activeSkin?["url"]?.ToString();
            if (!string.IsNullOrEmpty(skinUrl))
            {
                var bytes = await Http.GetByteArrayAsync(skinUrl);
                SetViewerSkin(bytes, _activeSlim);
                try   // keep a copy of the current skin in the library so you can always switch back
                {
                    Directory.CreateDirectory(SkinsDir);
                    var id = (activeSkin?["id"]?.ToString() ?? "skin").Replace("-", "");
                    var file = Path.Combine(SkinsDir, $"Current_{id[..Math.Min(8, id.Length)]}.png");
                    if (!File.Exists(file)) File.WriteAllBytes(file, bytes);
                }
                catch (Exception ex) { Program.Log("Save current skin", ex.Message); }
            }
            LoadSkinLibrary();
            await SetViewerCapeAsync(_capes.FirstOrDefault(c => c.Active)?.Url);
            ProfileStatus.Text = $"{(_activeSlim ? "Slim" : "Classic")} skin • {_capes.Count} cape(s) on this account";
        }
        catch (Exception ex)
        {
            Program.Log("LoadProfile", ex.ToString());
            ProfileStatus.Text = "Could not load your profile: " + ex.Message;
        }
        finally { _profileLoading = false; }
    }

    private void LoadSkinLibrary(string? select = null)
    {
        Directory.CreateDirectory(SkinsDir);
        _skins.Clear();
        foreach (var f in Directory.EnumerateFiles(SkinsDir, "*.png").OrderByDescending(x => File.GetLastWriteTimeUtc(x)))
        {
            var stem = Path.GetFileNameWithoutExtension(f);
            _skins.Add(new SkinFile(stem.StartsWith("Current_") ? "Current skin" : stem, f));
        }
        if (select is not null) SkinList.SelectedItem = _skins.FirstOrDefault(x => x.Path == select);
    }

    // ---------------------------------------------------------------- skins
    private static string? ValidateSkin(byte[] bytes)
    {
        var bmp = ImageHelper.Decode(bytes);
        if (bmp is null) return "That file is not a valid PNG image.";
        if (bmp.PixelWidth != 64 || (bmp.PixelHeight != 64 && bmp.PixelHeight != 32))
            return $"Minecraft skins must be 64×64 pixels (or the old 64×32). This one is {bmp.PixelWidth}×{bmp.PixelHeight}.";
        return null;
    }

    private void AddSkin_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "Minecraft skin (*.png)|*.png", Title = "Choose a skin" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            var bytes = File.ReadAllBytes(dlg.FileName);
            var err = ValidateSkin(bytes);
            if (err is not null) { MessageBox.Show(this, err, "Skin", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            Directory.CreateDirectory(SkinsDir);
            var target = UniquePath(Path.Combine(SkinsDir, Path.GetFileName(dlg.FileName)));
            File.WriteAllBytes(target, bytes);
            LoadSkinLibrary(target);
            SetStatus("Skin added to your library. Press \"Use this skin\" to wear it.");
        }
        catch (Exception ex) { SetStatus("Could not add the skin: " + ex.Message); }
    }

    private void SkinList_SelectionChanged(object sender, SelectionChangedEventArgs e) => PreviewSelectedSkin();
    private void Variant_Changed(object sender, RoutedEventArgs e) { if (_ready && SkinViewport is not null) PreviewSelectedSkin(); }

    private void PreviewSelectedSkin()
    {
        if (SkinList.SelectedItem is not SkinFile skin) return;
        try
        {
            SetViewerSkin(File.ReadAllBytes(skin.Path), VariantSlim.IsChecked == true);
            ProfileStatus.Text = $"Preview: {skin.Name} — press \"Use this skin\" to wear it.";
        }
        catch { }
    }

    private async void ApplySkin_Click(object sender, RoutedEventArgs e)
    {
        if (SkinList.SelectedItem is not SkinFile skin) { SetStatus("Pick a skin from your library first."); return; }
        var slim = VariantSlim.IsChecked == true;
        await ProfileOpAsync("Uploading skin…", async () =>
        {
            var bytes = File.ReadAllBytes(skin.Path);
            var err = ValidateSkin(bytes);
            if (err is not null) throw new Exception(err);
            using var form = new MultipartFormDataContent();
            form.Add(new StringContent(slim ? "slim" : "classic"), "variant");
            var file = new ByteArrayContent(bytes);
            file.Headers.ContentType = new MediaTypeHeaderValue("image/png");
            form.Add(file, "file", "skin.png");
            await McAsync(HttpMethod.Post, "/minecraft/profile/skins", form);
        }, "Skin changed. It can take a minute to show up in game.");
    }

    private void SkinList_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e) => ApplySkin_Click(sender, e);

    private async void ResetSkin_Click(object sender, RoutedEventArgs e)
    {
        if (MessageBox.Show(this, "Reset your skin to the default Steve/Alex skin?", "Reset skin", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        await ProfileOpAsync("Resetting skin…", () => McAsync(HttpMethod.Delete, "/minecraft/profile/skins/active"), "Skin reset to default.");
    }

    private void DeleteSkin_Click(object sender, RoutedEventArgs e)
    {
        if (SkinList.SelectedItem is not SkinFile skin) { SetStatus("Pick a skin from your library first."); return; }
        if (MessageBox.Show(this, $"Remove \"{skin.Name}\" from your library? (Your account's current skin is not changed.)", "Remove skin",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        try { File.Delete(skin.Path); LoadSkinLibrary(); SetStatus("Skin removed from the library."); }
        catch (Exception ex) { SetStatus("Could not remove: " + ex.Message); }
    }

    // ---------------------------------------------------------------- capes
    private async void EquipCape_Click(object sender, RoutedEventArgs e)
    {
        if (CapeList.SelectedItem is not CapeItem cape) { SetStatus("Pick a cape first."); return; }
        var json = new JsonObject { ["capeId"] = cape.Id }.ToJsonString();
        await ProfileOpAsync("Equipping cape…",
            () => McAsync(HttpMethod.Put, "/minecraft/profile/capes/active", new StringContent(json, Encoding.UTF8, "application/json")),
            $"Cape \"{cape.Alias}\" equipped.");
    }

    private void CapeList_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e) => EquipCape_Click(sender, e);

    private async void HideCape_Click(object sender, RoutedEventArgs e) =>
        await ProfileOpAsync("Removing cape…", () => McAsync(HttpMethod.Delete, "/minecraft/profile/capes/active"), "Cape hidden.");

    private async Task ProfileOpAsync(string busy, Func<Task> op, string done)
    {
        if (_profileOp) return;
        _profileOp = true;
        try
        {
            SetStatus(busy);
            SetBusy(true);
            await op();
            SetStatus(done);
        }
        catch (Exception ex)
        {
            Program.Log("Profile op", ex.ToString());
            SetStatus("Failed.");
            MessageBox.Show(this, ex.Message, "Skin & Cape", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            SetBusy(false);
            _profileOp = false;
        }
        await LoadProfileAsync();
    }
}
