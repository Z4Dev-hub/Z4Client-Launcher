using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;

namespace Z4ModernLauncher;

/// <summary>Blur-behind window backgrounds: Mica / Acrylic on Windows 11, blur-behind on Windows 10.</summary>
internal static class WindowEffects
{
    [StructLayout(LayoutKind.Sequential)] private struct Margins { public int L, R, T, B; }
    [StructLayout(LayoutKind.Sequential)] private struct AccentPolicy { public int State, Flags, Gradient, Animation; }
    [StructLayout(LayoutKind.Sequential)] private struct CompositionData { public int Attribute; public IntPtr Data; public int Size; }

    [DllImport("dwmapi.dll")] private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
    [DllImport("dwmapi.dll")] private static extern int DwmExtendFrameIntoClientArea(IntPtr hwnd, ref Margins m);
    [DllImport("user32.dll")] private static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref CompositionData data);

    /// <summary>Returns true when a see-through blurred background is active.</summary>
    public static bool Apply(Window window, string effect)
    {
        var hwnd = new WindowInteropHelper(window).Handle;
        if (hwnd == IntPtr.Zero) return false;
        var src = HwndSource.FromHwnd(hwnd);
        var build = Environment.OSVersion.Version.Build;

        var dark = 1;
        DwmSetWindowAttribute(hwnd, 20, ref dark, 4);                       // dark title/frame

        if (effect == "none" || build < 17134)
        {
            if (src?.CompositionTarget is not null) src.CompositionTarget.BackgroundColor = Color.FromRgb(0x0A, 0x0C, 0x12);
            if (build >= 22621) { var none = 1; DwmSetWindowAttribute(hwnd, 38, ref none, 4); }
            SetAccent(hwnd, 0);
            return false;
        }

        if (src?.CompositionTarget is not null) src.CompositionTarget.BackgroundColor = Colors.Transparent;
        var m = new Margins { L = -1, R = -1, T = -1, B = -1 };
        DwmExtendFrameIntoClientArea(hwnd, ref m);

        if (build >= 22621)
        {
            var type = effect == "mica" ? 2 : 3;                            // 2 = Mica, 3 = Acrylic
            return DwmSetWindowAttribute(hwnd, 38, ref type, 4) == 0;
        }
        SetAccent(hwnd, 3);                                                  // Windows 10: blur behind
        return true;
    }

    private static void SetAccent(IntPtr hwnd, int state)
    {
        try
        {
            var policy = new AccentPolicy { State = state, Flags = 2, Gradient = 0x01000000 };
            var size = Marshal.SizeOf(policy);
            var ptr = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(policy, ptr, false);
                var data = new CompositionData { Attribute = 19, Data = ptr, Size = size };
                SetWindowCompositionAttribute(hwnd, ref data);
            }
            finally { Marshal.FreeHGlobal(ptr); }
        }
        catch { }
    }
}
