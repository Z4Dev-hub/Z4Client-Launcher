using System.Windows;
using System.Windows.Media.Imaging;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private MinecraftSession? _session;
    private bool _signingIn;

    private async void SignIn_Click(object s, RoutedEventArgs e)
    {
        if (_session is not null) { SignOut(); return; }
        await BeginLoginAsync();
    }

    private async Task BeginLoginAsync()
    {
        if (_signingIn) return;
        var clientId = AuthConfig.ClientId;
        var useDefault = string.IsNullOrWhiteSpace(clientId);

        _signingIn = true;
        AccountButton.IsEnabled = false;
        try
        {
            if (useDefault)
            {
                SetStatus("Waiting for Microsoft sign-in…");
                var ds = await DefaultAuth.SignInAsync();
                ApplySession(ds);
                SetStatus($"Signed in as {ds.Name}");
                return;
            }

            var auth = new AuthService(Http, clientId);
            var (verifier, challenge) = AuthService.NewPkce();
            var state = Guid.NewGuid().ToString("N");

            SetStatus("Waiting for Microsoft sign-in…");
            var window = new LoginWindow(auth.BuildAuthorizeUrl(challenge, state), state) { Owner = this };
            window.ShowDialog();

            if (window.Error is not null)
            {
                MessageBox.Show(this, window.Error, "Sign-in", MessageBoxButton.OK, MessageBoxImage.Warning);
                SetStatus("Sign-in failed.");
                return;
            }
            if (window.Code is null) { SetStatus("Sign-in cancelled."); return; }

            SetStatus("Signing in to Xbox Live and Minecraft…");
            SetBusy(true);
            var session = await auth.CompleteWithCodeAsync(window.Code, verifier, CancellationToken.None);
            ApplySession(session);
            SetStatus($"Signed in as {session.Name}");
        }
        catch (Exception ex)
        {
            Program.Log("Login failed", ex.ToString());
            MessageBox.Show(this, ex.Message, "Sign-in failed", MessageBoxButton.OK, MessageBoxImage.Warning);
            SetStatus("Sign-in failed.");
        }
        finally
        {
            SetBusy(false);
            _signingIn = false;
            AccountButton.IsEnabled = true;
        }
    }

    private async Task TrySilentSignInAsync()
    {
        if (string.IsNullOrWhiteSpace(AuthConfig.ClientId))
        {
            AccountText.Text = "Signing in…";
            var saved = await DefaultAuth.TrySilentAsync();
            if (saved is null) { AccountText.Text = "Not signed in"; return; }
            ApplySession(saved);
            SetStatus($"Welcome back, {saved.Name}");
            return;
        }
        var token = AuthStore.Load();
        if (token is null) return;
        try
        {
            AccountText.Text = "Signing in…";
            var session = await new AuthService(Http, AuthConfig.ClientId).RefreshAsync(token, CancellationToken.None);
            ApplySession(session);
            SetStatus($"Welcome back, {session.Name}");
        }
        catch (Exception ex)
        {
            Program.Log("Silent sign-in failed", ex.Message);
            AccountText.Text = "Not signed in";
        }
    }

    private void ApplySession(MinecraftSession session)
    {
        _session = session;
        AuthStore.Save(session.RefreshToken);
        AccountText.Text = session.Name;
        AccountSub.Text = "Minecraft: Java Edition";
        AccountInitial.Text = session.Name.Length > 0 ? session.Name[..1].ToUpperInvariant() : "?";
        AccountButton.Content = "Sign out";
        try
        {
            AccountAvatar.Source = new BitmapImage(new Uri($"https://mc-heads.net/avatar/{session.Uuid}/72"));
        }
        catch { }
        Reveal(AccountText, 0, 8, 260, 0);
        if (ReferenceEquals(_currentPage, ProfilePanel)) _ = RefreshProfilePageAsync();
    }

    private void SignOut()
    {
        _session = null;
        AuthStore.Clear();
        _ = DefaultAuth.SignOutAsync();
        AccountText.Text = "Not signed in";
        AccountSub.Text = "Minecraft × Microsoft";
        AccountInitial.Text = "?";
        AccountAvatar.Source = null;
        AccountButton.Content = "Sign in";
        SetStatus("Signed out.");
        if (ReferenceEquals(_currentPage, ProfilePanel)) _ = RefreshProfilePageAsync();
    }
}
