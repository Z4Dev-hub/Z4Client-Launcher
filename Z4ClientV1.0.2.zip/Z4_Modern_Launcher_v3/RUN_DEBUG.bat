@echo off
cd /d "%~dp0"
echo Running from source so any error is shown here...
dotnet run -c Debug
echo.
echo Exit code: %errorlevel%
echo Log file: %LOCALAPPDATA%\Z4ModernLauncher\startup.log
pause
