using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Reflection;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using CmlLib.Core;
using CmlLib.Core.Auth;
using CmlLib.Core.ProcessBuilder;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private bool _playing;
    private int _ramMb = 4096;
    private DateTime _lastProgressUi = DateTime.MinValue;

    // libraries / assets / Java runtime / versions are shared by all instances (junctions), so each
    // instance only holds its own mods, worlds and settings instead of re-downloading ~1 GB.
    private static readonly string[] SharedFolders = { "libraries", "assets", "runtime", "versions" };
    private static string SharedRoot => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Z4Launcher", "shared");

    private async void Play_Click(object sender, RoutedEventArgs e)
    {
        if (_playing) return;
        var inst = InstanceDetailView.Visibility == Visibility.Visible ? _detail : ActiveInstance;
        if (inst is null) { SetStatus("Select an instance first."); return; }
        if (_session is null)
        {
            MessageBox.Show(this, "Sign in with your Microsoft account first (top left), then press Play.",
                "Sign in required", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (inst.Loader is "forge" or "neoforge")
        {
            MessageBox.Show(this, $"{inst.LoaderLabel} instances can't be launched yet. Vanilla, Fabric and Quilt work.",
                "Not supported yet", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (string.IsNullOrWhiteSpace(inst.Version) || inst.Version == "unspecified")
        {
            MessageBox.Show(this, "This instance has no Minecraft version set. Create a new instance and pick a version.",
                "No version", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        SetPlaying(true);
        try
        {
            SetStatus("Checking your sign-in…");
            var session = await EnsureFreshSessionAsync();
            _session = session;

            UnlinkSharedFolders(inst.Path);   // remove junctions an older version created (Windows blocks following them)

            var path = CreateMinecraftPath(inst.Path);
            var launcher = new MinecraftLauncher(path);
            TuneDownloads(launcher);
            launcher.FileProgressChanged += (_, args) =>
            {
                if ((DateTime.UtcNow - _lastProgressUi).TotalMilliseconds < 200) return;
                _lastProgressUi = DateTime.UtcNow;
                var name = args.Name;
                Dispatcher.BeginInvoke(() => StatusText.Text = "Downloading " + name);
            };

            var versionId = inst.Version;
            if (inst.Loader is "fabric" or "quilt")
            {
                SetStatus($"Preparing {inst.LoaderLabel} for {inst.Version}…");
                versionId = await EnsureLoaderProfileAsync(inst, path.Versions);
            }

            _ = Task.Run(() => CleanInstanceTemp(inst.Path)); // old logs/crash reports/tmp files, never touches settings or worlds

            var options = new MLaunchOption
            {
                Session = new MSession(session.Name, session.AccessToken, session.Uuid),
                MaximumRamMb = _ramMb,
                MinimumRamMb = Math.Min(2048, _ramMb)   // big enough start heap = fewer resize stutters
            };
            ApplyJvmTuning(options);

            SetStatus($"Installing Minecraft {inst.Version} (first launch downloads game files)…");
            var process = await launcher.InstallAndBuildProcessAsync(versionId, options);
            EnsureModMenuKeybind(inst, Path.Combine(path.Versions, inst.Version, inst.Version + ".jar"));
            process.EnableRaisingEvents = true;
            process.Exited += (_, _) => Dispatcher.BeginInvoke(() => OnGameExited(inst, process.ExitCode));
            process.Start();
            BoostWhilePlaying(process);
            SetStatus($"Playing {inst.Name} — Minecraft is running.");
        }
        catch (Exception ex)
        {
            Program.Log("Play failed", ex.ToString());
            SetStatus("Could not start the game.");
            SetPlaying(false);
            MessageBox.Show(this, ex.Message, "Could not start Minecraft", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void OnGameExited(InstanceInfo inst, int code)
    {
        RestoreAfterPlaying();
        SetPlaying(false);
        if (_detail is not null && _detail.Path == inst.Path) RefreshContent();   // new screenshots / logs
        if (code == 0) { SetStatus("Game closed."); return; }
        SetStatus($"Game closed unexpectedly (exit code {code}).");
        MessageBox.Show(this,
            $"Minecraft closed with exit code {code}.\n\nCheck the log in:\n{Path.Combine(inst.Path, "logs", "latest.log")}\n\n" +
            "Common causes: a mod for a different Minecraft version, or missing Fabric API.",
            "Game crashed", MessageBoxButton.OK, MessageBoxImage.Warning);
    }

    private void SetPlaying(bool on)
    {
        _playing = on;
        PlayButton.IsEnabled = !on;
        PlayListButton.IsEnabled = !on;
        SetBusy(on);
    }

    private async Task<MinecraftSession> EnsureFreshSessionAsync()
    {
        var s = _session!;
        if (s.ExpiresUtc > DateTime.UtcNow.AddMinutes(10)) return s;
        if (string.IsNullOrWhiteSpace(AuthConfig.ClientId))
            return await DefaultAuth.TrySilentAsync() ?? throw new Exception("Your sign-in expired. Sign out and sign in again.");
        return await new AuthService(Http, AuthConfig.ClientId).RefreshAsync(s.RefreshToken, CancellationToken.None);
    }

    private static readonly HttpClient DownloadHttp = new(new SocketsHttpHandler
    {
        MaxConnectionsPerServer = 64,
        AutomaticDecompression = System.Net.DecompressionMethods.All,
        EnableMultipleHttp2Connections = true
    }) { Timeout = TimeSpan.FromMinutes(5) };

    /// <summary>
    /// Raises download parallelism (many small asset/library files). Done by reflection so a different
    /// CmlLib version can never break the build; if it isn't available the default settings are used.
    /// </summary>
    private static void TuneDownloads(MinecraftLauncher launcher)
    {
        try
        {
            var type = typeof(MinecraftLauncher).Assembly.GetType("CmlLib.Core.Installers.ParallelGameInstaller");
            var ctor = type?.GetConstructors().FirstOrDefault(c =>
            {
                var ps = c.GetParameters();
                return ps.Length == 3 && ps[0].ParameterType == typeof(int) && ps[1].ParameterType == typeof(int) && ps[2].ParameterType == typeof(HttpClient);
            });
            var prop = typeof(MinecraftLauncher).GetProperty("GameInstaller");
            if (ctor is null || prop is null || !prop.CanWrite) { Program.Log("TuneDownloads", "ParallelGameInstaller not available; using defaults."); return; }
            var installer = ctor.Invoke(new object[] { 32, 32, DownloadHttp });
            if (prop.PropertyType.IsInstanceOfType(installer)) prop.SetValue(launcher, installer);
        }
        catch (Exception ex) { Program.Log("TuneDownloads", ex.Message); }
    }

    /// <summary>Downloads the Fabric/Quilt launch profile (a version json that inherits the vanilla version).</summary>
    private static async Task<string> EnsureLoaderProfileAsync(InstanceInfo inst, string versionsDir)
    {
        var wanted = inst.LoaderVersion;                                   // "" = newest stable
        if (Directory.Exists(versionsDir))
        {
            var pattern = string.IsNullOrEmpty(wanted) ? $"{inst.Loader}-loader-*-{inst.Version}" : $"{inst.Loader}-loader-{wanted}-{inst.Version}";
            var cached = Directory.GetDirectories(versionsDir, pattern)
                .Where(d => File.Exists(Path.Combine(d, Path.GetFileName(d) + ".json")))
                .OrderByDescending(d => d, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
            if (cached is not null) return Path.GetFileName(cached);
        }
        var meta = inst.Loader == "quilt" ? "https://meta.quiltmc.org/v3" : "https://meta.fabricmc.net/v2";
        var unsupported = $"{inst.LoaderLabel} {(string.IsNullOrEmpty(wanted) ? "" : wanted + " ")}does not support Minecraft {inst.Version} (Fabric/Quilt need 1.14 or newer).\n\n" +
                          "Open the instance and use the version/loader dropdowns, then Apply: pick Vanilla for old versions, or a newer Minecraft version for mods.";

        var loaderVersion = wanted;
        if (string.IsNullOrEmpty(loaderVersion))
        {
            using var listResp = await Http.GetAsync($"{meta}/versions/loader/{inst.Version}");
            if (listResp.StatusCode is System.Net.HttpStatusCode.BadRequest or System.Net.HttpStatusCode.NotFound) throw new Exception(unsupported);
            listResp.EnsureSuccessStatusCode();
            var listJson = JsonNode.Parse(await listResp.Content.ReadAsStringAsync())!.AsArray();
            if (listJson.Count == 0) throw new Exception(unsupported);
            var pick = listJson.FirstOrDefault(x => x?["loader"]?["stable"]?.GetValue<bool>() == true) ?? listJson[0];
            loaderVersion = pick!["loader"]!["version"]!.ToString();
        }

        var id = $"{inst.Loader}-loader-{loaderVersion}-{inst.Version}";
        var dir = Path.Combine(versionsDir, id);
        var file = Path.Combine(dir, id + ".json");
        if (!File.Exists(file))
        {
            using var resp = await Http.GetAsync($"{meta}/versions/loader/{inst.Version}/{loaderVersion}/profile/json");
            if (resp.StatusCode is System.Net.HttpStatusCode.BadRequest or System.Net.HttpStatusCode.NotFound) throw new Exception(unsupported);
            resp.EnsureSuccessStatusCode();
            Directory.CreateDirectory(dir);
            await File.WriteAllTextAsync(file, await resp.Content.ReadAsStringAsync());
        }
        return id;
    }

    // ---------------------------------------------------------------- shared game files (no junctions)
    /// <summary>
    /// Game directory = the instance folder (mods, worlds, settings), while libraries / assets / Java / versions
    /// point straight at one shared folder, so they are downloaded once for all instances.
    /// If the CmlLib version doesn't allow this, each instance simply keeps its own copy (still works).
    /// </summary>
    private static MinecraftPath CreateMinecraftPath(string instancePath)
    {
        var path = new MinecraftPath(instancePath);
        foreach (var (prop, folder) in new[] { ("Library", "libraries"), ("Versions", "versions"), ("Assets", "assets"), ("Runtime", "runtime") })
        {
            try
            {
                var target = Path.Combine(SharedRoot, folder);
                Directory.CreateDirectory(target);
                var p = typeof(MinecraftPath).GetProperty(prop);
                if (p is null) continue;
                var setter = p.GetSetMethod(true);
                if (setter is not null) setter.Invoke(path, new object[] { target });
                else typeof(MinecraftPath).GetField($"<{prop}>k__BackingField", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(path, target);
                if (!string.Equals(p.GetValue(path) as string, target, StringComparison.OrdinalIgnoreCase))
                    Program.Log("SharedPath", $"{prop} could not be shared; this instance keeps its own copy.");
            }
            catch (Exception ex) { Program.Log("SharedPath " + prop, ex.Message); }
        }
        return path;
    }

    private static bool IsLink(string path)
    {
        try { var di = new DirectoryInfo(path); return di.Exists && di.Attributes.HasFlag(FileAttributes.ReparsePoint); }
        catch { return false; }
    }

    /// <summary>Removes folder junctions inside an instance (left over from an older launcher build). Never touches their targets.</summary>
    private static void UnlinkSharedFolders(string instancePath)
    {
        foreach (var name in SharedFolders)
        {
            var link = Path.Combine(instancePath, name);
            try
            {
                if (!IsLink(link)) continue;
                try { Directory.Delete(link, false); }
                catch
                {
                    var psi = new ProcessStartInfo("cmd.exe", $"/c rmdir \"{link}\"") { CreateNoWindow = true, UseShellExecute = false };
                    Process.Start(psi)?.WaitForExit(5000);
                }
            }
            catch (Exception ex) { Program.Log("UnlinkShared " + name, ex.Message); }
        }
    }

    // ---------------------------------------------------------------- Right Shift opens the mod list (Mod Menu)
    /// <summary>
    /// Once per instance: if Mod Menu is installed, bind its "open" key to Right Shift. Only adds that one line to
    /// options.txt (video/graphics options are never changed).
    /// </summary>
    private static void EnsureModMenuKeybind(InstanceInfo inst, string versionJar)
    {
        try
        {
            var marker = Path.Combine(inst.Path, ".z4-keybind");
            if (File.Exists(marker)) return;
            var mods = Path.Combine(inst.Path, "mods");
            if (!Directory.Exists(mods) || !Directory.EnumerateFiles(mods, "modmenu*").Any()) return;

            const string key = "key_key.modmenu.open_menu";
            const string line = key + ":key.keyboard.right.shift";
            var options = Path.Combine(inst.Path, "options.txt");
            if (File.Exists(options))
            {
                var lines = File.ReadAllLines(options).ToList();
                var i = lines.FindIndex(l => l.StartsWith(key + ":"));
                if (i < 0) lines.Add(line);
                else if (lines[i].EndsWith("key.keyboard.unknown")) lines[i] = line;
                File.WriteAllLines(options, lines);
            }
            else
            {
                var dataVersion = ReadDataVersion(versionJar);
                if (dataVersion is null) return;           // can't write a valid new file: skip, try again next launch
                File.WriteAllLines(options, new[] { "version:" + dataVersion, line });
            }
            File.WriteAllText(marker, "Right Shift keybind for Mod Menu was set once.");
        }
        catch (Exception ex) { Program.Log("ModMenuKeybind", ex.Message); }
    }

    private static string? ReadDataVersion(string jar)
    {
        try
        {
            if (!File.Exists(jar)) return null;
            using var zip = System.IO.Compression.ZipFile.OpenRead(jar);
            var entry = zip.GetEntry("version.json");
            if (entry is null) return null;
            using var s = entry.Open();
            return JsonNode.Parse(s)?["world_version"]?.ToString();
        }
        catch { return null; }
    }

    // ---------------------------------------------------------------- performance (does NOT touch options.txt / video settings)
    private static readonly string[] JvmFlags =
    {
        "-XX:+UnlockExperimentalVMOptions",
        "-XX:+UseG1GC",
        "-XX:+ParallelRefProcEnabled",
        "-XX:MaxGCPauseMillis=50",        // short GC pauses = fewer micro-stutters
        "-XX:G1NewSizePercent=20",
        "-XX:G1ReservePercent=20",
        "-XX:G1HeapRegionSize=16M",
        "-XX:+DisableExplicitGC",
        "-XX:+PerfDisableSharedMem",
        "-Dfile.encoding=UTF-8"
    };

    /// <summary>Adds garbage-collector tuning. Reflection keeps it independent of the exact CmlLib version.</summary>
    private static void ApplyJvmTuning(MLaunchOption options)
    {
        try
        {
            foreach (var name in new[] { "ExtraJvmArguments", "JVMArguments" })
            {
                var prop = typeof(MLaunchOption).GetProperty(name);
                if (prop is null || !prop.CanWrite) continue;
                var pt = prop.PropertyType;
                var elem = pt.IsArray ? pt.GetElementType() : pt.IsGenericType ? pt.GetGenericArguments()[0] : null;
                if (elem is null) continue;

                var arr = Array.CreateInstance(elem, JvmFlags.Length);
                for (var i = 0; i < JvmFlags.Length; i++)
                {
                    object? value;
                    if (elem == typeof(string)) value = JvmFlags[i];
                    else
                    {
                        var factory = elem.GetMethod("FromCommandLine", new[] { typeof(string) });
                        value = factory is not null && factory.IsStatic ? factory.Invoke(null, new object[] { JvmFlags[i] })
                                                                       : Activator.CreateInstance(elem, JvmFlags[i]);
                    }
                    arr.SetValue(value, i);
                }
                if (!pt.IsInstanceOfType(arr)) continue;
                prop.SetValue(options, arr);
                return;
            }
            Program.Log("ApplyJvmTuning", "No JVM-argument property found; using default JVM flags.");
        }
        catch (Exception ex) { Program.Log("ApplyJvmTuning", ex.Message); }
    }

    private ProcessPriorityClass _launcherPriority = ProcessPriorityClass.Normal;

    /// <summary>Game gets CPU priority; the launcher (animated UI) steps out of the way while you play.</summary>
    private void BoostWhilePlaying(Process game)
    {
        try { game.PriorityClass = ProcessPriorityClass.AboveNormal; } catch { }
        try
        {
            var me = Process.GetCurrentProcess();
            _launcherPriority = me.PriorityClass;
            me.PriorityClass = ProcessPriorityClass.BelowNormal;
        }
        catch { }
        WindowState = WindowState.Minimized;
    }

    private void RestoreAfterPlaying()
    {
        try { Process.GetCurrentProcess().PriorityClass = _launcherPriority; } catch { }
        if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
    }

    // ---------------------------------------------------------------- temp-file cleanup
    /// <summary>Deletes old logs, crash reports and leftover temp files of one instance. Returns bytes freed.</summary>
    private static long CleanInstanceTemp(string instancePath)
    {
        long freed = 0;
        void Del(string file)
        {
            try { var len = new FileInfo(file).Length; File.Delete(file); freed += len; } catch { }
        }
        void DelOld(string dir, string pattern, int days, bool recurse = false, string? keep = null)
        {
            try
            {
                if (!Directory.Exists(dir)) return;
                var limit = DateTime.UtcNow.AddDays(-days);
                foreach (var f in Directory.EnumerateFiles(dir, pattern, recurse ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly))
                {
                    if (keep is not null && string.Equals(Path.GetFileName(f), keep, StringComparison.OrdinalIgnoreCase)) continue;
                    if (File.GetLastWriteTimeUtc(f) < limit) Del(f);
                }
            }
            catch { }
        }

        DelOld(Path.Combine(instancePath, "logs"), "*", 7, keep: "latest.log");     // old rotated logs (.log.gz)
        DelOld(Path.Combine(instancePath, "crash-reports"), "*.txt", 14);
        DelOld(instancePath, "hs_err_pid*.log", 7);                                 // Java crash dumps
        DelOld(instancePath, "*.tmp", 1);
        DelOld(Path.Combine(instancePath, "mods"), "*.tmp", 1);
        DelOld(Path.Combine(instancePath, "mods"), "*.part", 1);
        DelOld(Path.Combine(instancePath, "downloads"), "*", 3, recurse: true);
        try
        {
            var mixin = Path.Combine(instancePath, ".mixin.out");                   // debug class dumps, can be large
            if (Directory.Exists(mixin) && !IsLink(mixin))
                foreach (var f in Directory.EnumerateFiles(mixin, "*", SearchOption.AllDirectories)) Del(f);
        }
        catch { }

        // keep the launcher's own error log from growing forever
        try
        {
            var log = new FileInfo(Program.LogPath);
            if (log.Exists && log.Length > 2 * 1024 * 1024) { freed += log.Length; log.Delete(); }
        }
        catch { }
        return freed;
    }

    private async void CleanTemp_Click(object sender, RoutedEventArgs e)
    {
        var inst = InstanceDetailView.Visibility == Visibility.Visible ? _detail : InstancesList.SelectedItem as InstanceInfo;
        if (inst is null) { SetStatus("Select an instance first."); return; }
        SetStatus($"Cleaning temp files of \"{inst.Name}\"…");
        var freed = await Task.Run(() => CleanInstanceTemp(inst.Path));
        RefreshInstanceEntry(inst.Name);
        SetStatus(freed > 0 ? $"Cleaned \"{inst.Name}\": freed {HumanSize(freed)}." : $"\"{inst.Name}\" is already clean.");
    }

    // ---------------------------------------------------------------- per-instance version
    private void ChangeVersion_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        if (DetailVersionBox.SelectedItem is not MinecraftVersion picked) { SetStatus("Pick a version first."); return; }
        var inst = _detail;
        var newLoader = ((DetailLoaderBox.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content?.ToString() ?? "Vanilla").ToLowerInvariant();
        var newLv = DetailLoaderVersionBox.IsEnabled && DetailLoaderVersionBox.SelectedIndex > 0 ? DetailLoaderVersionBox.SelectedItem as string ?? "" : "";
        if (picked.Id == inst.Version && newLoader == (string.IsNullOrEmpty(inst.Loader) ? "vanilla" : inst.Loader) && newLv == inst.LoaderVersion)
        { SetStatus($"\"{inst.Name}\" already uses these settings."); return; }
        if (_playing) { SetStatus("Close the game before changing its version."); return; }

        var modsDir = Path.Combine(inst.Path, "mods");
        var hasMods = Directory.Exists(modsDir) && Directory.EnumerateFiles(modsDir).Any();
        if (hasMods && MessageBox.Show(this,
                $"Change \"{inst.Name}\" to {newLoader} {picked.Id}?\n\nMods installed for the current version/loader usually won't work afterwards. " +
                "Your worlds are kept, but older worlds can't be opened on an older game version afterwards.",
                "Change version", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

        try
        {
            var metaPath = Path.Combine(inst.Path, "instance.json");
            var json = File.Exists(metaPath) ? JsonNode.Parse(File.ReadAllText(metaPath))!.AsObject() : new JsonObject { ["name"] = inst.Name };
            json["version"] = picked.Id;
            json["loader"] = newLoader;
            json["loaderVersion"] = newLv;
            File.WriteAllText(metaPath, json.ToJsonString(new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
            RefreshInstanceEntry(inst.Name);
            var updated = _instances.First(i => i.Name == inst.Name);
            _detail = updated;
            DetailHint.Visibility = Visibility.Collapsed;
            DetailMeta.Text = $"{updated.Meta}{(updated.LoaderVersion.Length > 0 ? " (" + updated.LoaderVersion + ")" : "")}  •  {updated.Summary}";
            SetStatus($"\"{inst.Name}\" is now {updated.Meta}. Only this instance was changed.");
        }
        catch (Exception ex) { SetStatus("Could not change version: " + ex.Message); }
    }

    // ---------------------------------------------------------------- loader version of the opened instance
    private bool _detailLoading;
    private string _detailWantedLv = "";
    private int _detailRev;

    private void DetailChoice_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready || _detailLoading || _detail is null) return;
        _detailWantedLv = "";
        _ = RefreshDetailLoaderVersionsAsync();
    }

    private async Task RefreshDetailLoaderVersionsAsync()
    {
        var rev = ++_detailRev;
        var loader = ((DetailLoaderBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Vanilla").ToLowerInvariant();
        var mc = (DetailVersionBox.SelectedItem as MinecraftVersion)?.Id;
        if (loader == "vanilla" || mc is null)
        {
            DetailLoaderVersionBox.ItemsSource = new[] { "—" };
            DetailLoaderVersionBox.SelectedIndex = 0;
            DetailLoaderVersionBox.IsEnabled = false;
            return;
        }
        DetailLoaderVersionBox.IsEnabled = false;
        DetailLoaderVersionBox.ItemsSource = new[] { "Loading…" };
        DetailLoaderVersionBox.SelectedIndex = 0;
        var list = await FetchLoaderVersionsAsync(loader, mc);
        if (rev != _detailRev) return;
        var items = new List<string> { "Latest (recommended)" };
        items.AddRange(list);
        if (_detailWantedLv.Length > 0 && !items.Contains(_detailWantedLv)) items.Insert(1, _detailWantedLv);   // keep a version that is no longer listed
        DetailLoaderVersionBox.ItemsSource = items;
        var idx = _detailWantedLv.Length > 0 ? items.IndexOf(_detailWantedLv) : 0;
        DetailLoaderVersionBox.SelectedIndex = Math.Max(0, idx);
        DetailLoaderVersionBox.IsEnabled = true;
    }

    // ---------------------------------------------------------------- instance icon
    private void ChangeIcon_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Choose an icon for " + _detail.Name,
            Filter = "Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.ico)|*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.ico|All files|*.*"
        };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            InstanceIcons.SetCustom(_detail.Path, dlg.FileName);
            RefreshDetailIcon();
            SetStatus("Instance icon changed.");
        }
        catch (Exception ex) { SetStatus("Could not use that image: " + ex.Message); }
    }

    private void ResetIcon_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        InstanceIcons.Reset(_detail.Path);
        RefreshDetailIcon();
        SetStatus("Default icon restored.");
    }

    private void RefreshDetailIcon()
    {
        if (_detail is null) return;
        RefreshInstanceEntry(_detail.Name);
        _detail = _instances.FirstOrDefault(i => i.Name == _detail.Name) ?? _detail;
        DetailIcon.Background = new ImageBrush(_detail.Icon) { Stretch = Stretch.UniformToFill };
    }
}
