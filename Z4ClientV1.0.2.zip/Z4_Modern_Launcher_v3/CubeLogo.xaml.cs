using System.Windows.Controls;

namespace Z4ModernLauncher;

public partial class CubeLogo : UserControl
{
    public CubeLogo() => InitializeComponent();
}
