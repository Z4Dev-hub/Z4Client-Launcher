using System.IO;
using System.Runtime.InteropServices;

namespace Z4ModernLauncher;

public static class Program
{
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBoxW(IntPtr hWnd, string text, string caption, uint type);

    public static string LogPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Z4ModernLauncher", "startup.log");

    public static void Log(string title, string details)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);
            File.AppendAllText(LogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {title}{Environment.NewLine}{details}{Environment.NewLine}{Environment.NewLine}");
        }
        catch { }
    }

    public static void ShowFatal(string message)
    {
        // Native message box: works even if WPF itself failed to load.
        try { MessageBoxW(IntPtr.Zero, message + "\n\nLog file:\n" + LogPath, "Z4 Launcher - startup error", 0x10); } catch { }
    }

    [STAThread]
    public static int Main(string[] args)
    {
        AppDomain.CurrentDomain.UnhandledException += (_, a) =>
        {
            Log("Unhandled exception", a.ExceptionObject?.ToString() ?? "unknown");
            ShowFatal("Unexpected error:\n" + (a.ExceptionObject as Exception)?.Message);
        };
        try
        {
            Log("Main", $"Starting. OS: {Environment.OSVersion}, runtime: {Environment.Version}");
            var app = new App();
            app.InitializeComponent();
            return app.Run();
        }
        catch (Exception ex)
        {
            Log("Fatal startup failure", ex.ToString());
            ShowFatal(ex.GetType().Name + ": " + ex.Message);
            return 1;
        }
    }
}
