namespace Z4ModernLauncher;

/// <summary>
/// Leave DefaultClientId empty to use the built-in CmlLib login (no Azure app needed, friends-only use).
/// Set your own Application (client) ID to use the launcher's own Microsoft login flow instead.
/// </summary>
public static class AuthConfig
{
    public const string DefaultClientId = "";   // <-- empty = built-in login; or paste your own client ID

    public static string ClientId { get; set; } = DefaultClientId;
}
