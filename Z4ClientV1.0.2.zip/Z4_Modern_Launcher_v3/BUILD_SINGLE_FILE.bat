@echo off
setlocal
cd /d "%~dp0"
if exist dist-single rmdir /s /q dist-single
dotnet publish Z4ModernLauncher.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o dist-single
if errorlevel 1 ( echo Build failed. & pause & exit /b 1 )
echo Built: dist-single\Z4ModernLauncher.exe
pause
