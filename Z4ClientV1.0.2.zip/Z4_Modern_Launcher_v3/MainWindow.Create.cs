using System.IO;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private string? _createIconFile;
    private int _createRev;
    private bool _createBusy;

    private string CreateLoader =>
        CLFabric.IsChecked == true ? "fabric" : CLQuilt.IsChecked == true ? "quilt" :
        CLForge.IsChecked == true ? "forge" : CLNeo.IsChecked == true ? "neoforge" : "vanilla";

    private PremadeInstance? CreatePreset =>
        CPZ4.IsChecked == true ? Premades.First(p => p.Id == "z4client") :
        CPPerformance.IsChecked == true ? Premades.First(p => p.Id == "performance") :
        CPShaders.IsChecked == true ? Premades.First(p => p.Id == "shaders") :
        CPExplorer.IsChecked == true ? Premades.First(p => p.Id == "explorer") : null;

    // ---------------------------------------------------------------- open / close
    private async void OpenCreate_Click(object sender, RoutedEventArgs e)
    {
        CreateNameBox.Text = "";
        CreateError.Text = "";
        CreateProgress.Text = "";
        _createIconFile = null;
        UpdateCreateIcon();
        CLVanilla.IsChecked = true;
        CPNone.IsChecked = true;
        CreateSnapshots.IsChecked = false;
        CreateOverlay.Opacity = 0;
        CreateOverlay.Visibility = Visibility.Visible;
        CreateOverlay.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180)));
        CreateCard.RenderTransformOrigin = new Point(0.5, 0.5);
        var open = new ScaleTransform(0.93, 0.93);
        CreateCard.RenderTransform = open;
        var grow = new DoubleAnimation(0.93, 1, TimeSpan.FromMilliseconds(260)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.35 } };
        open.BeginAnimation(ScaleTransform.ScaleXProperty, grow);
        open.BeginAnimation(ScaleTransform.ScaleYProperty, grow);
        CreateNameBox.Focus();

        if (_versions.Count == 0) await LoadVersionsAsync();
        FillCreateVersions();
    }

    private void CreateCancel_Click(object sender, RoutedEventArgs e)
    {
        if (_createBusy) return;
        CloseCreateOverlay();
    }

    private void CloseCreateOverlay()
    {
        if (CreateOverlay.Visibility != Visibility.Visible) return;
        var fade = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(130)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
        fade.Completed += (_, _) =>
        {
            CreateOverlay.BeginAnimation(OpacityProperty, null);
            CreateOverlay.Visibility = Visibility.Collapsed;
            CreateOverlay.Opacity = 1;
        };
        CreateOverlay.BeginAnimation(OpacityProperty, fade);
        if (CreateCard.RenderTransform is ScaleTransform st)
        {
            var shrink = new DoubleAnimation(1, 0.95, TimeSpan.FromMilliseconds(130));
            st.BeginAnimation(ScaleTransform.ScaleXProperty, shrink);
            st.BeginAnimation(ScaleTransform.ScaleYProperty, shrink);
        }
    }

    // ---------------------------------------------------------------- fields
    private void FillCreateVersions()
    {
        var list = CreateSnapshots.IsChecked == true ? _versions.ToList() : _versions.Where(v => v.Type == "release").ToList();
        CreateVersionBox.ItemsSource = null;
        CreateVersionBox.DisplayMemberPath = "Label";
        CreateVersionBox.ItemsSource = list;
        if (list.Count > 0) CreateVersionBox.SelectedIndex = 0;
    }

    private void CreateSnapshots_Changed(object sender, RoutedEventArgs e) { if (_ready) FillCreateVersions(); }

    private async void CreateVersion_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) await RefreshCreateLoaderVersionsAsync();
    }

    private async void CreateLoader_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        if (CreateLoader != "fabric" && CreatePreset is not null) CPNone.IsChecked = true;   // presets are Fabric packs
        await RefreshCreateLoaderVersionsAsync();
    }

    private void CreatePreset_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        var preset = CreatePreset;
        if (preset is not null && CreateLoader != "fabric") CLFabric.IsChecked = true;       // presets need Fabric
        CreatePresetHint.Text = preset is null
            ? "No mods. You can add some later with Add files or Browse online."
            : $"{preset.Tagline}  ({preset.Items.Length} downloads from Modrinth, requires Fabric)";
    }

    private async Task RefreshCreateLoaderVersionsAsync()
    {
        var loader = CreateLoader;
        var mc = (CreateVersionBox.SelectedItem as MinecraftVersion)?.Id;
        var rev = ++_createRev;
        if (loader == "vanilla" || mc is null)
        {
            CreateLoaderVersionBox.ItemsSource = new[] { "Not needed for Vanilla" };
            CreateLoaderVersionBox.SelectedIndex = 0;
            CreateLoaderVersionBox.IsEnabled = false;
            return;
        }
        CreateLoaderVersionBox.IsEnabled = false;
        CreateLoaderVersionBox.ItemsSource = new[] { "Loading versions…" };
        CreateLoaderVersionBox.SelectedIndex = 0;
        var list = await FetchLoaderVersionsAsync(loader, mc);
        if (rev != _createRev) return;
        var items = new List<string> { "Latest (recommended)" };
        items.AddRange(list);
        CreateLoaderVersionBox.ItemsSource = items;
        CreateLoaderVersionBox.SelectedIndex = 0;
        CreateLoaderVersionBox.IsEnabled = true;
    }

    /// <summary>Loader versions for one Minecraft version (newest first). Empty list = unknown / unsupported.</summary>
    internal static async Task<List<string>> FetchLoaderVersionsAsync(string loader, string mc)
    {
        var result = new List<string>();
        try
        {
            switch (loader)
            {
                case "fabric":
                case "quilt":
                {
                    var meta = loader == "quilt" ? "https://meta.quiltmc.org/v3" : "https://meta.fabricmc.net/v2";
                    using var resp = await Http.GetAsync($"{meta}/versions/loader/{mc}");
                    if (!resp.IsSuccessStatusCode) break;
                    var arr = JsonNode.Parse(await resp.Content.ReadAsStringAsync())?.AsArray();
                    if (arr is null) break;
                    foreach (var x in arr)
                    {
                        var v = x?["loader"]?["version"]?.ToString();
                        if (!string.IsNullOrEmpty(v) && !result.Contains(v)) result.Add(v);
                        if (result.Count >= 40) break;
                    }
                    break;
                }
                case "forge":
                {
                    var json = JsonNode.Parse(await Http.GetStringAsync("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"));
                    var promos = json?["promos"]?.AsObject();
                    foreach (var key in new[] { $"{mc}-recommended", $"{mc}-latest" })
                    {
                        var v = promos?[key]?.ToString();
                        if (!string.IsNullOrEmpty(v) && !result.Contains(v)) result.Add(v);
                    }
                    break;
                }
                case "neoforge":
                {
                    var parts = mc.Split('.');
                    if (parts.Length < 2 || parts[0] != "1") break;
                    var prefix = $"{parts[1]}.{(parts.Length > 2 ? parts[2] : "0")}.";
                    var json = JsonNode.Parse(await Http.GetStringAsync("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge"));
                    var all = json?["versions"]?.AsArray().Select(x => x?.ToString() ?? "").Where(v => v.StartsWith(prefix)).ToList() ?? new List<string>();
                    all.Reverse();
                    result.AddRange(all.Take(40));
                    break;
                }
            }
        }
        catch (Exception ex) { Program.Log("FetchLoaderVersions " + loader, ex.Message); }
        return result;
    }

    // ---------------------------------------------------------------- icon
    private void UpdateCreateIcon()
    {
        ImageSource img = InstanceIcons.Default;
        try
        {
            if (_createIconFile is not null && ImageHelper.Decode(File.ReadAllBytes(_createIconFile), 160) is { } custom) img = custom;
        }
        catch { }
        CreateIconHost.Background = new ImageBrush(img) { Stretch = Stretch.UniformToFill };
    }

    private void CreateChooseIcon_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Choose an icon for the instance",
            Filter = "Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.ico)|*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.ico|All files|*.*"
        };
        if (dlg.ShowDialog(this) != true) return;
        _createIconFile = dlg.FileName;
        UpdateCreateIcon();
    }

    private void CreateResetIcon_Click(object sender, RoutedEventArgs e)
    {
        _createIconFile = null;
        UpdateCreateIcon();
    }

    // ---------------------------------------------------------------- create
    private async void CreateConfirm_Click(object sender, RoutedEventArgs e)
    {
        if (_createBusy) return;
        CreateError.Text = "";

        var name = CreateNameBox.Text.Trim();
        foreach (var c in Path.GetInvalidFileNameChars()) name = name.Replace(c.ToString(), "");
        name = name.Trim().TrimEnd('.');
        if (name.Length == 0) { CreateError.Text = "Enter a name for the instance."; return; }
        if (_instances.Any(i => string.Equals(i.Name, name, StringComparison.OrdinalIgnoreCase)))
        { CreateError.Text = $"An instance named \"{name}\" already exists."; return; }
        if (CreateVersionBox.SelectedItem is not MinecraftVersion version) { CreateError.Text = "Pick a Minecraft version."; return; }

        var loader = CreateLoader;
        var loaderVersion = CreateLoaderVersionBox.IsEnabled && CreateLoaderVersionBox.SelectedIndex > 0
            ? CreateLoaderVersionBox.SelectedItem as string ?? "" : "";
        var preset = CreatePreset;

        _createBusy = true;
        CreateConfirmButton.IsEnabled = false;
        CreateCancelButton.IsEnabled = false;
        SetBusy(true);
        try
        {
            CreateProgress.Text = "Creating instance…";
            var inst = CreateInstanceFolders(name, version.Id, loader, loaderVersion);
            if (_createIconFile is not null)
            {
                try { InstanceIcons.SetCustom(inst.Path, _createIconFile); }
                catch (Exception ex) { Program.Log("Instance icon", ex.Message); }
            }
            _instances.Add(inst);
            SetActive(inst);

            var ok = 0;
            var failed = new List<string>();
            if (preset is not null)
                (ok, failed) = await InstallPresetAsync(preset, inst, n => CreateProgress.Text = $"Downloading preinstalled mods… {n}/{preset.Items.Length}");

            RefreshInstanceEntry(inst.Name);
            CloseCreateOverlay();
            SetStatus(preset is null
                ? $"Created \"{inst.Name}\" ({inst.Meta})."
                : failed.Count == 0
                    ? $"Created \"{inst.Name}\" ({inst.Meta}) with {ok} download(s)."
                    : $"Created \"{inst.Name}\": {ok} downloaded, skipped {string.Join(", ", failed)} (no compatible file).");
            OpenInstanceDetail(ActiveInstance ?? inst);
        }
        catch (Exception ex)
        {
            Program.Log("Create instance", ex.ToString());
            CreateError.Text = "Could not create the instance: " + ex.Message;
        }
        finally
        {
            _createBusy = false;
            CreateConfirmButton.IsEnabled = true;
            CreateCancelButton.IsEnabled = true;
            CreateProgress.Text = "";
            SetBusy(false);
        }
    }

    // ---------------------------------------------------------------- preinstalled packs
    /// <summary>Downloads every item of a preset (4 at a time). Failures are skipped and returned, never fatal.</summary>
    private async Task<(int Ok, List<string> Failed)> InstallPresetAsync(PremadeInstance preset, InstanceInfo inst, Action<int> progress)
    {
        var ok = 0;
        var done = 0;
        var failed = new List<string>();
        using var gate = new SemaphoreSlim(4);
        await Task.WhenAll(preset.Items.Select(async item =>
        {
            var (slug, folder) = item;
            await gate.WaitAsync();
            try
            {
                await DownloadModrinthAsync(slug, folder, inst, strict: folder == "mods");
                Interlocked.Increment(ref ok);
            }
            catch (Exception ex)
            {
                lock (failed) failed.Add(slug);
                Program.Log("Preset item failed", slug + ": " + ex.Message);
            }
            finally
            {
                gate.Release();
                var n = Interlocked.Increment(ref done);
                _ = Dispatcher.BeginInvoke(() => progress(n));
            }
        }));
        return (ok, failed);
    }

    /// <summary>Adds the Z4 Client pack to the opened instance (Fabric only).</summary>
    private async void AddZ4Pack_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null || _createBusy) return;
        var inst = _detail;
        if (inst.Loader != "fabric")
        {
            MessageBox.Show(this, "The Z4 Client pack needs a Fabric instance. Use the loader dropdown above (set it to Fabric, then Apply) and try again.",
                "Z4 Client pack", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var preset = Premades.First(p => p.Id == "z4client");
        _createBusy = true;
        SetBusy(true);
        try
        {
            SetStatus("Adding the Z4 Client pack…");
            var (ok, failed) = await InstallPresetAsync(preset, inst, n => SetStatus($"Z4 Client pack: {n}/{preset.Items.Length}…"));
            RefreshContent();
            RefreshInstanceEntry(inst.Name);
            SetStatus(failed.Count == 0
                ? $"Z4 Client pack added ({ok} mods). Press Right Shift in game for the mod list."
                : $"Z4 Client pack: {ok} added, skipped {string.Join(", ", failed)} (no compatible file for {inst.Version}).");
        }
        catch (Exception ex) { SetStatus("Could not add the pack: " + ex.Message); }
        finally { _createBusy = false; SetBusy(false); }
    }
}
