; Inno Setup script -> builds a real Windows installer (Z4ClientSetup.exe).
; Compile it with BUILD_INSTALLER.bat (it publishes the app first), or open it in Inno Setup.

#define AppName "Z4 Client"
#define AppVersion "2.0"
#define AppPublisher "Z4"
#define AppExe "Z4ModernLauncher.exe"

[Setup]
AppId={{FF9D117F-7D76-4F66-B524-17CAA25945C1}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
; Installs to C:\Z4Client. The folder is created automatically if it does not exist.
DefaultDirName=C:\Z4Client
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=output
OutputBaseFilename=Z4ClientSetup
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
UninstallDisplayName={#AppName}
UninstallDisplayIcon={app}\{#AppExe}
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "app\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "Start {#AppName}"; Flags: nowait postinstall skipifsilent

; Your instances, mods, worlds and sign-in live in %APPDATA%\Z4Launcher and are NOT removed on uninstall.
