using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace Z4ModernLauncher;

public sealed record MinecraftSession(string Name, string Uuid, string AccessToken, string RefreshToken, DateTime ExpiresUtc);

/// <summary>Real Microsoft -> Xbox Live -> XSTS -> Minecraft Services sign-in using the OAuth device-code flow.</summary>
public sealed class AuthService
{
    private const string Authority = "https://login.microsoftonline.com/consumers/oauth2/v2.0";
    private const string Scope = "XboxLive.signin offline_access";
    private readonly HttpClient _http;
    private readonly string _clientId;

    public AuthService(HttpClient http, string clientId) { _http = http; _clientId = clientId.Trim(); }

    public const string RedirectUri = "https://login.live.com/oauth20_desktop.srf";

    public static (string Verifier, string Challenge) NewPkce()
    {
        var bytes = RandomNumberGenerator.GetBytes(48);
        var verifier = Base64Url(bytes);
        var challenge = Base64Url(SHA256.HashData(Encoding.ASCII.GetBytes(verifier)));
        return (verifier, challenge);
    }

    private static string Base64Url(byte[] data) =>
        Convert.ToBase64String(data).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    /// <summary>The Microsoft sign-in page that is shown inside the launcher's login window.</summary>
    public string BuildAuthorizeUrl(string challenge, string state) =>
        $"{Authority}/authorize?client_id={Uri.EscapeDataString(_clientId)}&response_type=code" +
        $"&redirect_uri={Uri.EscapeDataString(RedirectUri)}&response_mode=query" +
        $"&scope={Uri.EscapeDataString(Scope)}&code_challenge={challenge}&code_challenge_method=S256" +
        $"&state={Uri.EscapeDataString(state)}&prompt=select_account";

    public async Task<MinecraftSession> CompleteWithCodeAsync(string code, string verifier, CancellationToken ct)
    {
        var json = await PostFormAsync($"{Authority}/token", new()
        {
            ["grant_type"] = "authorization_code",
            ["client_id"] = _clientId,
            ["code"] = code,
            ["redirect_uri"] = RedirectUri,
            ["code_verifier"] = verifier,
            ["scope"] = Scope
        }, ct);
        if (json["error"] != null) throw new Exception(Describe(json, "Microsoft sign-in failed."));
        return await ExchangeAsync(json["access_token"]!.ToString(), json["refresh_token"]?.ToString() ?? "", ct);
    }

    public async Task<MinecraftSession> RefreshAsync(string refreshToken, CancellationToken ct)
    {
        var json = await PostFormAsync($"{Authority}/token", new()
        {
            ["grant_type"] = "refresh_token",
            ["client_id"] = _clientId,
            ["refresh_token"] = refreshToken,
            ["scope"] = Scope
        }, ct);
        if (json["error"] != null) throw new Exception(Describe(json, "Session expired. Please sign in again."));
        return await ExchangeAsync(json["access_token"]!.ToString(), json["refresh_token"]?.ToString() ?? refreshToken, ct);
    }

    private async Task<MinecraftSession> ExchangeAsync(string msAccessToken, string msRefreshToken, CancellationToken ct)
    {
        // 1) Xbox Live user token
        var xbl = await PostJsonAsync("https://user.auth.xboxlive.com/user/authenticate", new JsonObject
        {
            ["Properties"] = new JsonObject
            {
                ["AuthMethod"] = "RPS",
                ["SiteName"] = "user.auth.xboxlive.com",
                ["RpsTicket"] = "d=" + msAccessToken
            },
            ["RelyingParty"] = "http://auth.xboxlive.com",
            ["TokenType"] = "JWT"
        }, null, ct);
        var xblToken = xbl.Body["Token"]?.ToString();
        var uhs = xbl.Body["DisplayClaims"]?["xui"]?[0]?["uhs"]?.ToString();
        if (!xbl.Ok || xblToken == null || uhs == null) throw new Exception("Xbox Live sign-in failed (" + (int)xbl.Status + ").");

        // 2) XSTS token for Minecraft services
        var xsts = await PostJsonAsync("https://xsts.auth.xboxlive.com/xsts/authorize", new JsonObject
        {
            ["Properties"] = new JsonObject
            {
                ["SandboxId"] = "RETAIL",
                ["UserTokens"] = new JsonArray(xblToken)
            },
            ["RelyingParty"] = "rp://api.minecraftservices.com/",
            ["TokenType"] = "JWT"
        }, null, ct);
        if (!xsts.Ok)
        {
            var xerr = xsts.Body["XErr"]?.ToString();
            throw new Exception(xerr switch
            {
                "2148916233" => "This Microsoft account has no Xbox profile. Sign in once at xbox.com to create one, then try again.",
                "2148916235" => "Xbox Live is not available in your country/region.",
                "2148916236" or "2148916237" => "This account needs adult verification on Xbox.",
                "2148916238" => "This is a child account. Add it to a Microsoft Family and allow online play first.",
                _ => "Xbox security token (XSTS) was refused (code " + (xerr ?? ((int)xsts.Status).ToString()) + ")."
            });
        }
        var xstsToken = xsts.Body["Token"]!.ToString();

        // 3) Minecraft access token
        var mc = await PostJsonAsync("https://api.minecraftservices.com/authentication/login_with_xbox",
            new JsonObject { ["identityToken"] = $"XBL3.0 x={uhs};{xstsToken}" }, null, ct);
        if (mc.Status == System.Net.HttpStatusCode.Forbidden)
            throw new Exception("Minecraft rejected this Azure app registration. New apps must be approved by Mojang first: request access at https://aka.ms/AppRegInfo and wait for approval.");
        var mcToken = mc.Body["access_token"]?.ToString();
        if (!mc.Ok || mcToken == null) throw new Exception("Minecraft services sign-in failed (" + (int)mc.Status + ").");
        var expires = DateTime.UtcNow.AddSeconds((int?)mc.Body["expires_in"] ?? 86400);

        // 4) Profile
        using var req = new HttpRequestMessage(HttpMethod.Get, "https://api.minecraftservices.com/minecraft/profile");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", mcToken);
        using var resp = await _http.SendAsync(req, ct);
        if (resp.StatusCode == System.Net.HttpStatusCode.NotFound)
            throw new Exception("This Microsoft account does not own Minecraft: Java Edition (no profile found).");
        resp.EnsureSuccessStatusCode();
        var profile = JsonNode.Parse(await resp.Content.ReadAsStringAsync(ct))!;
        return new MinecraftSession(profile["name"]!.ToString(), profile["id"]!.ToString(), mcToken, msRefreshToken, expires);
    }

    // ---------- helpers ----------
    private async Task<JsonNode> PostFormAsync(string url, Dictionary<string, string> form, CancellationToken ct)
    {
        using var resp = await _http.PostAsync(url, new FormUrlEncodedContent(form), ct);
        var text = await resp.Content.ReadAsStringAsync(ct);
        return JsonNode.Parse(text) ?? new JsonObject();
    }

    private async Task<(bool Ok, System.Net.HttpStatusCode Status, JsonNode Body)> PostJsonAsync(string url, JsonNode body, string? bearer, CancellationToken ct)
    {
        using var req = new HttpRequestMessage(HttpMethod.Post, url)
        {
            Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json")
        };
        req.Headers.Accept.ParseAdd("application/json");
        if (bearer != null) req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
        using var resp = await _http.SendAsync(req, ct);
        var text = await resp.Content.ReadAsStringAsync(ct);
        JsonNode node;
        try { node = JsonNode.Parse(text) ?? new JsonObject(); } catch { node = new JsonObject(); }
        return (resp.IsSuccessStatusCode, resp.StatusCode, node);
    }

    private static string Describe(JsonNode json, string fallback)
    {
        var d = json["error_description"]?.ToString();
        if (string.IsNullOrWhiteSpace(d)) return fallback;
        var line = d.Split('\n')[0].Trim();
        return fallback + " (" + line + ")";
    }
}

/// <summary>Stores the Microsoft refresh token encrypted for the current Windows user (DPAPI).</summary>
public static class AuthStore
{
    private static string PathFile => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Z4ModernLauncher", "auth.bin");

    public static void Save(string refreshToken)
    {
        if (string.IsNullOrEmpty(refreshToken)) return;
        Directory.CreateDirectory(Path.GetDirectoryName(PathFile)!);
        var data = ProtectedData.Protect(Encoding.UTF8.GetBytes(refreshToken), null, DataProtectionScope.CurrentUser);
        File.WriteAllBytes(PathFile, data);
    }

    public static string? Load()
    {
        try
        {
            if (!File.Exists(PathFile)) return null;
            return Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(PathFile), null, DataProtectionScope.CurrentUser));
        }
        catch { return null; }
    }

    public static void Clear() { try { if (File.Exists(PathFile)) File.Delete(PathFile); } catch { } }
}
