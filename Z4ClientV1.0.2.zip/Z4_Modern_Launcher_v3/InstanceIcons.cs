using System.Collections.Concurrent;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Z4ModernLauncher;

/// <summary>Instance icon: a generic pixel block by default, or any image the user picks (stored as icon.png in the instance).</summary>
public static class InstanceIcons
{
    private static BitmapSource? _default;
    private static readonly ConcurrentDictionary<string, ImageSource> Cache = new();

    public static ImageSource Default => _default ??= BuildDefault();

    public static ImageSource Load(string instancePath)
    {
        try
        {
            var file = Path.Combine(instancePath, "icon.png");
            if (!File.Exists(file)) return Default;
            var key = file + "|" + File.GetLastWriteTimeUtc(file).Ticks;
            return Cache.GetOrAdd(key, _ => ImageHelper.Decode(File.ReadAllBytes(file), 128) ?? Default);
        }
        catch { return Default; }
    }

    public static void SetCustom(string instancePath, string sourceFile)
    {
        var bmp = ImageHelper.Decode(File.ReadAllBytes(sourceFile)) ?? throw new Exception("That file is not a readable image.");
        var side = Math.Min(bmp.PixelWidth, bmp.PixelHeight);
        BitmapSource result = new CroppedBitmap(bmp, new Int32Rect((bmp.PixelWidth - side) / 2, (bmp.PixelHeight - side) / 2, side, side));
        if (side > 256) { var s = 256.0 / side; result = new TransformedBitmap(result, new ScaleTransform(s, s)); }
        var enc = new PngBitmapEncoder();
        enc.Frames.Add(BitmapFrame.Create(result));
        using var fs = File.Create(Path.Combine(instancePath, "icon.png"));
        enc.Save(fs);
    }

    public static void Reset(string instancePath)
    {
        try { File.Delete(Path.Combine(instancePath, "icon.png")); } catch { }
    }

    private static BitmapSource BuildDefault()
    {
        const int n = 16, k = 8;
        var rnd = new Random(7);
        var px = new byte[n * k * n * k * 4];
        for (var y = 0; y < n; y++)
            for (var x = 0; x < n; x++)
            {
                var grass = y < 4 || (y == 4 && x % 3 != 0);
                int r, g, b;
                var v = rnd.Next(-12, 13);
                if (grass) { r = 0x5E + v; g = 0xA8 + v; b = 0x3A + v; }
                else { r = 0x86 + v; g = 0x5A + v; b = 0x3A + v; }
                if (x == 0 || y == 0 || x == n - 1 || y == n - 1) { r = r * 6 / 10; g = g * 6 / 10; b = b * 6 / 10; }
                else if (x == n - 2 || y == n - 2) { r = r * 8 / 10; g = g * 8 / 10; b = b * 8 / 10; }
                for (var yy = 0; yy < k; yy++)
                    for (var xx = 0; xx < k; xx++)
                    {
                        var i = (((y * k) + yy) * n * k + (x * k) + xx) * 4;
                        px[i] = (byte)Math.Clamp(b, 0, 255); px[i + 1] = (byte)Math.Clamp(g, 0, 255); px[i + 2] = (byte)Math.Clamp(r, 0, 255); px[i + 3] = 255;
                    }
            }
        var bmp = BitmapSource.Create(n * k, n * k, 96, 96, PixelFormats.Bgra32, null, px, n * k * 4);
        bmp.Freeze();
        return bmp;
    }
}
