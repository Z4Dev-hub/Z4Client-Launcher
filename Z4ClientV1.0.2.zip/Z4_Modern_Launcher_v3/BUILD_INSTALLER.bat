@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build Z4 Client installer

where dotnet >nul 2>nul
if errorlevel 1 goto nodotnet
dotnet --list-sdks | findstr /r /b "10\. 11\. 12\." >nul
if errorlevel 1 goto nodotnet

echo [1/2] Publishing the launcher...
if exist installer\app rmdir /s /q installer\app
dotnet publish Z4ModernLauncher.csproj -c Release -r win-x64 --self-contained true -o installer\app
if errorlevel 1 goto fail
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0MAKE_UPDATE.ps1" -SetBaseline installer\app

:findiscc
set "PF86=%ProgramFiles(x86)%"
set "PF=%ProgramFiles%"
set "LAP=%LOCALAPPDATA%\Programs"
set "ISCC="
for %%P in ("%PF86%" "%PF%" "%LAP%") do for %%V in (7 6) do if not defined ISCC if exist "%%~P\Inno Setup %%V\ISCC.exe" set "ISCC=%%~P\Inno Setup %%V\ISCC.exe"
if defined ISCC goto compile
if defined TRIED goto noinno
set "TRIED=1"
echo.
echo Inno Setup (free installer builder) is needed once to create Setup.exe.
choice /c YN /m "Install it now with winget"
if errorlevel 2 goto noinno
winget install --id JRSoftware.InnoSetup -e --accept-package-agreements --accept-source-agreements
goto findiscc

:compile
echo.
echo [2/2] Building the installer...
"%ISCC%" installer\Z4Client.iss
if errorlevel 1 goto fail
echo.
echo ============================================
echo   Done: installer\output\Z4ClientSetup.exe
echo   Send that one file to your friends.
echo ============================================
explorer installer\output
pause
exit /b 0

:nodotnet
echo .NET SDK 10 or newer is needed to build. Get it from https://dotnet.microsoft.com/download
goto fail
:noinno
echo Install Inno Setup from https://jrsoftware.org/isdl.php and run this file again.
goto fail
:fail
echo.
echo Build failed. Read the message above.
pause
exit /b 1
