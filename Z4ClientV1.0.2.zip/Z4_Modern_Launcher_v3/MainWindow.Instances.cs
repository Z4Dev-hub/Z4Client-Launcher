using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private readonly ObservableCollection<InstanceInfo> _instances = new();
    private readonly ObservableCollection<ContentItem> _content = new();
    private string _activeName = "";
    private bool _suppressInstanceSelect;
    private bool _premadeBusy;
    private InstanceInfo? _detail;
    private string _tab = "mods";
    private static readonly string[] InstanceSubfolders = { "mods", "shaderpacks", "resourcepacks", "datapacks", "saves", "screenshots", "config" };

    private static readonly PremadeInstance[] Premades =
    {
        new("vanilla", "Vanilla", "The clean, unmodified game on the latest release.", "", "vanilla", "#1FA971", "#0E6B78", Array.Empty<(string, string)>()),
        new("z4client", "Z4 Client", "FPS mods + 3D skin layers + voice chat. Press Right Shift in game for the mod list.", "", "fabric", "#8B5CF6", "#38BDF8",
            new[] { ("fabric-api", "mods"), ("sodium", "mods"), ("lithium", "mods"), ("ferrite-core", "mods"), ("entityculling", "mods"), ("immediatelyfast", "mods"),
                    ("dynamic-fps", "mods"), ("krypton", "mods"), ("modmenu", "mods"), ("3dskinlayers", "mods"), ("simple-voice-chat", "mods") }),
        new("performance", "Performance", "Fabric with Sodium, Lithium and friends for big FPS gains.", "", "fabric", "#FF8A3D", "#D6336C",
            new[] { ("fabric-api", "mods"), ("sodium", "mods"), ("lithium", "mods"), ("ferrite-core", "mods"), ("entityculling", "mods"), ("immediatelyfast", "mods"), ("dynamic-fps", "mods") }),
        new("shaders", "Shader Ready", "Iris + Sodium with a beautiful shader pack preinstalled.", "", "fabric", "#8B5CF6", "#3B82F6",
            new[] { ("fabric-api", "mods"), ("sodium", "mods"), ("iris", "mods"), ("complementary-unbound", "shaderpacks") }),
        new("explorer", "Explorer", "Minimap, world map and quality-of-life helpers.", "", "fabric", "#14B8A6", "#0EA5E9",
            new[] { ("fabric-api", "mods"), ("modmenu", "mods"), ("appleskin", "mods"), ("jade", "mods"), ("xaeros-minimap", "mods"), ("xaeros-world-map", "mods") })
    };

    private InstanceInfo? ActiveInstance => _instances.FirstOrDefault(i => i.Name == _activeName);

    // ---------------------------------------------------------------- init / listing
    private void InitInstances()
    {
        InstancesList.ItemsSource = _instances;
        ContentList.ItemsSource = _content;
        TargetInstanceBox.DisplayMemberPath = "Name";
        TargetInstanceBox.ItemsSource = _instances;
        try { LoadInstances(); }
        catch (Exception ex) { Program.Log("Instances", ex.ToString()); }
    }

    private void LoadInstances()
    {
        _instances.Clear();
        Directory.CreateDirectory(_instancesRoot);
        foreach (var dir in Directory.GetDirectories(_instancesRoot).OrderBy(d => d, StringComparer.OrdinalIgnoreCase))
            _instances.Add(ReadInstance(dir));
        if (_instances.Count == 0) EnsureDefaultInstance();
        SelectActive();
    }

    private static InstanceInfo ReadInstance(string dir)
    {
        var version = "unspecified";
        var loader = "vanilla";
        var loaderVersion = "";
        try
        {
            var meta = Path.Combine(dir, "instance.json");
            if (File.Exists(meta))
            {
                var json = JsonNode.Parse(File.ReadAllText(meta));
                version = json?["version"]?.ToString() ?? version;
                loader = json?["loader"]?.ToString() ?? loader;
                loaderVersion = json?["loaderVersion"]?.ToString() ?? "";
            }
        }
        catch { }
        return new InstanceInfo(Path.GetFileName(dir), version, loader, dir, Summarize(dir), loaderVersion);
    }

    private static string Summarize(string dir)
    {
        int Count(string sub, bool dirs = false)
        {
            try
            {
                var p = Path.Combine(dir, sub);
                if (!Directory.Exists(p)) return 0;
                return dirs ? Directory.GetDirectories(p).Length : Directory.GetFiles(p).Length;
            }
            catch { return 0; }
        }
        return $"{Count("mods")} mods  •  {Count("shaderpacks")} shaders  •  {Count("resourcepacks")} resource packs  •  {Count("saves", true)} worlds";
    }

    private void RefreshInstanceEntry(string name)
    {
        var idx = -1;
        for (var i = 0; i < _instances.Count; i++) if (_instances[i].Name == name) { idx = i; break; }
        if (idx < 0) return;
        _suppressInstanceSelect = true;
        _instances[idx] = ReadInstance(_instances[idx].Path);
        if (_activeName == name) InstancesList.SelectedItem = _instances[idx];
        _suppressInstanceSelect = false;
        if (_detail?.Name == name) _detail = _instances[idx];
    }

    private InstanceInfo EnsureDefaultInstance()
    {
        var existing = _instances.FirstOrDefault(i => i.Name == "Default");
        if (existing is not null)
        {
            if (ActiveInstance is null) _activeName = existing.Name;
            return existing;
        }
        var inst = CreateInstanceFolders("Default", "unspecified", "vanilla");
        _instances.Add(inst);
        if (ActiveInstance is null) _activeName = inst.Name;
        return inst;
    }

    private InstanceInfo CreateInstanceFolders(string name, string version, string loader, string loaderVersion = "")
    {
        var path = Path.Combine(_instancesRoot, name);
        Directory.CreateDirectory(path);
        foreach (var sub in InstanceSubfolders) Directory.CreateDirectory(Path.Combine(path, sub));
        File.WriteAllText(Path.Combine(path, "instance.json"), JsonSerializer.Serialize(
            new { name, version, loader, loaderVersion, created = DateTime.UtcNow }, new JsonSerializerOptions { WriteIndented = true }));
        return new InstanceInfo(name, version, loader, path, Summarize(path), loaderVersion);
    }

    private string UniqueInstanceName(string wanted)
    {
        var name = wanted;
        var n = 2;
        while (_instances.Any(i => string.Equals(i.Name, name, StringComparison.OrdinalIgnoreCase)) || Directory.Exists(Path.Combine(_instancesRoot, name)))
            name = $"{wanted} {n++}";
        return name;
    }

    private void SelectActive()
    {
        _suppressInstanceSelect = true;
        var target = ActiveInstance ?? _instances.FirstOrDefault();
        if (target is not null) _activeName = target.Name;
        InstancesList.SelectedItem = target;
        TargetInstanceBox.SelectedItem = target;
        _suppressInstanceSelect = false;
        UpdateActiveText();
    }

    private void UpdateActiveText()
    {
        ActiveInstanceText.Text = ActiveInstance is { } a
            ? $"Active instance: {a.Name} ({a.Meta}). Everything you install goes here."
            : "No instance selected.";
    }

    private void SetActive(InstanceInfo inst)
    {
        _activeName = inst.Name;
        try { SaveSettings(); } catch { }
        SelectActive();
    }

    private void InstancesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressInstanceSelect || InstancesList.SelectedItem is not InstanceInfo inst) return;
        SetActive(inst);
        SetStatus($"Active instance: {inst.Name}");
    }

    private void TargetInstanceBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressInstanceSelect || TargetInstanceBox.SelectedItem is not InstanceInfo inst) return;
        SetActive(inst);
        SetStatus($"Installing into: {inst.Name}");
        if (_ready && ReferenceEquals(_currentPage, BrowserPanel)) _ = SearchAsync();   // show what fits this instance
    }

    private void InstancesList_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (InstancesList.SelectedItem is InstanceInfo inst) OpenInstanceDetail(inst);
    }

    private void OpenInstance_Click(object sender, RoutedEventArgs e)
    {
        if (InstancesList.SelectedItem is InstanceInfo inst) OpenInstanceDetail(inst);
        else SetStatus("Select an instance first.");
    }

    private void ResetInstancesView()
    {
        InstanceDetailView.Visibility = Visibility.Collapsed;
        InstancesListView.Visibility = Visibility.Visible;
        _detail = null;
        foreach (var inst in _instances.ToList()) RefreshInstanceEntry(inst.Name);
    }

    // ---------------------------------------------------------------- create / delete
    private void DeleteInstance_Click(object sender, RoutedEventArgs e)
    {
        if (InstancesList.SelectedItem is not InstanceInfo inst) { SetStatus("Select an instance first."); return; }
        var ok = MessageBox.Show(this, $"Delete \"{inst.Name}\" and everything inside it (mods, worlds, packs)?\n\nThis cannot be undone.",
            "Delete instance", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (ok != MessageBoxResult.Yes) return;
        try
        {
            UnlinkSharedFolders(inst.Path);
            Directory.Delete(inst.Path, true);
            _instances.Remove(inst);
            if (_activeName == inst.Name) _activeName = "";
            if (_instances.Count == 0) EnsureDefaultInstance();
            SelectActive();
            SaveSettings();
            SetStatus($"Deleted \"{inst.Name}\".");
        }
        catch (Exception ex) { SetStatus("Could not delete: " + ex.Message); }
    }

    private void InstanceFolder_Click(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement fe && fe.Tag is string tag) OpenFolder(tag);
    }

    // ---------------------------------------------------------------- premade instances
    private void PremadeItem_Loaded(object s, RoutedEventArgs e)
    {
        if (s is not FrameworkElement fe) return;
        var idx = fe.DataContext is PremadeInstance p ? Array.IndexOf(Premades, p) : 0;
        fe.Opacity = 0;
        fe.BeginAnimation(OpacityProperty, Tween(0, 1, 380, Math.Max(idx, 0) * 90));
    }

    private void Premade_Enter(object s, MouseEventArgs e)
    {
        if (s is not Border b) return;
        if (b.RenderTransform is ScaleTransform st && !st.IsFrozen)
        {
            st.BeginAnimation(ScaleTransform.ScaleXProperty, TweenTo(1.025, 220));
            st.BeginAnimation(ScaleTransform.ScaleYProperty, TweenTo(1.025, 220));
        }
        if (b.Background is LinearGradientBrush g && !g.IsFrozen)
        {
            g.BeginAnimation(LinearGradientBrush.StartPointProperty, new PointAnimation(new Point(0.45, 0), TimeSpan.FromMilliseconds(600)) { EasingFunction = EaseOut });
            g.BeginAnimation(LinearGradientBrush.EndPointProperty, new PointAnimation(new Point(0.9, 1), TimeSpan.FromMilliseconds(600)) { EasingFunction = EaseOut });
        }
    }

    private void Premade_Leave(object s, MouseEventArgs e)
    {
        if (s is not Border b) return;
        if (b.RenderTransform is ScaleTransform st && !st.IsFrozen)
        {
            st.BeginAnimation(ScaleTransform.ScaleXProperty, TweenTo(1, 300));
            st.BeginAnimation(ScaleTransform.ScaleYProperty, TweenTo(1, 300));
        }
        if (b.Background is LinearGradientBrush g && !g.IsFrozen)
        {
            g.BeginAnimation(LinearGradientBrush.StartPointProperty, new PointAnimation(new Point(0, 0), TimeSpan.FromMilliseconds(700)) { EasingFunction = EaseOut });
            g.BeginAnimation(LinearGradientBrush.EndPointProperty, new PointAnimation(new Point(1, 1), TimeSpan.FromMilliseconds(700)) { EasingFunction = EaseOut });
        }
    }

    /// <summary>Newest Minecraft release that Fabric API supports (or newest release for vanilla).</summary>
    private async Task<string> ResolveGameVersionAsync(string loader)
    {
        var releases = _versions.Where(v => v.Type == "release").Select(v => v.Id).ToList();
        if (releases.Count == 0) return "unspecified";
        if (loader == "vanilla") return releases[0];
        try
        {
            using var resp = await Http.GetAsync("https://api.modrinth.com/v2/project/fabric-api");
            resp.EnsureSuccessStatusCode();
            var json = JsonNode.Parse(await resp.Content.ReadAsStringAsync());
            var supported = new HashSet<string>();
            if (json?["game_versions"] is JsonArray arr)
                foreach (var v in arr) if (v?.ToString() is { } sv) supported.Add(sv);
            foreach (var r in releases) if (supported.Contains(r)) return r;
        }
        catch (Exception ex) { Program.Log("ResolveGameVersion", ex.Message); }
        return releases[0];
    }

    // ---------------------------------------------------------------- instance detail (opened inside the launcher)
    private void OpenInstanceDetail(InstanceInfo inst)
    {
        SetActive(inst);
        DetailTitle.Text = inst.Name;
        DetailMeta.Text = $"{inst.Meta}  •  {inst.Summary}";
        DetailInitial.Text = "";
        DetailIcon.Background = new ImageBrush(inst.Icon) { Stretch = Stretch.UniformToFill };
        _detailLoading = true;
        var noVersion = string.IsNullOrWhiteSpace(inst.Version) || inst.Version == "unspecified";
        DetailVersionBox.SelectedItem = _versions.FirstOrDefault(v => v.Id == inst.Version)
            ?? (noVersion ? _versions.FirstOrDefault(v => v.Type == "release") : null);   // suggest the newest release
        DetailHint.Visibility = noVersion ? Visibility.Visible : Visibility.Collapsed;
        DetailLoaderBox.SelectedIndex = 0;
        for (var i = 0; i < DetailLoaderBox.Items.Count; i++)
            if (DetailLoaderBox.Items[i] is ComboBoxItem li && string.Equals(li.Content?.ToString(), inst.Loader, StringComparison.OrdinalIgnoreCase))
                DetailLoaderBox.SelectedIndex = i;
        _detailLoading = false;
        _detailWantedLv = inst.LoaderVersion;

        if (!ReferenceEquals(_currentPage, InstancesPanel)) NavInstances.IsChecked = true;
        _detail = inst;
        InstancesListView.Visibility = Visibility.Collapsed;
        InstanceDetailView.Visibility = Visibility.Visible;
        Reveal(InstanceDetailView, 0, 22, 300, 0);
        TabMods.IsChecked = true;
        _tab = "mods";
        RefreshContent();
        _ = RefreshDetailLoaderVersionsAsync();
    }

    private void InstanceBack_Click(object sender, RoutedEventArgs e)
    {
        var fade = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(130)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
        fade.Completed += (_, _) =>
        {
            InstanceDetailView.BeginAnimation(OpacityProperty, null);
            InstanceDetailView.Opacity = 1;
            ResetInstancesView();
            SelectActive();
            Reveal(InstancesListView, 0, 16, 260, 0);
        };
        InstanceDetailView.BeginAnimation(OpacityProperty, fade);
    }

    private void InstanceTab_Checked(object sender, RoutedEventArgs e)
    {
        if (!_ready || _detail is null || sender is not RadioButton rb || rb.Tag is not string tab) return;
        _tab = tab;
        RefreshContent();
        Reveal(ContentList, 0, 10, 200, 0);
    }

    private static string HumanSize(long bytes) =>
        bytes >= 1L << 20 ? $"{bytes / (1024.0 * 1024.0):0.0} MB" : bytes >= 1024 ? $"{bytes / 1024.0:0} KB" : $"{bytes} B";

    private void RefreshContent()
    {
        if (_detail is null) return;
        _content.Clear();
        var dir = Path.Combine(_detail.Path, _tab);
        try
        {
            Directory.CreateDirectory(dir);
            var entries = Directory.EnumerateFileSystemEntries(dir);
            var ordered = _tab == "screenshots"
                ? entries.OrderByDescending(p => File.GetLastWriteTimeUtc(p))                       // newest first
                : entries.OrderBy(p => Path.GetFileName(p), StringComparer.OrdinalIgnoreCase);
            foreach (var entry in ordered)
            {
                var name = Path.GetFileName(entry);
                var isDir = Directory.Exists(entry);
                var enabled = !name.EndsWith(".disabled", StringComparison.OrdinalIgnoreCase);
                var display = enabled ? name : name[..^".disabled".Length];
                var detail = isDir ? "World folder"
                    : _tab == "screenshots" ? $"{File.GetLastWriteTime(entry):yyyy-MM-dd HH:mm}  •  {HumanSize(new FileInfo(entry).Length)}"
                    : HumanSize(new FileInfo(entry).Length);
                _content.Add(new ContentItem(display, entry, enabled, isDir, detail));
            }
        }
        catch (Exception ex) { SetStatus("Could not read folder: " + ex.Message); }

        ContentEmpty.Visibility = _content.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        ContentEmptyText.Text = _tab switch
        {
            "mods" => "No mods in this instance yet.",
            "shaderpacks" => "No shader packs yet.",
            "resourcepacks" => "No resource packs yet.",
            "datapacks" => "No datapacks yet.",
            "screenshots" => "No screenshots yet. Press F2 in the game to take one.",
            _ => "No worlds yet."
        };
    }

    // ---------------------------------------------------------------- add / toggle / remove
    private void AddFiles_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        var filter = _tab switch
        {
            "mods" => "Mods (*.jar)|*.jar|All files|*.*",
            "saves" => "World archives (*.zip)|*.zip|All files|*.*",
            "screenshots" => "Images (*.png;*.jpg)|*.png;*.jpg|All files|*.*",
            _ => "Packs (*.zip)|*.zip|All files|*.*"
        };
        var dialog = new Microsoft.Win32.OpenFileDialog { Multiselect = true, Filter = filter, Title = "Add to " + _detail.Name };
        if (dialog.ShowDialog(this) == true) ImportPaths(dialog.FileNames);
    }

    private void ImportPaths(IEnumerable<string> paths)
    {
        if (_detail is null) return;
        var dir = Path.Combine(_detail.Path, _tab);
        Directory.CreateDirectory(dir);
        var added = 0;
        foreach (var path in paths)
        {
            try
            {
                if (Directory.Exists(path))
                {
                    CopyDirectory(path, UniquePath(Path.Combine(dir, Path.GetFileName(path))));
                    added++;
                }
                else if (_tab == "saves" && path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    ExtractWorld(path, dir);
                    added++;
                }
                else
                {
                    File.Copy(path, Path.Combine(dir, Path.GetFileName(path)), true);
                    added++;
                }
            }
            catch (Exception ex) { SetStatus($"Could not add {Path.GetFileName(path)}: {ex.Message}"); }
        }
        RefreshInstanceEntry(_detail.Name);
        RefreshContent();
        if (added > 0) SetStatus($"Added {added} item(s) to {_detail.Name}.");
    }

    private static string UniquePath(string path)
    {
        if (!Directory.Exists(path) && !File.Exists(path)) return path;
        var n = 2;
        while (Directory.Exists($"{path} ({n})") || File.Exists($"{path} ({n})")) n++;
        return $"{path} ({n})";
    }

    private static void CopyDirectory(string source, string dest)
    {
        Directory.CreateDirectory(dest);
        foreach (var f in Directory.GetFiles(source)) File.Copy(f, Path.Combine(dest, Path.GetFileName(f)), true);
        foreach (var d in Directory.GetDirectories(source)) CopyDirectory(d, Path.Combine(dest, Path.GetFileName(d)));
    }

    private static void ExtractWorld(string zip, string savesDir)
    {
        var name = Path.GetFileNameWithoutExtension(zip);
        var temp = Path.Combine(savesDir, "__import_" + Guid.NewGuid().ToString("N"));
        ZipFile.ExtractToDirectory(zip, temp);
        var root = temp;
        if (!File.Exists(Path.Combine(temp, "level.dat")))
        {
            var inner = Directory.GetDirectories(temp).FirstOrDefault(d => File.Exists(Path.Combine(d, "level.dat")));
            if (inner is not null) { root = inner; name = Path.GetFileName(inner); }
        }
        Directory.Move(root, UniquePath(Path.Combine(savesDir, name)));
        if (root != temp && Directory.Exists(temp)) Directory.Delete(temp, true);
    }

    private void ContentList_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (ContentList.SelectedItem is not ContentItem item) return;
        try
        {
            if (item.IsDirectory || _tab == "screenshots")
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(item.FullPath) { UseShellExecute = true });
        }
        catch (Exception ex) { SetStatus("Could not open: " + ex.Message); }
    }

    private void OpenTabFolder_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        var dir = Path.Combine(_detail.Path, _tab);
        Directory.CreateDirectory(dir);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(dir) { UseShellExecute = true });
    }

    private void ToggleSelected_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        if (_tab == "screenshots") { SetStatus("Screenshots can't be enabled or disabled."); return; }
        var picked = ContentList.SelectedItems.OfType<ContentItem>().Where(c => !c.IsDirectory).ToList();
        if (picked.Count == 0) { SetStatus("Select one or more files first."); return; }
        foreach (var item in picked)
        {
            try
            {
                var target = item.Enabled ? item.FullPath + ".disabled" : item.FullPath[..^".disabled".Length];
                File.Move(item.FullPath, target, true);
            }
            catch (Exception ex) { SetStatus("Could not toggle " + item.DisplayName + ": " + ex.Message); }
        }
        RefreshContent();
    }

    private void RemoveSelected_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        var picked = ContentList.SelectedItems.OfType<ContentItem>().ToList();
        if (picked.Count == 0) { SetStatus("Select something to remove first."); return; }
        var label = picked.Count == 1 ? $"\"{picked[0].DisplayName}\"" : $"{picked.Count} items";
        if (MessageBox.Show(this, $"Remove {label} from {_detail.Name}?", "Remove", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        foreach (var item in picked)
        {
            try
            {
                if (item.IsDirectory) Directory.Delete(item.FullPath, true);
                else File.Delete(item.FullPath);
            }
            catch (Exception ex) { SetStatus("Could not remove " + item.DisplayName + ": " + ex.Message); }
        }
        RefreshInstanceEntry(_detail.Name);
        RefreshContent();
    }

    private void BrowseOnline_Click(object sender, RoutedEventArgs e)
    {
        switch (_tab)
        {
            case "shaderpacks": NavShaders.IsChecked = true; break;
            case "resourcepacks": NavResources.IsChecked = true; break;
            case "datapacks": NavDatapacks.IsChecked = true; break;
            case "saves": NavWorlds.IsChecked = true; break;
            default: NavMods.IsChecked = true; break;
        }
    }

    // ---------------------------------------------------------------- drag & drop
    private void Drop_Enter(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop)) DropOverlay.BeginAnimation(OpacityProperty, TweenTo(1, 160));
    }

    private void Drop_Over(object sender, DragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    private void Drop_Leave(object sender, DragEventArgs e) => DropOverlay.BeginAnimation(OpacityProperty, TweenTo(0, 220));

    private void Drop_Drop(object sender, DragEventArgs e)
    {
        DropOverlay.BeginAnimation(OpacityProperty, TweenTo(0, 220));
        if (e.Data.GetData(DataFormats.FileDrop) is string[] files) ImportPaths(files);
    }
}
