@echo off
setlocal
cd /d "%~dp0"
title Make a Z4 Client update
where dotnet >nul 2>nul
if errorlevel 1 ( echo .NET SDK not found. & pause & exit /b 1 )
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0MAKE_UPDATE.ps1" %*
if errorlevel 1 ( echo. & echo Failed. Read the message above. & pause & exit /b 1 )
if exist release explorer release
pause
