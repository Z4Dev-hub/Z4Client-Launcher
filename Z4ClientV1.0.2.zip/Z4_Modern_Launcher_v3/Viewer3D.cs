using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;

namespace Z4ModernLauncher;

/// <summary>Builds a rotatable 3D character (skin + overlay layers + optional cape) from the skin / cape textures.</summary>
public static class SkinViewer3D
{
    private sealed class Mesh
    {
        public readonly MeshGeometry3D Geo = new();

        public void Quad(Point3D a, Point3D b, Point3D c, Point3D d, Point ta, Point tb, Point tc, Point td)
        {
            var i = Geo.Positions.Count;
            Geo.Positions.Add(a); Geo.Positions.Add(b); Geo.Positions.Add(c); Geo.Positions.Add(d);
            Geo.TextureCoordinates.Add(ta); Geo.TextureCoordinates.Add(tb); Geo.TextureCoordinates.Add(tc); Geo.TextureCoordinates.Add(td);
            var n = Vector3D.CrossProduct(b - a, d - a);
            n.Normalize();
            for (var k = 0; k < 4; k++) Geo.Normals.Add(n);
            foreach (var idx in new[] { 0, 1, 2, 0, 2, 3 }) Geo.TriangleIndices.Add(i + idx);
        }
    }

    /// <summary>Minecraft box UV layout: u,v = texture origin; w,h,d = box size in texture pixels.</summary>
    private static void Box(Mesh m, double x0, double y0, double z0, double x1, double y1, double z1,
        double u, double v, double w, double h, double d, double tw, double th, bool mirror)
    {
        // returns the 4 corner texcoords (u0,v0 top-left ... u1,v1 bottom-right) of a region
        (double U0, double V0, double U1, double V1) R(double px, double py, double pw, double ph)
        {
            var a = px / tw; var b = (px + pw) / tw;
            return mirror ? (b, py / th, a, (py + ph) / th) : (a, py / th, b, (py + ph) / th);
        }
        var top = R(u + d, v, w, d);
        var bottom = R(u + d + w, v, w, d);
        var right = R(mirror ? u + d + w : u, v + d, d, h);      // character's right (-x) side
        var front = R(u + d, v + d, w, h);
        var left = R(mirror ? u : u + d + w, v + d, d, h);       // character's left (+x) side
        var back = R(u + 2 * d + w, v + d, w, h);

        // front (+z)
        m.Quad(new(x0, y0, z1), new(x1, y0, z1), new(x1, y1, z1), new(x0, y1, z1),
            new(front.U0, front.V1), new(front.U1, front.V1), new(front.U1, front.V0), new(front.U0, front.V0));
        // back (-z)
        m.Quad(new(x1, y0, z0), new(x0, y0, z0), new(x0, y1, z0), new(x1, y1, z0),
            new(back.U0, back.V1), new(back.U1, back.V1), new(back.U1, back.V0), new(back.U0, back.V0));
        // right (-x)
        m.Quad(new(x0, y0, z0), new(x0, y0, z1), new(x0, y1, z1), new(x0, y1, z0),
            new(right.U0, right.V1), new(right.U1, right.V1), new(right.U1, right.V0), new(right.U0, right.V0));
        // left (+x)
        m.Quad(new(x1, y0, z1), new(x1, y0, z0), new(x1, y1, z0), new(x1, y1, z1),
            new(left.U0, left.V1), new(left.U1, left.V1), new(left.U1, left.V0), new(left.U0, left.V0));
        // top (+y)
        m.Quad(new(x0, y1, z1), new(x1, y1, z1), new(x1, y1, z0), new(x0, y1, z0),
            new(top.U0, top.V1), new(top.U1, top.V1), new(top.U1, top.V0), new(top.U0, top.V0));
        // bottom (-y)
        m.Quad(new(x0, y0, z0), new(x1, y0, z0), new(x1, y0, z1), new(x0, y0, z1),
            new(bottom.U0, bottom.V1), new(bottom.U1, bottom.V1), new(bottom.U1, bottom.V0), new(bottom.U0, bottom.V0));
    }

    private static Brush TextureBrush(BitmapSource img)
    {
        var b = new ImageBrush(img) { Stretch = Stretch.Fill, ViewportUnits = BrushMappingMode.Absolute };
        RenderOptions.SetBitmapScalingMode(b, BitmapScalingMode.NearestNeighbor);
        return b;
    }

    public static Model3DGroup Build(BitmapSource skin, bool slim, BitmapSource? cape)
    {
        var group = new Model3DGroup();
        var legacy = skin.PixelHeight * 2 <= skin.PixelWidth + 1;        // old 64x32 skins
        double tw = 64, th = legacy ? 32 : 64;
        var aw = slim ? 3.0 : 4.0;

        var body = new Mesh();
        void Part(Mesh m, double x0, double y0, double z0, double x1, double y1, double z1, double e,
            double u, double v, double w, double h, double d, bool mirror = false) =>
            Box(m, x0 - e, y0 - e, z0 - e, x1 + e, y1 + e, z1 + e, u, v, w, h, d, tw, th, mirror);

        // head, body, right arm, right leg (left limbs follow below)
        Part(body, -4, 24, -4, 4, 32, 4, 0, 0, 0, 8, 8, 8);
        Part(body, -4, 12, -2, 4, 24, 2, 0, 16, 16, 8, 12, 4);
        Part(body, -4 - aw, 12, -2, -4, 24, 2, 0, 40, 16, aw, 12, 4);
        Part(body, -4, 0, -2, 0, 12, 2, 0, 0, 16, 4, 12, 4);                    // right leg
        if (legacy)
        {
            Part(body, 4, 12, -2, 4 + aw, 24, 2, 0, 40, 16, aw, 12, 4, true);   // left arm = mirrored right arm
            Part(body, 0, 0, -2, 4, 12, 2, 0, 0, 16, 4, 12, 4, true);           // left leg = mirrored right leg
        }
        else
        {
            Part(body, 4, 12, -2, 4 + aw, 24, 2, 0, 32, 48, aw, 12, 4);
            Part(body, 0, 0, -2, 4, 12, 2, 0, 16, 48, 4, 12, 4);
        }

        var layers = new Mesh();
        Part(layers, -4, 24, -4, 4, 32, 4, 0.5, 32, 0, 8, 8, 8);                // hat
        if (!legacy)
        {
            Part(layers, -4, 12, -2, 4, 24, 2, 0.25, 16, 32, 8, 12, 4);                 // jacket
            Part(layers, -4 - aw, 12, -2, -4, 24, 2, 0.25, 40, 32, aw, 12, 4);          // right sleeve
            Part(layers, 4, 12, -2, 4 + aw, 24, 2, 0.25, 48, 48, aw, 12, 4);            // left sleeve
            Part(layers, -4, 0, -2, 0, 12, 2, 0.25, 0, 32, 4, 12, 4);                   // right pants
            Part(layers, 0, 0, -2, 4, 12, 2, 0.25, 0, 48, 4, 12, 4);                    // left pants
        }

        var mat = new DiffuseMaterial(TextureBrush(skin));
        group.Children.Add(new GeometryModel3D(body.Geo, mat));
        group.Children.Add(new GeometryModel3D(layers.Geo, mat));

        if (cape is not null)
        {
            // cape textures are 64x32 (or HD multiples); the old OptiFine ones are 22x17
            var hd = cape.PixelWidth % 64 == 0;
            double ctw = hd ? 64 : 22, cth = hd ? 32 : 17;
            var cm = new Mesh();
            Box(cm, -5, 8, -3, 5, 24, -2, 0, 0, 10, 16, 1, ctw, cth, false);
            var capeModel = new GeometryModel3D(cm.Geo, new DiffuseMaterial(TextureBrush(cape)));
            var t = new Transform3DGroup();
            t.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(0, 1, 0), 180), new Point3D(0, 0, -2.5)));   // outside faces backwards
            t.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(1, 0, 0), 9), new Point3D(0, 24, -2.5)));    // slight tilt
            capeModel.Transform = t;
            group.Children.Add(capeModel);
        }
        return group;
    }
}
