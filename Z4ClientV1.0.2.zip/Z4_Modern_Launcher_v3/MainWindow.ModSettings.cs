using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Z4ModernLauncher;

public partial class MainWindow
{
    private ConfigDocument? _cfgDoc;
    private ICollectionView? _cfgView;
    private List<string> _cfgFiles = new();
    private bool _cfgLoading;

    // ---------------------------------------------------------------- enable / disable switch in the list
    private void ModSwitch_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement { Tag: string path }) return;
        try
        {
            var target = path.EndsWith(".disabled", StringComparison.OrdinalIgnoreCase) ? path[..^".disabled".Length] : path + ".disabled";
            File.Move(path, target, true);
            SetStatus(target.EndsWith(".disabled", StringComparison.OrdinalIgnoreCase)
                ? $"Disabled {Path.GetFileName(path)}" : $"Enabled {Path.GetFileName(target)}");
        }
        catch (Exception ex) { SetStatus("Could not switch: " + ex.Message); }
        RefreshContent();
    }

    // ---------------------------------------------------------------- mod settings window
    private void ModGear_Click(object sender, RoutedEventArgs e)
    {
        e.Handled = true;
        if (sender is FrameworkElement { Tag: string path }) OpenModSettings(path);
    }

    private void OpenModSettings(string jarPath)
    {
        if (_detail is null) return;
        var (id, name) = ModConfigFinder.ReadModInfo(jarPath);
        var fileName = Path.GetFileName(jarPath);
        var shown = name ?? id ?? Path.GetFileNameWithoutExtension(fileName.Replace(".disabled", ""));
        ModSettingsTitle.Text = shown + " — options";
        ModSettingsFilter.Text = "";
        ModSettingsStatus.Text = "";

        var configDir = Path.Combine(_detail.Path, "config");
        _cfgFiles = ModConfigFinder.FindConfigs(_detail.Path, id, name, fileName);
        _cfgLoading = true;
        ModConfigFileBox.ItemsSource = _cfgFiles.Select(f => Path.GetRelativePath(configDir, f)).ToList();
        ModConfigFileBox.SelectedIndex = _cfgFiles.Count > 0 ? 0 : -1;
        _cfgLoading = false;
        ModConfigFileBox.Visibility = _cfgFiles.Count > 1 ? Visibility.Visible : Visibility.Collapsed;

        if (_cfgFiles.Count == 0)
        {
            _cfgDoc = null;
            ModSettingsList.ItemsSource = null;
            ModSettingsInfo.Text = "";
            ModSettingsEmpty.Text = "No config file found for this mod yet. Start the game once so the mod creates it, then open this window again. " +
                                    "(Some mods have no options, or keep them in-game.)";
            ModSettingsEmpty.Visibility = Visibility.Visible;
            ModSettingsSaveButton.IsEnabled = false;
        }
        else LoadConfigFile(0);

        ModSettingsOverlay.Opacity = 0;
        ModSettingsOverlay.Visibility = Visibility.Visible;
        ModSettingsOverlay.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180)));
        ModSettingsCard.RenderTransformOrigin = new Point(0.5, 0.5);
        var scale = new ScaleTransform(0.95, 0.95);
        ModSettingsCard.RenderTransform = scale;
        var grow = new DoubleAnimation(0.95, 1, TimeSpan.FromMilliseconds(240)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, grow);
        scale.BeginAnimation(ScaleTransform.ScaleYProperty, grow.Clone());
    }

    private void ModConfigFile_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_cfgLoading || ModConfigFileBox.SelectedIndex < 0) return;
        LoadConfigFile(ModConfigFileBox.SelectedIndex);
    }

    private void LoadConfigFile(int index)
    {
        try
        {
            _cfgDoc = ConfigDocument.Load(_cfgFiles[index]);
            _cfgView = CollectionViewSource.GetDefaultView(_cfgDoc.Rows);
            ModSettingsList.ItemsSource = _cfgView;
            ApplySettingsFilter();
            ModSettingsEmpty.Visibility = _cfgDoc.Rows.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            ModSettingsEmpty.Text = "This file has no simple options (true/false, numbers or text) that can be edited here. Use Open file for anything else.";
            ModSettingsInfo.Text = $"{_cfgDoc.Rows.Count} option(s) • {Path.GetFileName(_cfgFiles[index])}" +
                (_cfgDoc.LosesComments ? " • comments in this file are removed when saving (a backup .z4bak is kept)" : "");
            ModSettingsSaveButton.IsEnabled = _cfgDoc.Rows.Count > 0;
        }
        catch (Exception ex)
        {
            Program.Log("Load config", ex.ToString());
            _cfgDoc = null;
            ModSettingsList.ItemsSource = null;
            ModSettingsEmpty.Text = "Could not read this file: " + ex.Message;
            ModSettingsEmpty.Visibility = Visibility.Visible;
            ModSettingsSaveButton.IsEnabled = false;
        }
    }

    private void ModSettingsFilter_Changed(object sender, TextChangedEventArgs e) => ApplySettingsFilter();

    private void ApplySettingsFilter()
    {
        if (_cfgView is null) return;
        var q = ModSettingsFilter.Text.Trim();
        _cfgView.Filter = q.Length == 0 ? null
            : o => o is SettingRow r && (r.Label.Contains(q, StringComparison.OrdinalIgnoreCase) || r.Path.Contains(q, StringComparison.OrdinalIgnoreCase));
    }

    private void ModSettingsSave_Click(object sender, RoutedEventArgs e)
    {
        if (_cfgDoc is null) return;
        Keyboard.ClearFocus();                         // commits a text box that is still being edited
        try
        {
            var changed = _cfgDoc.Rows.Count(r => r.Changed);
            if (changed == 0) { ModSettingsStatus.Text = "Nothing changed."; return; }
            _cfgDoc.Save();
            SetStatus($"Saved {changed} option(s). Restart the game to apply them." + (_playing ? " (Close the running game first, it may overwrite the file.)" : ""));
            CloseModSettings();
        }
        catch (Exception ex)
        {
            Program.Log("Save config", ex.ToString());
            ModSettingsStatus.Text = "Could not save: " + ex.Message;
        }
    }

    private void ModSettingsCancel_Click(object sender, RoutedEventArgs e) => CloseModSettings();

    private void CloseModSettings()
    {
        if (ModSettingsOverlay.Visibility != Visibility.Visible) return;
        var fade = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(130)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
        fade.Completed += (_, _) =>
        {
            ModSettingsOverlay.BeginAnimation(OpacityProperty, null);
            ModSettingsOverlay.Visibility = Visibility.Collapsed;
            ModSettingsOverlay.Opacity = 1;
            ModSettingsList.ItemsSource = null;
        };
        ModSettingsOverlay.BeginAnimation(OpacityProperty, fade);
    }

    private void ModSettingsOpenFile_Click(object sender, RoutedEventArgs e)
    {
        if (_cfgDoc is not null) OpenPath(_cfgDoc.FilePath);
        else if (_detail is not null) { Directory.CreateDirectory(Path.Combine(_detail.Path, "config")); OpenPath(Path.Combine(_detail.Path, "config")); }
    }
}
