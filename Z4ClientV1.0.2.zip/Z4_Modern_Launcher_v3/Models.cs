using System.Windows;
using System.Windows.Media;

namespace Z4ModernLauncher;

public static class Palette
{
    private static readonly (string A, string B)[] Pairs =
    {
        ("#8B5CF6", "#4F46E5"), ("#38BDF8", "#6366F1"), ("#F472B6", "#8B5CF6"), ("#34D399", "#0EA5E9"),
        ("#FB923C", "#E11D48"), ("#A78BFA", "#38BDF8"), ("#2DD4BF", "#6366F1"), ("#F59E0B", "#EC4899")
    };

    public static LinearGradientBrush For(string key)
    {
        var sum = 0;
        foreach (var c in key) sum = (sum * 31 + c) & 0x7fffffff;
        var (a, b) = Pairs[sum % Pairs.Length];
        var brush = new LinearGradientBrush((Color)ColorConverter.ConvertFromString(a), (Color)ColorConverter.ConvertFromString(b), 45);
        brush.Freeze();
        return brush;
    }

    public static LinearGradientBrush Gradient(string a, string b)
    {
        return new LinearGradientBrush((Color)ColorConverter.ConvertFromString(a), (Color)ColorConverter.ConvertFromString(b), new Point(0, 0), new Point(1, 1));
    }
}

public record ProjectResult(string Title, string Description, string Meta, string Source, string Id, string Slug, string? IconUrl = null)
{
    public string Initial => Title.Length > 0 ? Title[..1].ToUpperInvariant() : "?";
    public Brush Accent => Palette.For(Title);
    public ImageSource? Icon => ImageHelper.FromUrl(IconUrl, 104);   // read on a background thread (Binding IsAsync=True)
}

public record MinecraftVersion(string Id, string Type, string ReleaseTime)
{
    public string Label => $"{Id}   ·   {Type}";
    public override string ToString() => Label;
}

public record InstanceInfo(string Name, string Version, string Loader, string Path, string Summary, string LoaderVersion = "")
{
    public ImageSource Icon => InstanceIcons.Load(Path);
    public string LoaderLabel => string.IsNullOrEmpty(Loader) || Loader == "vanilla" ? "Vanilla" : char.ToUpperInvariant(Loader[0]) + Loader[1..];
    public string Meta => $"{LoaderLabel} {Version}";
    public string Initial => Name.Length > 0 ? Name[..1].ToUpperInvariant() : "?";
    public Brush Accent => Palette.For(Name);
}

public record ContentItem(string DisplayName, string FullPath, bool Enabled, bool IsDirectory, string Detail)
{
    public bool IsScreenshot => string.Equals(System.IO.Path.GetFileName(System.IO.Path.GetDirectoryName(FullPath) ?? ""), "screenshots", StringComparison.OrdinalIgnoreCase);
    public double IconWidth => IsScreenshot ? 132 : 38;
    public double IconHeight => IsScreenshot ? 74 : 38;
    public ImageSource? Icon => LocalIcons.Load(FullPath, IsDirectory, IsScreenshot);
    public bool IsModFile => !IsDirectory && string.Equals(System.IO.Path.GetFileName(System.IO.Path.GetDirectoryName(FullPath) ?? ""), "mods", StringComparison.OrdinalIgnoreCase);
    public Visibility SwitchVisibility => IsDirectory || IsScreenshot ? Visibility.Collapsed : Visibility.Visible;
    public Visibility GearVisibility => IsModFile ? Visibility.Visible : Visibility.Collapsed;
    public Visibility StatusVisibility => IsDirectory || IsScreenshot ? Visibility.Visible : Visibility.Collapsed;
    public string Status => IsScreenshot ? "IMAGE" : IsDirectory ? "FOLDER" : Enabled ? "ENABLED" : "DISABLED";
    public double Dim => Enabled ? 1.0 : 0.45;
    public Brush Accent => Palette.For(DisplayName);
    public string Initial => DisplayName.Length > 0 ? DisplayName[..1].ToUpperInvariant() : "?";
}

public record PremadeInstance(string Id, string Name, string Tagline, string Glyph, string Loader, string ColorA, string ColorB,
    (string Slug, string Folder)[] Items)
{
    public LinearGradientBrush Gradient => Palette.Gradient(ColorA, ColorB);
    public string Summary => Items.Length == 0
        ? "Vanilla • no downloads"
        : $"{(char.ToUpperInvariant(Loader[0]) + Loader[1..])} • {Items.Length} downloads from Modrinth";
}

public record SkinFile(string Name, string Path)
{
    public ImageSource? Face => SkinRenderer.Face(Path);
}

public record CapeItem(string Id, string Alias, string Url, bool Active)
{
    public ImageSource? Image => SkinRenderer.CapeFront(Url);
    public string Badge => Active ? "EQUIPPED" : "";
    public Visibility BadgeVisibility => Active ? Visibility.Visible : Visibility.Collapsed;
}

public record ShotItem(string Path, string Instance, DateTime Time)
{
    public ImageSource? Thumb => LocalIcons.Load(Path, false, true);
    public string When => Time.ToString("yyyy-MM-dd HH:mm");
}
