using CmlLib.Core.Auth;
using CmlLib.Core.Auth.Microsoft;

namespace Z4ModernLauncher;

/// <summary>
/// Sign-in that needs no Azure app of your own: uses CmlLib.Core's built-in Microsoft login
/// (it ships its own app ID). Fine for a small group of friends; if you ever distribute the launcher
/// publicly, register your own app and set AuthConfig.DefaultClientId instead.
/// </summary>
public static class DefaultAuth
{
    private static JELoginHandler? _handler;
    private static JELoginHandler Handler => _handler ??= JELoginHandlerBuilder.BuildDefault();

    public static async Task<MinecraftSession> SignInAsync()
        => ToSession(await Handler.AuthenticateInteractively());

    /// <summary>Returns null when there is no saved login (or it expired).</summary>
    public static async Task<MinecraftSession?> TrySilentAsync()
    {
        try { return ToSession(await Handler.AuthenticateSilently()); }
        catch { return null; }
    }

    public static async Task SignOutAsync()
    {
        try { await Handler.Signout(); } catch { }
    }

    private static MinecraftSession ToSession(MSession s) =>
        new(s.Username ?? "Player", s.UUID ?? "", s.AccessToken ?? "", "", DateTime.UtcNow.AddHours(23));
}
