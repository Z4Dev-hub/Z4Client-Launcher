using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Z4ModernLauncher;

public partial class MainWindow : Window
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(2) };
    private readonly ObservableCollection<ProjectResult> _results = new();
    private readonly List<MinecraftVersion> _versions = new();
    private string _category = "mod";
    private string _instancesRoot = DefaultInstancesRoot;
    private static string DefaultInstancesRoot => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Z4Launcher", "instances");
    private string _curseKey = "";
    private bool _loadingVersions;
    private bool _ready;
    private FrameworkElement? _currentPage;
    private int _navToken;
    private const string VersionManifestUrl = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

    // ---------- animation helpers ----------
    private static readonly IEasingFunction EaseOut = new CubicEase { EasingMode = EasingMode.EaseOut };
    private static readonly IEasingFunction EaseInOut = new SineEase { EasingMode = EasingMode.EaseInOut };

    private static DoubleAnimation Tween(double from, double to, int ms, int delayMs = 0, IEasingFunction? ease = null) =>
        new(from, to, TimeSpan.FromMilliseconds(ms))
        {
            BeginTime = TimeSpan.FromMilliseconds(delayMs),
            EasingFunction = ease ?? EaseOut
        };

    private static DoubleAnimation TweenTo(double to, int ms, IEasingFunction? ease = null) =>
        new(to, TimeSpan.FromMilliseconds(ms)) { EasingFunction = ease ?? EaseOut };

    private static TranslateTransform EnsureTranslate(UIElement el)
    {
        if (el.RenderTransform is TranslateTransform t && !t.IsFrozen) return t;
        var nt = new TranslateTransform();
        el.RenderTransform = nt;
        return nt;
    }

    /// <summary>Fade in while sliding from an offset to rest.</summary>
    private static void Reveal(UIElement el, double dx, double dy, int ms, int delayMs)
    {
        var t = EnsureTranslate(el);
        el.Opacity = 0;
        el.BeginAnimation(OpacityProperty, Tween(0, 1, ms, delayMs));
        if (dx != 0) t.BeginAnimation(TranslateTransform.XProperty, Tween(dx, 0, ms + 120, delayMs));
        if (dy != 0) t.BeginAnimation(TranslateTransform.YProperty, Tween(dy, 0, ms + 120, delayMs));
    }

    static MainWindow()
    {
        Http.DefaultRequestHeaders.UserAgent.ParseAdd("Z4ModernLauncher/2.0 (desktop launcher)");
        Http.DefaultRequestHeaders.Accept.ParseAdd("application/json");
    }

    public MainWindow()
    {
        Program.Log("MainWindow", "Constructor started");
        InitializeComponent();
        Program.Log("MainWindow", "XAML loaded");

        ResultsList.ItemsSource = _results;
        LoadSettings();
        GameDirBox.Text = _instancesRoot;
        RamBox.Text = _ramMb.ToString();
        CurseKeyBox.Password = _curseKey;
        InitInstances();
        InitProfile();

        StateChanged += (_, _) =>
        {
            var max = WindowState == WindowState.Maximized;
            Root.Margin = max ? SystemParameters.WindowResizeBorderThickness : new Thickness(0);
            MaxButton.Content = max ? "" : "";
        };
        SizeChanged += (_, _) => ApplyScale();
        Root.Opacity = 0;                                            // faded in by OnLoaded
        Root.RenderTransformOrigin = new Point(0.5, 0.5);
        Root.RenderTransform = new ScaleTransform(0.97, 0.97);
        StateChanged += (_, _) => { if (WindowState != WindowState.Minimized) AnimateRoot(true); };
        Closing += OnWindowClosing;
        SourceInitialized += (_, _) => ApplyWindowLook();
        EffectBox.SelectedIndex = _effect == "mica" ? 1 : _effect == "none" ? 2 : 0;
        GlassSlider.Value = _glass;
        InitUpdateUi();
        Loaded += OnLoaded;
        Loaded += (_, _) => _ = StartupUpdateCheckAsync();
        Program.Log("MainWindow", "Constructor completed");
    }

    // ---------------------------------------------------------------- fullscreen + scaling
    /// <summary>Scales the whole UI up on big screens instead of leaving tiny content in a huge window.</summary>
    private void ApplyScale()
    {
        if (ActualWidth <= 0 || ActualHeight <= 0) return;
        var scale = Math.Clamp(Math.Min(ActualWidth / 1280.0, ActualHeight / 820.0), 1.0, 1.8);
        Root.LayoutTransform = scale < 1.02 ? Transform.Identity : new ScaleTransform(scale, scale);
    }

    /// <summary>"Fullscreen" = maximized to the work area, so the taskbar stays visible.</summary>
    private void ToggleFullscreen() =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    protected override void OnPreviewKeyDown(System.Windows.Input.KeyEventArgs e)
    {
        base.OnPreviewKeyDown(e);
        if (e.Key == System.Windows.Input.Key.F11) { ToggleFullscreen(); e.Handled = true; }
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        AnimateRoot(true);
        // Entrance: sidebar slides in, content rises.
        Reveal(Sidebar, -40, 0, 480, 0);
        Reveal(MainArea, 0, 26, 520, 120);

        _currentPage = OverviewPanel;
        StaggerOverview(260);

        // Ambient motion: drifting hero glow, pulsing glyph, breathing status dot.
        var drift = new PointAnimation(new Point(0.8, 0.12), new Point(0.97, 0.85), TimeSpan.FromSeconds(7))
        { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut };
        HeroGlow.BeginAnimation(RadialGradientBrush.CenterProperty, drift);
        HeroGlow.BeginAnimation(RadialGradientBrush.GradientOriginProperty, drift.Clone());

        var pulse = new DoubleAnimation(1, 1.09, TimeSpan.FromSeconds(2.6))
        { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut };
        GlyphScale.BeginAnimation(ScaleTransform.ScaleXProperty, pulse);
        GlyphScale.BeginAnimation(ScaleTransform.ScaleYProperty, pulse.Clone());


        // Slow drifting gradient lights behind everything.
        Glow1Shift.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(-90, 140, TimeSpan.FromSeconds(11)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut });
        Glow1Shift.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(-30, 90, TimeSpan.FromSeconds(13)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut });
        Glow2Shift.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(80, -160, TimeSpan.FromSeconds(14)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut });
        Glow2Shift.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(40, -80, TimeSpan.FromSeconds(10)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut });

        // Colour-shifting accent line + hero core.
        LineStop1.BeginAnimation(GradientStop.ColorProperty, new ColorAnimation(Color.FromRgb(0x8B, 0x5C, 0xF6), Color.FromRgb(0xF4, 0x72, 0xB6), TimeSpan.FromSeconds(4)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut });
        LineStop2.BeginAnimation(GradientStop.ColorProperty, new ColorAnimation(Color.FromRgb(0x38, 0xBD, 0xF8), Color.FromRgb(0x8B, 0x5C, 0xF6), TimeSpan.FromSeconds(4)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut });
        HeroStop.BeginAnimation(GradientStop.ColorProperty, new ColorAnimation(Color.FromRgb(0x5B, 0x3F, 0xD0), Color.FromRgb(0x2F, 0x6B, 0xE8), TimeSpan.FromSeconds(6)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut });

        _ready = true;
        _ = LoadVersionsAsync();
        _ = TrySilentSignInAsync();
    }

    // ---------- window chrome ----------
    private bool _closeAnimDone;

    /// <summary>Window-level fade + scale, used for opening, closing, minimizing and restoring.</summary>
    private void AnimateRoot(bool show, Action? done = null)
    {
        var duration = TimeSpan.FromMilliseconds(show ? 240 : 140);
        var ease = new CubicEase { EasingMode = show ? EasingMode.EaseOut : EasingMode.EaseIn };
        var opacity = new DoubleAnimation(show ? 0 : 1, show ? 1 : 0, duration) { EasingFunction = ease };
        if (done is not null) opacity.Completed += (_, _) => done();
        Root.BeginAnimation(OpacityProperty, opacity);
        if (Root.RenderTransform is ScaleTransform st)
        {
            var scale = new DoubleAnimation(show ? 0.97 : 1, show ? 1 : 0.97, duration) { EasingFunction = ease };
            st.BeginAnimation(ScaleTransform.ScaleXProperty, scale);
            st.BeginAnimation(ScaleTransform.ScaleYProperty, scale.Clone());
        }
    }

    private void OnWindowClosing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (_closeAnimDone) return;
        e.Cancel = true;                                             // play the closing animation first, then really close
        AnimateRoot(false, () => { _closeAnimDone = true; Close(); });
    }

    private void Minimize_Click(object s, RoutedEventArgs e) => AnimateRoot(false, () => WindowState = WindowState.Minimized);
    private void Maximize_Click(object s, RoutedEventArgs e) =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    private void Close_Click(object s, RoutedEventArgs e) => Close();

    // ---------- navigation with page transitions ----------
    private void Nav_Checked(object sender, RoutedEventArgs e)
    {
        if (!_ready || sender is not RadioButton rb) return;
        switch (rb.Tag as string)
        {
            case "overview": ShowPage(OverviewPanel, "Your Minecraft, your way.", "A calmer home for your instances, content and style."); break;
            case "instances": ResetInstancesView(); ShowPage(InstancesPanel, "Instances", "Premade setups, and every instance opened right here."); break;
            case "screenshots": ShowPage(ScreenshotsPanel, "Screenshots", "Everything you captured in-game, across all instances."); _ = RefreshShotsPageAsync(); break;
            case "mod": OpenBrowser("mod", "Mods"); break;
            case "shader": OpenBrowser("shader", "Shaders"); break;
            case "resourcepack": OpenBrowser("resourcepack", "Resource packs"); break;
            case "datapack": OpenBrowser("datapack", "Datapacks"); break;
            case "world": OpenBrowser("world", "Worlds"); break;
            case "profile": ShowPage(ProfilePanel, "Skin & Cape", "Manage the look of your Minecraft character."); _ = RefreshProfilePageAsync(); break;
            case "settings": ShowPage(SettingsPanel, "Settings", "Configure your game directory and content sources."); break;
        }
    }

    private void ShowPage(FrameworkElement target, string title, string subtitle)
    {
        PageTitle.Text = title;
        PageSubtitle.Text = subtitle;
        Reveal(HeaderStack, -16, 0, 300, 40);

        var token = ++_navToken;
        var old = _currentPage;
        _currentPage = target;
        if (ReferenceEquals(old, target) && target.IsVisible) return;

        void Enter()
        {
            if (token != _navToken) return;
            target.Visibility = Visibility.Visible;
            if (ReferenceEquals(target, OverviewPanel))
            {
                target.BeginAnimation(OpacityProperty, null);
                target.Opacity = 1;
                StaggerOverview(0);
            }
            else
            {
                Reveal(target, 0, 22, 300, 0);
            }
        }

        if (old is not null && old.IsVisible && !ReferenceEquals(old, target))
        {
            var fade = TweenTo(0, 110);
            fade.Completed += (_, _) =>
            {
                old.Visibility = Visibility.Collapsed;
                old.BeginAnimation(OpacityProperty, null);
                old.Opacity = 1;
                Enter();
            };
            old.BeginAnimation(OpacityProperty, fade);
        }
        else Enter();
    }

    private void StaggerOverview(int baseDelay)
    {
        var i = 0;
        foreach (UIElement child in OverviewStack.Children)
        {
            Reveal(child, 0, 28, 380, baseDelay + i * 85);
            i++;
        }
    }

    private void HeroExplore_Click(object s, RoutedEventArgs e) => NavMods.IsChecked = true;
    private void HeroInstances_Click(object s, RoutedEventArgs e) => NavInstances.IsChecked = true;

    private void ForwardWheel(object s, MouseWheelEventArgs e)
    {
        if (e.Handled || s is not FrameworkElement fe || fe.Parent is not UIElement parent) return;
        e.Handled = true;
        parent.RaiseEvent(new MouseWheelEventArgs(e.MouseDevice, e.Timestamp, e.Delta) { RoutedEvent = MouseWheelEvent, Source = s });
    }

    // ---------- card hover tweens ----------
    private void Card_Enter(object s, MouseEventArgs e)
    {
        if (s is not Border b) return;
        EnsureTranslate(b).BeginAnimation(TranslateTransform.YProperty, TweenTo(-4, 180));
        if (b.BorderBrush is SolidColorBrush sb && !sb.IsFrozen)
            sb.BeginAnimation(SolidColorBrush.ColorProperty, new ColorAnimation(Color.FromRgb(0x8B, 0x5C, 0xF6), TimeSpan.FromMilliseconds(200)));
    }

    private void Card_Leave(object s, MouseEventArgs e)
    {
        if (s is not Border b) return;
        EnsureTranslate(b).BeginAnimation(TranslateTransform.YProperty, TweenTo(0, 260));
        if (b.BorderBrush is SolidColorBrush sb && !sb.IsFrozen)
            sb.BeginAnimation(SolidColorBrush.ColorProperty, new ColorAnimation(Color.FromRgb(0x22, 0x2A, 0x3F), TimeSpan.FromMilliseconds(280)));
    }

    private void QuickCard_Click(object s, MouseButtonEventArgs e)
    {
        if (s is FrameworkElement fe && fe.Tag is string folder) OpenFolder(folder);
    }

    private void ResultItem_Loaded(object s, RoutedEventArgs e)
    {
        if (s is not FrameworkElement fe) return;
        var idx = fe.DataContext is ProjectResult pr ? _results.IndexOf(pr) : 0;
        Reveal(fe, 0, 16, 260, idx >= 0 && idx < 12 ? idx * 40 : 0);
    }

    private void SetBusy(bool on)
    {
        BusyHost.Visibility = on ? Visibility.Visible : Visibility.Hidden;
        InstBusyHost.Visibility = on ? Visibility.Visible : Visibility.Hidden;
        if (on)
        {
            var width = BusyHost.ActualWidth > 0 ? BusyHost.ActualWidth : 800;
            DoubleAnimation Slide() => new(-170, width, TimeSpan.FromMilliseconds(1100))
            { RepeatBehavior = RepeatBehavior.Forever, EasingFunction = EaseInOut };
            BusyShift.BeginAnimation(TranslateTransform.XProperty, Slide());
            InstBusyShift.BeginAnimation(TranslateTransform.XProperty, Slide());
        }
        else
        {
            BusyShift.BeginAnimation(TranslateTransform.XProperty, null);
            InstBusyShift.BeginAnimation(TranslateTransform.XProperty, null);
        }
    }

    private void SetStatus(string text)
    {
        StatusText.Text = text;
        StatusText.BeginAnimation(OpacityProperty, Tween(0, 1, 260));
        EnsureTranslate(StatusText).BeginAnimation(TranslateTransform.YProperty, Tween(6, 0, 260));
    }

    // ---------- versions ----------
    private async Task LoadVersionsAsync()
    {
        if (_loadingVersions) return;
        _loadingVersions = true;
        try
        {
            VersionInfoText.Text = "Fetching Mojang version manifest…";
            using var response = await Http.GetAsync(VersionManifestUrl);
            response.EnsureSuccessStatusCode();
            var root = JsonNode.Parse(await response.Content.ReadAsStringAsync());
            _versions.Clear();
            if (root?["versions"] is JsonArray items)
            {
                foreach (var item in items)
                {
                    var id = item?["id"]?.ToString();
                    var type = item?["type"]?.ToString() ?? "unknown";
                    var releaseTime = item?["releaseTime"]?.ToString() ?? "";
                    if (!string.IsNullOrWhiteSpace(id))
                        _versions.Add(new MinecraftVersion(id, type, releaseTime));
                }
            }
            VersionBox.ItemsSource = null;
            VersionBox.DisplayMemberPath = "Label";
            VersionBox.ItemsSource = _versions;
            if (_versions.Count > 0) VersionBox.SelectedIndex = 0;
            DetailVersionBox.DisplayMemberPath = "Label";
            DetailVersionBox.ItemsSource = _versions;
            if (_detail is not null) DetailVersionBox.SelectedItem = _versions.FirstOrDefault(v => v.Id == _detail.Version);
            VersionInfoText.Text = $"{_versions.Count} Java versions listed by Mojang, including historical versions where present. Select one, then open the official launcher to install and play it.";
        }
        catch (Exception ex)
        {
            VersionInfoText.Text = "Could not load Mojang's version list: " + ex.Message;
        }
        finally { _loadingVersions = false; }
    }

    private async void RefreshVersions_Click(object s, RoutedEventArgs e) => await LoadVersionsAsync();

    private void VersionBox_SelectionChanged(object s, SelectionChangedEventArgs e)
    {
        if (VersionBox.SelectedItem is not MinecraftVersion v || VersionInfoText is null) return;
        VersionInfoText.Text = $"{v.Id}  •  {v.Type}  •  {v.ReleaseTime}\nFor legacy builds, use a separate game directory and back up old worlds. Some very early versions may have compatibility limitations.";
        VersionInfoText.BeginAnimation(OpacityProperty, Tween(0, 1, 220));
    }

    private void OpenOfficialLauncher_Click(object s, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("minecraft://") { UseShellExecute = true });
            var selected = VersionBox.SelectedItem as MinecraftVersion;
            SetStatus(selected is null
                ? "Opened the official Minecraft Launcher."
                : $"Opened the official launcher. Choose {selected.Id} in Installations and install it there.");
        }
        catch (Exception ex)
        {
            SetStatus("Could not open Minecraft Launcher: " + ex.Message + " Open it from the Start menu instead.");
        }
    }

    // ---------- content browser ----------
    private void OpenBrowser(string category, string title)
    {
        _category = category;
        CategoryText.Text = title.ToUpperInvariant();
        _results.Clear();
        EmptyText.Visibility = Visibility.Visible;
        EmptyText.Text = category == "world"
            ? "Search worlds on CurseForge, or browse local saves from Overview."
            : "Loading the most popular…";
        SearchBox.Text = "";
        ShowPage(BrowserPanel, title, $"Most popular {title.ToLowerInvariant()} on Modrinth and CurseForge. Type to search.");
        if (category != "world") _ = SearchAsync();
    }

    private async void SourceBox_SelectionChanged(object s, SelectionChangedEventArgs e)
    {
        if (!_ready || !ReferenceEquals(_currentPage, BrowserPanel)) return;
        await SearchAsync();
    }

    private static string FormatCount(string? raw)
    {
        if (!double.TryParse(raw, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var n)) return raw ?? "0";
        return n >= 1_000_000_000 ? $"{n / 1_000_000_000:0.#}B" : n >= 1_000_000 ? $"{n / 1_000_000:0.#}M" : n >= 1_000 ? $"{n / 1_000:0.#}K" : n.ToString("0");
    }

    private async void Search_Click(object s, RoutedEventArgs e) => await SearchAsync();
    private async void SearchBox_KeyDown(object s, KeyEventArgs e) { if (e.Key == Key.Enter) await SearchAsync(); }

    private async Task SearchAsync()
    {
        var query = SearchBox.Text.Trim();
        var popular = query.Length == 0;
        var inst = ActiveInstance;
        var filter = inst is not null && inst.Version != "unspecified" ? inst : null;   // only show what fits the chosen instance
        _results.Clear();
        EmptyText.Visibility = Visibility.Visible;
        EmptyText.Text = popular ? "Loading the most popular…" : "Searching…";
        SetStatus(popular ? "Loading the most popular…" : "Searching content providers…");
        SetBusy(true);
        try
        {
            var source = (SourceBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Modrinth";
            if (source == "Modrinth")
            {
                if (_category == "world")
                {
                    EmptyText.Text = "Modrinth does not expose a dedicated world-save project type. Choose CurseForge for world searches, or open local saves from Overview.";
                    SetStatus("World search is available through CurseForge.");
                    return;
                }
                await SearchModrinth(query, filter);
                if (_results.Count == 0 && filter is not null) { filter = null; await SearchModrinth(query, null); }
            }
            else
            {
                await SearchCurseForge(query, filter);
                if (_results.Count == 0 && filter is not null) { filter = null; await SearchCurseForge(query, null); }
            }

            EmptyText.Visibility = _results.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            if (_results.Count == 0) EmptyText.Text = "No results found. Try another search.";
            var fits = filter is not null ? $" • for {filter.LoaderLabel} {filter.Version}" : "";
            SetStatus(popular
                ? $"Most popular {_category}s on {source}{fits}"
                : $"{_results.Count} result(s) • {_category} • {source}{fits}");
        }
        catch (Exception ex)
        {
            EmptyText.Text = "Search failed. Check your connection and provider settings.";
            SetStatus(ex.Message);
        }
        finally { SetBusy(false); }
    }

    private async Task SearchModrinth(string query, InstanceInfo? filter)
    {
        var facet = _category switch { "mod" => "mod", "shader" => "shader", "datapack" => "datapack", "resourcepack" => "resourcepack", _ => "mod" };
        var groups = new List<string[]> { new[] { $"project_type:{facet}" } };
        if (filter is not null)
        {
            groups.Add(new[] { $"versions:{filter.Version}" });
            if (_category == "mod")
            {
                if (filter.Loader == "quilt") groups.Add(new[] { "categories:quilt", "categories:fabric" });   // Quilt runs Fabric mods
                else if (filter.Loader is "fabric" or "forge" or "neoforge") groups.Add(new[] { $"categories:{filter.Loader}" });
            }
        }
        var facets = JsonSerializer.Serialize(groups);
        var index = query.Length == 0 ? "downloads" : "relevance";   // no search text = most downloaded first
        var url = "https://api.modrinth.com/v2/search?query=" + Uri.EscapeDataString(query)
            + "&facets=" + Uri.EscapeDataString(facets) + "&limit=30&index=" + index;
        using var response = await Http.GetAsync(url);
        response.EnsureSuccessStatusCode();
        var root = JsonNode.Parse(await response.Content.ReadAsStringAsync());
        if (root?["hits"] is not JsonArray hits) return;
        foreach (var hit in hits)
        {
            var id = hit?["project_id"]?.ToString() ?? "";
            var title = hit?["title"]?.ToString() ?? "Untitled";
            var desc = hit?["description"]?.ToString() ?? "";
            var downloads = hit?["downloads"]?.ToString() ?? "0";
            var slug = hit?["slug"]?.ToString() ?? id;
            var icon = hit?["icon_url"]?.ToString();
            _results.Add(new ProjectResult(title, desc, $"Modrinth • {FormatCount(downloads)} downloads", "Modrinth", id, slug, string.IsNullOrWhiteSpace(icon) ? null : icon));
        }
    }

    private async Task SearchCurseForge(string query, InstanceInfo? filter)
    {
        if (string.IsNullOrWhiteSpace(_curseKey))
            throw new InvalidOperationException("Add a CurseForge API key in Settings to search CurseForge.");
        var classId = _category switch { "mod" => 6, "shader" => 6552, "datapack" => 6945, "world" => 17, "resourcepack" => 12, _ => 6 };
        var url = $"https://api.curseforge.com/v1/mods/search?gameId=432&classId={classId}&searchFilter={Uri.EscapeDataString(query)}&pageSize=30&sortField=2&sortOrder=desc";   // sortField 2 = popularity
        if (filter is not null)
        {
            url += "&gameVersion=" + Uri.EscapeDataString(filter.Version);
            if (_category == "mod")
            {
                var loaderType = filter.Loader switch { "forge" => 1, "fabric" => 4, "quilt" => 5, "neoforge" => 6, _ => 0 };
                if (loaderType != 0) url += "&modLoaderType=" + loaderType;
            }
        }
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.Add("x-api-key", _curseKey);
        using var response = await Http.SendAsync(req);
        response.EnsureSuccessStatusCode();
        var root = JsonNode.Parse(await response.Content.ReadAsStringAsync());
        if (root?["data"] is not JsonArray data) return;
        foreach (var item in data)
        {
            var id = item?["id"]?.ToString() ?? "";
            var title = item?["name"]?.ToString() ?? "Untitled";
            var desc = item?["summary"]?.ToString() ?? "";
            var downloads = item?["downloadCount"]?.ToString() ?? "0";
            var logo = item?["logo"]?["thumbnailUrl"]?.ToString();
            _results.Add(new ProjectResult(title, desc, $"CurseForge • {FormatCount(downloads)} downloads", "CurseForge", id, id, string.IsNullOrWhiteSpace(logo) ? null : logo));
        }
    }

    private async void Install_Click(object sender, RoutedEventArgs e)
    {
        if (ResultsList.SelectedItem is not ProjectResult selected) { SetStatus("Select a result first."); return; }
        SetBusy(true);
        try
        {
            SetStatus("Resolving compatible file…");
            if (selected.Source == "Modrinth") await InstallModrinth(selected);
            else await InstallCurseForge(selected);
        }
        catch (Exception ex) { SetStatus("Install failed: " + ex.Message); }
        finally { SetBusy(false); }
    }

    private async Task InstallModrinth(ProjectResult p)
    {
        var inst = ActiveInstance ?? EnsureDefaultInstance();
        var folder = Path.GetFileName(TargetFolder());
        var file = await DownloadModrinthAsync(p.Id, folder, inst, strict: folder == "mods");
        RefreshInstanceEntry(inst.Name);
        SetStatus($"Installed {p.Title} ({file}) into \"{inst.Name}\"");
    }

    /// <summary>Downloads the best-matching file of a Modrinth project into an instance folder.</summary>
    private async Task<string> DownloadModrinthAsync(string project, string folder, InstanceInfo inst, bool strict)
    {
        var query = new List<string>();
        if (folder == "mods" && !string.IsNullOrEmpty(inst.Loader) && inst.Loader != "vanilla")
            query.Add("loaders=" + Uri.EscapeDataString(JsonSerializer.Serialize(new[] { inst.Loader })));
        var versionFilter = inst.Version != "unspecified" ? "game_versions=" + Uri.EscapeDataString(JsonSerializer.Serialize(new[] { inst.Version })) : null;

        async Task<JsonNode?> FetchAsync(bool withVersion)
        {
            var qs = new List<string>(query);
            if (withVersion && versionFilter != null) qs.Add(versionFilter);
            var url = $"https://api.modrinth.com/v2/project/{Uri.EscapeDataString(project)}/version" + (qs.Count > 0 ? "?" + string.Join("&", qs) : "");
            using var resp = await Http.GetAsync(url);
            resp.EnsureSuccessStatusCode();
            return (JsonNode.Parse(await resp.Content.ReadAsStringAsync()) as JsonArray)?.FirstOrDefault();
        }

        var version = await FetchAsync(true);
        if (version is null && !strict) version = await FetchAsync(false);
        if (version is null)
            throw new Exception($"No {inst.LoaderLabel} file for Minecraft {inst.Version} was found for \"{project}\".");

        var files = version["files"]?.AsArray();
        var file = files?.FirstOrDefault(x => x?["primary"]?.GetValue<bool>() == true) ?? files?.FirstOrDefault();
        var download = file?["url"]?.ToString();
        var filename = file?["filename"]?.ToString();
        if (string.IsNullOrWhiteSpace(download) || string.IsNullOrWhiteSpace(filename)) throw new Exception("No downloadable file found.");

        var target = Path.Combine(inst.Path, folder);
        Directory.CreateDirectory(target);
        var bytes = await Http.GetByteArrayAsync(download);
        await File.WriteAllBytesAsync(Path.Combine(target, Path.GetFileName(filename)), bytes);
        return Path.GetFileName(filename);
    }

    private async Task InstallCurseForge(ProjectResult p)
    {
        var url = $"https://api.curseforge.com/v1/mods/{p.Id}/files?pageSize=20&index=0";
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.Add("x-api-key", _curseKey);
        using var resp = await Http.SendAsync(req);
        resp.EnsureSuccessStatusCode();
        var root = JsonNode.Parse(await resp.Content.ReadAsStringAsync());
        var file = root?["data"]?.AsArray().FirstOrDefault();
        var download = file?["downloadUrl"]?.ToString();
        var filename = file?["fileName"]?.ToString();
        if (string.IsNullOrWhiteSpace(download) || string.IsNullOrWhiteSpace(filename)) throw new Exception("No direct file URL. Open the project page to download it.");
        var folder = TargetFolder();
        Directory.CreateDirectory(folder);
        var bytes = await Http.GetByteArrayAsync(download);
        await File.WriteAllBytesAsync(Path.Combine(folder, Path.GetFileName(filename)), bytes);
        RefreshInstanceEntry((ActiveInstance ?? EnsureDefaultInstance()).Name);
        SetStatus($"Downloaded {p.Title} into instance \"{ActiveInstance?.Name}\"");
    }

    private string TargetFolder()
    {
        var inst = ActiveInstance ?? EnsureDefaultInstance();
        var sub = _category switch
        {
            "shader" => "shaderpacks",
            "datapack" => "datapacks",
            "world" => "saves",
            "resourcepack" => "resourcepacks",
            _ => "mods"
        };
        return Path.Combine(inst.Path, sub);
    }

    private void OpenFolder(string name)
    {
        try
        {
            var inst = ActiveInstance ?? EnsureDefaultInstance();
            var path = name == "@root" ? _instancesRoot : name == "." ? inst.Path : Path.Combine(inst.Path, name);
            Directory.CreateDirectory(path);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true });
        }
        catch (Exception ex) { SetStatus("Could not open folder: " + ex.Message); }
    }

    private void DefaultDir_Click(object s, RoutedEventArgs e) => GameDirBox.Text = DefaultInstancesRoot;

    private void SaveSettings_Click(object s, RoutedEventArgs e)
    {
        var newRoot = string.IsNullOrWhiteSpace(GameDirBox.Text) ? _instancesRoot : GameDirBox.Text.Trim();
        var rootChanged = !string.Equals(newRoot, _instancesRoot, StringComparison.OrdinalIgnoreCase);
        _instancesRoot = newRoot;
        _curseKey = CurseKeyBox.Password.Trim();
        _autoUpdate = AutoUpdateBox.IsChecked == true;
        _updateUrl = UpdateUrlBox.Text.Trim();
        _ramMb = int.TryParse(RamBox.Text.Trim(), out var ram) ? Math.Clamp(ram, 1024, 65536) : 4096;
        RamBox.Text = _ramMb.ToString();
        try
        {
            SaveSettings();
            if (rootChanged) LoadInstances();
            SetStatus("Settings saved locally.");
        }
        catch (Exception ex) { SetStatus("Could not save settings: " + ex.Message); }
    }

    private static string ConfigPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Z4ModernLauncher", "settings.json");

    private void LoadSettings()
    {
        try
        {
            if (!File.Exists(ConfigPath)) return;
            var cfg = JsonNode.Parse(File.ReadAllText(ConfigPath));
            var dir = cfg?["instancesDirectory"]?.ToString();
            if (!string.IsNullOrWhiteSpace(dir)) _instancesRoot = dir;
            _activeName = cfg?["activeInstance"]?.ToString() ?? "";
            var overrideId = cfg?["azureClientId"]?.ToString();
            if (!string.IsNullOrWhiteSpace(overrideId)) AuthConfig.ClientId = overrideId.Trim();
            _curseKey = cfg?["curseForgeApiKey"]?.ToString() ?? "";
            if (int.TryParse(cfg?["ramMb"]?.ToString(), out var savedRam)) _ramMb = Math.Clamp(savedRam, 1024, 65536);
            _autoUpdate = cfg?["autoUpdate"]?.ToString() != "False";
            _updateUrl = cfg?["updateUrl"]?.ToString() ?? "";
            var eff = cfg?["windowEffect"]?.ToString();
            if (eff is "acrylic" or "mica" or "none") _effect = eff;
            if (int.TryParse(cfg?["glass"]?.ToString(), out var g)) _glass = Math.Clamp(g, 0, 100);
        }
        catch { }
    }

    private void SaveSettings()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(ConfigPath)!);
        File.WriteAllText(ConfigPath, JsonSerializer.Serialize(
            new { instancesDirectory = _instancesRoot, activeInstance = _activeName, azureClientId = AuthConfig.ClientId == AuthConfig.DefaultClientId ? "" : AuthConfig.ClientId, curseForgeApiKey = _curseKey, ramMb = _ramMb, windowEffect = _effect, glass = _glass, autoUpdate = _autoUpdate, updateUrl = _updateUrl },
            new JsonSerializerOptions { WriteIndented = true }));
    }

    // ---------------------------------------------------------------- see-through window (blur)
    private string _effect = "acrylic";
    private int _glass = 70;

    private void Discord_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo("https://discord.gg/Uabq8nXReb") { UseShellExecute = true }); }
        catch (Exception ex) { SetStatus("Could not open the link: " + ex.Message); }
    }

    private void ApplyWindowLook()
    {
        var blur = false;
        try { blur = WindowEffects.Apply(this, _effect); }
        catch (Exception ex) { Program.Log("WindowEffects", ex.Message); }
        var t = blur ? _glass / 100.0 : 0.0;

        void Set(string key, byte r, byte g, byte b, double solidAlpha, double glassAlpha)
        {
            if (Application.Current.Resources[key] is SolidColorBrush brush && !brush.IsFrozen)
                brush.Color = Color.FromArgb((byte)(solidAlpha + (glassAlpha - solidAlpha) * t), r, g, b);
        }
        Set("TintBrush", 0x0A, 0x0C, 0x12, 255, 100);          // main background
        Set("SidebarGlassBrush", 0x0B, 0x0E, 0x16, 255, 120);  // sidebar
        Set("GlassBrush", 0x12, 0x16, 0x24, 255, 140);         // cards, lists, status bar
    }

    private void Effect_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready) return;
        _effect = EffectBox.SelectedIndex switch { 1 => "mica", 2 => "none", _ => "acrylic" };
        ApplyWindowLook();
    }

    private void Glass_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        _glass = (int)GlassSlider.Value;
        ApplyWindowLook();
    }
}
